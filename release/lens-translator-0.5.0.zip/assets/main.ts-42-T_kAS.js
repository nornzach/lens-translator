import{i as e,t}from"./settings-defaults-J11EyiRw.js";import{i as n}from"./hotkey-tZ8Jri1V.js";import{n as r,r as i}from"./languages-CqtD30Wb.js";import{i as a,n as o,r as s,t as c}from"./text-BWXmprjd.js";import{a as l,c as u,t as d}from"./vocabulary-CJExWyZ0.js";function f(e,t,n){let r=`${e.toLowerCase()}|${a(t)}|${n}`,i=2166136261;for(let e=0;e<r.length;e++)i^=r.charCodeAt(e),i=Math.imul(i,16777619);return`b_${(i>>>0).toString(36)}`}async function p(e,t,n){let r=e.slice(),i=async()=>{let e=r.shift();e!==void 0&&(await n(e),await i())},a=[];for(let n=0;n<Math.min(t,e.length);n++)a.push(i());await Promise.all(a)}var m=`data-lens-translator-source`,h=[`p`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`li`,`blockquote`,`figcaption`,`caption`,`td`,`th`,`dt`,`dd`,`summary`,`label`,`legend`,`address`,`article`],ee=[`[role="heading"]`,`[role="listitem"]`,`[role="paragraph"]`,`[role="article"]`,`[role="text"]`,`[role="tab"]`,`[role="menuitem"]`,`[role="menuitemradio"]`,`[role="option"]`,`[role="button"]`,`[role="link"]`],te=`.markdown-body,.markdown-content,.markdown,.md-content,.md-typeset,.prose,.Post-body,.post-content,.entry-content,.article-content,.article-body,.post-body,.rich-text,.RichText,.notion-page-content,[data-testid="post_message"],.message-body,.comment-body,.js-comment-body,.wiki-body,.doc-content,.docs-content,.content__default,.theme-default-content,.vp-doc,.mdx-content,[class*="Markdown"],[class*="markdown"],[class*="ProseMirror"],[class*="DraftEditor"],[class*="ql-editor"],[class*="tiptap"],[class*="slate-"],[data-slate-editor]`.split(`,`),ne=/(?:^|[\s_-])(?:paragraph|text-block|textblock|richtext|rich-text|post-body|postbody|entry-content|article-body|md-p|md-block|markdown-p|block-paragraph|block-text|notion-text|notion-page-block|pw-post-body|reader-word|transcript|caption-text|message-text|comment-text|answer-text|question-title|issue-body)(?:$|[\s_-])/i,re=/paragraph|text|heading|list.?item|quote|callout|toggle|bulleted|numbered|to.?do/i,g=new Set(`a.abbr.b.bdi.bdo.br.cite.code.data.dfn.em.i.kbd.mark.q.rp.rt.ruby.s.samp.small.span.strong.sub.sup.time.u.var.wbr.svg.img.picture.source.font.strike.big.tt.acronym.del.ins.math.mi.mo.mn.mrow.msup.msub`.split(`.`)),ie=`script.style.noscript.template.svg.canvas.video.audio.iframe.object.embed.textarea.input.select.nav.pre.[contenteditable]:not([contenteditable="false"]).[role="textbox"].[class*="DraftEditorPlaceholder"].[class*="EditorPlaceholder"].[class*="editor-placeholder"].[aria-hidden="true"].[role="navigation"].[role="banner"].[role="search"].[role="toolbar"].[role="tooltip"].tool-tip.[data-lens-ignore].[data-lens-page-translation].#lens-translator-root`.split(`.`).join(`, `),_=new Set(`script.style.noscript.template.svg.canvas.video.audio.iframe.object.embed.textarea.input.select.option.nav.pre.code.br.hr.img.path.meta.link.head.html.body`.split(`.`));function v(e){let t=[],n=e,r=0;for(;n&&r<8;){let e=n.parentElement,i=0;if(e){let t=[...e.children].filter(e=>e.tagName===n.tagName);i=Math.max(0,t.indexOf(n))}let a=n.tagName.toLowerCase();t.push(`${a}[${i}]`),n=e,r++}return`/`+t.reverse().join(`/`)}function y(e,t){let n=e.getBoundingClientRect();if(!b(e,n))return!1;let r=window.innerHeight,i=window.innerWidth;return!(n.bottom<-t||n.top>r+t||n.right<0||n.left>i)}function b(e,t=e.getBoundingClientRect()){if(t.width<2||t.height<2)return!1;let n=window.getComputedStyle(e);return!(n.display===`none`||n.visibility===`hidden`||n.opacity===`0`)}var ae=new Set([`script`,`style`,`noscript`,`template`]);function x(e,t){if(!(typeof document<`u`&&typeof document.createTreeWalker==`function`)||t===void 0&&(typeof e.querySelector!=`function`||!e.querySelector(`script, style, noscript, template`))){let n=e.textContent??``;return t!==void 0&&n.length>t?n.slice(0,t):n}let n=document.createTreeWalker(e,4,{acceptNode(t){let n=t.parentElement;for(;n&&n!==e;){if(ae.has(n.tagName.toLowerCase()))return 2;n=n.parentElement}return 1}}),r=``,i=n.nextNode();for(;i;){if(r+=i.nodeValue??``,t!==void 0&&r.length>t)return r;i=n.nextNode()}return r}function S(e){return a(e.getAttribute(`data-lens-translator-source`)??x(e))}function C(e){for(let t of e.children){let e=t.tagName.toLowerCase();if(e.includes(`-`)||!g.has(e)||e!==`br`&&e!==`img`&&e!==`source`&&e!==`wbr`&&e!==`path`&&!C(t))return!1}return!0}function oe(e){return typeof e.className==`string`?e.className:e.getAttribute(`class`)??``}function se(e){let t=oe(e);if(ne.test(t))return!0;let n=e.getAttribute(`data-testid`)||e.getAttribute(`data-test`)||``;if(ne.test(n))return!0;let r=e.getAttribute(`data-block-type`)||e.getAttribute(`data-type`)||e.getAttribute(`data-slate-type`)||e.getAttribute(`data-text-type`)||``;if(r&&re.test(r))return!0;let i=e.getAttribute(`role`)||``;return i===`heading`||i===`listitem`||i===`paragraph`||i===`text`}function ce(e){return e.tagName.includes(`-`)}function w(e){let t=0;for(let n of h)if(t+=e.querySelectorAll(n).length,t>3)return t;for(let n of ee)if(t+=e.querySelectorAll(n).length,t>3)return t;return t}function le(e){return e.querySelectorAll(`a, button, [role="link"], [role="button"], [role="tab"], [role="menuitem"], [role="menuitemradio"], [role="option"]`).length>1}function T(e){let t=(e.getAttribute(`role`)||``).toLowerCase();if(t===`tab`||t===`menuitem`||t===`menuitemradio`||t===`option`||t===`button`||t===`link`)return!0;let n=e.tagName.toLowerCase();if(n===`button`||n===`summary`)return!0;if(n===`a`){let t=S(e);if(t.length>0&&t.length<=48&&(C(e)||e.children.length===0))return!0}if(e.closest(`[role="tablist"]`)&&(n===`div`||n===`span`||n===`li`)&&(C(e)||e.children.length===0)){let t=S(e);if(t.length>0&&t.length<=48)return!0}return!1}function ue(e,t){let n=e.tagName.toLowerCase(),r=S(e);if(T(e))return s(r,Math.min(2,t))&&r.length<=80;if(_.has(n)||!s(r,t))return!1;if(C(e))return!le(e);if(se(e)){let n=w(e);if(n<=2&&r.length<=2e3||n===0&&r.length>=t&&r.length<=1500)return!0}if(ce(e)){let n=w(e);if(n===0&&C(e)||n<=1&&r.length<=1200&&r.length>=t)return!0}return!1}function de(e,t){return!T(e)&&w(e)>1&&S(e).length>t*2}function fe(e){if(e.closest(`#lens-translator-root`)||!e.hasAttribute(`data-lens-translator-source`)&&e.querySelector(`[data-lens-page-translation]`)||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`)return!0;if(T(e))return!!e.closest(`script, style, noscript, template, textarea, input, select, svg, canvas`);if(e.closest(ie))return!0;let t=e.tagName.toLowerCase();return!!_.has(t)}function pe(e=document){let t=[],n=new Set,r=e=>{for(let r of e)n.has(r)||(n.add(r),t.push(r))};r(e.querySelectorAll(h.join(`,`))),r(e.querySelectorAll(ee.join(`,`))),r(e.querySelectorAll(`button, [role="tablist"] button, [role="tablist"] a, [role="tablist"] [role="tab"]`)),r(e.querySelectorAll(`[role="tablist"] > *, [role="tablist"] [role="presentation"] > *`)),r(e.querySelectorAll(`a, [role="link"]`));for(let t of e.querySelectorAll(te.join(`,`)))r(t.querySelectorAll(h.join(`,`))),r(t.querySelectorAll(`:scope > div, :scope > span, :scope > section`)),r(t.querySelectorAll(`div > p, div > li, div > h1, div > h2, div > h3, section > p`));r(e.querySelectorAll([`[data-block-type]`,`[data-slate-type]`,`[data-text-type]`,`[class*="paragraph"]`,`[class*="Paragraph"]`,`[class*="text-block"]`,`[class*="TextBlock"]`,`[class*="notion-text"]`,`[class*="markdown"] p`,`[class*="Markdown"] p`,`[class*="prose"] p`,`[class*="prose"] li`].join(`,`))),r(e.querySelectorAll(`div, span, section, article, main`));for(let r of e.querySelectorAll(`*`))r.tagName.includes(`-`)&&!n.has(r)&&(n.add(r),t.push(r));return t}function me(e,t,n){if(fe(e)||(n===null?!b(e):!y(e,n)))return;let r=e.tagName.toLowerCase(),i=h.includes(r),a=e.getAttribute(`role`)||``,o=a===`heading`||a===`listitem`||a===`paragraph`||a===`text`||a===`tab`||a===`menuitem`||a===`button`||a===`link`,c=T(e),l=c?Math.min(2,t):t;if(c){if(!ue(e,t))return}else if(i||o){if(!s(S(e),l)||de(e,t))return}else if(!ue(e,t))return;let u=S(e);if(s(u,l))return{id:f(r,u,v(e)),el:e,tag:r,text:u}}var he=4e3,ge=new Set([`script`,`style`,`noscript`,`template`,`canvas`,`video`,`audio`,`iframe`,`object`,`embed`,`textarea`,`input`,`select`,`option`,`br`,`hr`,`img`,`path`,`meta`,`link`,`head`,`html`,`body`,`svg`]),_e=`script, style, noscript, template, canvas, video, audio, iframe, object, embed, textarea, input, select, [data-lens-ignore], #lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt`;function E(e){if(e.closest(_e)||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`)return!0;let t=e.tagName.toLowerCase();return!!ge.has(t)}function ve(e,t){return t.length<280?!1:e.querySelectorAll(`p, li, h1, h2, h3, h4, h5, h6, tr, blockquote, pre, section, article`).length>=4}function ye(e,t){return T(e)?1:Math.max(1,Math.min(t,2))}function be(e,t=1){let n=e;for(;n!==null;){let e=n,r=e.tagName.toLowerCase();if(r===`html`||r===`body`)break;let i=!0;if(!E(e)){try{i=b(e)}catch{i=!0}if(i){let n=a(x(e,4001));if(s(n,ye(e,t))&&n.length<=4e3&&!ve(e,n))return{id:f(r,n,v(e)),el:e,tag:r,text:n}}}n=e.parentElement}}var xe=new Set([``,`text`,`search`,`url`,`email`]);function D(e,t=he){let n=e?.closest(`textarea, input, [contenteditable]:not([contenteditable="false"])`);if(!n||n.closest(`[data-lens-ignore], #lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt`))return null;let r=n.tagName.toLowerCase();if(r===`textarea`){let e=n,r=a(e.value);return!r||r.length>t?null:{el:e,kind:`textarea`,text:r,writable:!e.disabled&&!e.readOnly}}if(r===`input`){let e=n;if(!xe.has(e.type))return null;let r=a(e.value);return!r||r.length>t?null:{el:e,kind:`input`,text:r,writable:!e.disabled&&!e.readOnly}}if(n.isContentEditable){let e=a(x(n,t+1));return!e||e.length>t?null:{el:n,kind:`contenteditable`,text:e,writable:!0}}return null}function O(e,t,n=1){let r=null;try{let n=document;if(typeof n.caretRangeFromPoint==`function`){let i=n.caretRangeFromPoint(e,t)?.startContainer;i&&(r=i.nodeType===Node.TEXT_NODE?i.parentElement:i instanceof Element?i:null)}else if(typeof n.caretPositionFromPoint==`function`){let i=n.caretPositionFromPoint(e,t)?.offsetNode;i&&(r=i.nodeType===Node.TEXT_NODE?i.parentElement:i instanceof Element?i:null)}}catch{}if(!r)try{r=document.elementsFromPoint(e,t).find(e=>e.id!==`lens-translator-root`&&!e.closest?.(`#lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root`)&&!E(e))??null}catch{r=null}return be(r,n)||Se(r,n)}function Se(e,t){let n=e;for(;n&&n.tagName.toLowerCase()!==`html`;){let e=me(n,t,0);if(e)return e;n=n.parentElement}}function Ce(e,t){return A(document,e,t)}function we(e,t=document){let n=k(t),r=n.flatMap(t=>A(t,e,null)),i=new Set(r.map(e=>e.el)),a=n.flatMap(t=>De(t,e,i));return[...r,...a]}function k(e=document){let t=[e];`shadowRoot`in e&&e.shadowRoot&&t.push(e.shadowRoot);for(let e=0;e<t.length;e++)for(let n of t[e].querySelectorAll(`*`))n.shadowRoot&&t.push(n.shadowRoot);return t}function Te(e){let t=e.parentElement;if(!t)return null;let n=t;for(;g.has(n.tagName.toLowerCase());){let e=n.parentElement;if(!e||e.tagName.toLowerCase()===`body`)break;n=e}let r=n.tagName.toLowerCase();return r===`html`||r===`body`?null:n}function Ee(e,t){let n=e;for(;n;){if(t.has(n))return!0;n=n.parentElement}return!1}function De(e,t,n){let r=new Map,i=document.createTreeWalker(e,4),o=i.nextNode();for(;o;){let e=o,t=a(e.data),s=e.parentElement;if(t&&s&&!Ee(s,n)){let n=Te(e);if(n&&!fe(n)){let e=r.get(n)??[];e.push(t),r.set(n,e)}}o=i.nextNode()}let c=[];for(let[e,i]of r){if(!b(e))continue;let r=a(i.join(` `));if(!s(r,T(e)?Math.min(2,t):t))continue;let o=e.tagName.toLowerCase(),l={id:f(o,r,v(e)),el:e,tag:o,text:r};c.push(l),n.add(e)}return c}function A(e,t,n){let r=pe(e),i=[],a=new Set,o=new Set;for(let e of r){if(o.has(e))continue;let r=me(e,t,n);!r||a.has(r.id)||(a.add(r.id),o.add(r.el),i.push(r))}return Oe(i)}function Oe(e){if(e.length<=1)return e;let t=new Map(e.map(e=>[e.el,e])),n=new Set;for(let r of e){let e=r.el.parentElement;for(;e;){let i=t.get(e);if(i&&r.text.length>=Math.min(i.text.length*.5,i.text.length-1)&&(i.text.length<=r.text.length+40||i.el.querySelectorAll(`p,li,h1,h2,h3,h4,h5,h6`).length>=1)){n.add(i);break}e=e.parentElement}}return e.filter(e=>!n.has(e))}var ke=class{byId=new Map;byEl=new WeakMap;byNormText=new Map;maxEntries;maxTranslations;constructor(e=1500,t=2500){this.maxEntries=Math.max(1,e),this.maxTranslations=Math.max(1,t)}upsert(e){let t=this.byId.get(e.id);t||this.makeRoom();let n=a(e.text),r=this.byNormText.get(n),i={id:e.id,el:e.el,tag:e.tag,text:e.text,status:e.status??t?.status??`pending`,translation:t?.translation,error:t?.error};return t&&t.text===i.text&&t.translation?(i.translation=t.translation,i.status=`ready`):r&&(i.translation=r,i.status=`ready`,i.error=void 0),this.byId.set(i.id,i),this.byEl.set(i.el,i.id),i}setTranslation(e,t){let n=this.byId.get(e);if(!n)return;let r=a(n.text);for(this.byNormText.delete(r),this.byNormText.set(r,t);this.byNormText.size>this.maxTranslations;){let e=this.byNormText.keys().next().value;if(e===void 0)break;this.byNormText.delete(e)}for(let e of this.byId.values())a(e.text)===r&&(e.translation=t,e.status=`ready`,e.error=void 0)}setError(e,t){let n=this.byId.get(e);n&&(n.status=`error`,n.error=t)}setPending(e){let t=this.byId.get(e);t&&t.status!==`ready`&&(t.status=`pending`)}get(e){return this.byId.get(e)}getByElement(e){if(!e)return;let t=e;for(;t;){let e=this.byEl.get(t);if(e)return this.byId.get(e);t=t.parentElement}}pendingBlocks(){return[...this.byId.values()].filter(e=>e.status===`pending`).map(e=>({id:e.id,tag:e.tag,text:e.text}))}resetTranslationsToPending(){this.byNormText.clear();for(let e of this.byId.values())e.status=`pending`,e.translation=void 0,e.error=void 0}makeRoom(){if(!(this.byId.size<this.maxEntries)){for(let[e,t]of this.byId)t.el.isConnected||this.byId.delete(e);for(;this.byId.size>=this.maxEntries;){let e=this.byId.keys().next().value;if(e===void 0)break;this.byId.delete(e)}}}},Ae=class e{host;root;panel;textLayer;sourceLabel;sourceBody;zhLabel;body;divider;hint;ring;toolbar;starBtn;speakSourceBtn;speakTargetBtn;dictCard;actionRow;actionBtn;actionHandler=null;starHandler=null;speakHandler=null;highlightEl=null;widthPx;lastSourceKey=``;sourceLangLabel=`源语言`;targetLangLabel=`译文`;constructor(t=340){this.widthPx=t,this.host=document.createElement(`div`),this.host.id=`lens-translator-root`,Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,pointerEvents:`none`,zIndex:`2147483647`}),this.root=this.host.attachShadow({mode:`open`});let n=document.createElement(`style`);n.textContent=je;let r=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);r.setAttribute(`aria-hidden`,`true`),r.setAttribute(`width`,`0`),r.setAttribute(`height`,`0`),r.style.position=`absolute`,r.innerHTML=`
      <defs>
        <filter id="glass-distortion" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.008 0.008" numOctaves="2" seed="3" result="noise" />
          <feGaussianBlur in="noise" stdDeviation="0.5" result="softNoise" />
          <feDisplacementMap in="SourceGraphic" in2="softNoise" scale="12" xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </defs>
    `,this.ring=document.createElement(`div`),this.ring.className=`source-outline`,this.ring.style.display=`none`,this.panel=document.createElement(`div`),this.panel.className=`liquidGlass-wrapper panel`,this.panel.style.display=`none`;let i=document.createElement(`div`);i.className=`liquidGlass-effect`;let a=document.createElement(`div`);a.className=`liquidGlass-tint`;let o=document.createElement(`div`);o.className=`liquidGlass-shine`,this.textLayer=document.createElement(`div`),this.textLayer.className=`liquidGlass-text`,this.sourceLabel=document.createElement(`div`),this.sourceLabel.className=`label label-source`,this.sourceLabel.textContent=this.sourceLangLabel,this.sourceBody=document.createElement(`div`),this.sourceBody.className=`body body-source`,this.divider=document.createElement(`div`),this.divider.className=`divider`,this.zhLabel=document.createElement(`div`),this.zhLabel.className=`label label-target`,this.zhLabel.textContent=this.targetLangLabel,this.body=document.createElement(`div`),this.body.className=`body body-zh`,this.hint=document.createElement(`div`),this.hint.className=`hint`,this.toolbar=document.createElement(`div`),this.toolbar.className=`toolbar`,this.starBtn=e.iconButton(`star`,`收藏到生词本`),this.starBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.starHandler?.()}),this.speakSourceBtn=e.iconButton(`speak`,`朗读原文`),this.speakSourceBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.speakHandler?.(`source`)}),this.speakTargetBtn=e.iconButton(`speak`,`朗读译文`),this.speakTargetBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.speakHandler?.(`target`)}),this.toolbar.append(this.starBtn,this.speakSourceBtn,this.speakTargetBtn),this.dictCard=document.createElement(`div`),this.dictCard.className=`dict-card`,this.actionRow=document.createElement(`div`),this.actionRow.className=`action-row`,this.actionBtn=document.createElement(`button`),this.actionBtn.type=`button`,this.actionBtn.className=`action-btn`,this.actionBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.actionHandler?.()}),this.actionRow.append(this.actionBtn),this.textLayer.append(this.toolbar,this.sourceLabel,this.sourceBody,this.divider,this.zhLabel,this.body,this.dictCard,this.actionRow,this.hint),this.panel.append(i,a,o,this.textLayer),this.root.append(n,r,this.ring,this.panel),this.applyWidth()}applyWidth(){this.panel.style.width=`${this.widthPx}px`,this.panel.style.maxWidth=`${this.widthPx}px`}static iconButton(e,t){let n=document.createElement(`button`);return n.type=`button`,n.className=`icon-btn icon-${e}`,n.title=t,n.setAttribute(`aria-label`,t),n.textContent=e===`star`?`☆`:`🔊`,n}onAction(e){this.actionHandler=e}onStar(e){this.starHandler=e}onSpeak(e){this.speakHandler=e}setStarActive(e){this.starBtn.textContent=e?`★`:`☆`,this.starBtn.classList.toggle(`is-active`,e)}mount(){this.host.isConnected||document.documentElement.appendChild(this.host)}setWidth(e){this.widthPx=Math.max(280,e),this.applyWidth()}setLanguageLabels(e,t){this.sourceLangLabel=e||`源语言`,this.targetLangLabel=t||`译文`,this.sourceLabel.textContent=this.sourceLangLabel,this.zhLabel.textContent=this.targetLangLabel}setFontSize(e){let t=Math.max(10,Math.min(28,e));this.host.style.setProperty(`--lens-zh-size`,`${t+2.5}px`),this.host.style.setProperty(`--lens-en-size`,`${t+.5}px`)}setFontFamily(e){let t={system:`-apple-system, BlinkMacSystemFont, 'SF Pro Text', system-ui, sans-serif`,sans:`Inter, ui-sans-serif, system-ui, sans-serif`,serif:`Georgia, 'Times New Roman', serif`,mono:`'SFMono-Regular', Consolas, 'Liberation Mono', monospace`}[e];this.host.style.setProperty(`--lens-font-family`,t)}setAppearance(e){let t=typeof matchMedia==`function`&&matchMedia(`(prefers-color-scheme: dark)`).matches?`rgba(242, 244, 247, 0.96)`:`rgba(20, 24, 32, 0.94)`;this.host.style.setProperty(`--lens-target-color`,e.pageTranslationUseCustomColor?e.pageTranslationTextColor:t),this.host.style.setProperty(`--lens-target-background`,e.pageTranslationUseBackground?e.pageTranslationBackgroundColor:`transparent`),this.host.style.setProperty(`--lens-target-padding`,e.pageTranslationUseBackground?`6px 8px`:`0`),this.host.style.setProperty(`--lens-target-radius`,e.pageTranslationUseBackground?`4px`:`0`),this.host.style.setProperty(`--lens-target-weight`,e.pageTranslationBold?`700`:`520`),this.host.style.setProperty(`--lens-target-style`,e.pageTranslationItalic?`italic`:`normal`),this.host.style.setProperty(`--lens-target-decoration`,e.pageTranslationUnderline?`underline`:`none`)}showAt(e,t,n){this.mount(),this.panel.style.display=`flex`,this.panel.classList.add(`is-visible`),this.body.classList.remove(`muted`,`pending-anim`),this.sourceBody.classList.remove(`muted`);let r=n.kind===`dict`,i=n.kind===`editable`,a=`sourceText`in n&&n.sourceText?n.sourceText:``,o=n.kind===`ready`?n.text:i&&n.status===`ready`?n.translation:null,s=!!a&&!r;switch(this.sourceLabel.hidden=!s,this.sourceBody.hidden=!s,this.divider.hidden=!s,this.zhLabel.hidden=r||n.kind===`empty`||n.kind===`target-language`||n.kind===`unconfigured`,s?this.sourceBody.textContent=a:this.sourceBody.textContent=``,this.dictCard.hidden=!r,r&&this.renderDictCard(n.entry),this.actionRow.hidden=!(i&&n.status===`ready`&&n.writable&&n.translation),n.kind){case`ready`:this.zhLabel.textContent=this.targetLangLabel,this.body.textContent=n.text;break;case`pending`:this.zhLabel.textContent=this.targetLangLabel,this.body.classList.add(`muted`,`pending-anim`),this.body.textContent=`翻译中…`;break;case`empty`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`此处无可译文本（请移到文字上）`;break;case`target-language`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`此段已是目标语言`;break;case`error`:this.zhLabel.textContent=this.targetLangLabel,this.body.classList.add(`muted`),this.body.textContent=n.message;break;case`unconfigured`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`翻译引擎未就绪，请下载语言包或配置外部 LLM`;break;case`editable`:this.zhLabel.textContent=`回译`,n.status===`pending`?(this.body.classList.add(`muted`,`pending-anim`),this.body.textContent=`回译中…`):n.status===`error`?(this.body.classList.add(`muted`),this.body.textContent=n.error??`回译失败`):this.body.textContent=n.translation??``;break;case`dict`:this.body.textContent=``;break}this.hint.textContent=i?`「替换为译文」会改写输入框全部内容 · Esc 关闭`:`可选择文本复制 · Esc 关闭`,this.starBtn.hidden=!(n.kind===`ready`||r||i&&n.status===`ready`),this.speakSourceBtn.hidden=!a,this.speakTargetBtn.hidden=!o,this.toolbar.hidden=this.starBtn.hidden&&this.speakSourceBtn.hidden&&this.speakTargetBtn.hidden;let c=`sourceRect`in n&&n.sourceRect?n.sourceRect:null;if(c){let r=`${n.kind}:${a.length}:${`text`in n&&n.text?n.text.length:0}:${`message`in n&&n.message?n.message.length:0}:${`translation`in n&&n.translation?n.translation.length:0}:${`entry`in n?n.entry.senses.length*100+n.entry.examples.length*10:0}`,i=`${Math.round(c.left)}|${Math.round(c.top)}|${Math.round(c.right)}|${Math.round(c.bottom)}|${r}`;i!==this.lastSourceKey&&(this.lastSourceKey=i,this.placePanel(e,t,c))}else this.lastSourceKey=``,this.placePanel(e,t,null)}renderDictCard(e){let t=document.createElement(`div`);t.className=`dict-word`,t.textContent=e.word;let n=[t];if(e.phonetic){let n=document.createElement(`span`);n.className=`dict-phonetic`,n.textContent=e.phonetic,t.append(n)}let r=document.createElement(`ol`);r.className=`dict-senses`;for(let t of e.senses){let e=document.createElement(`li`);if(t.pos){let n=document.createElement(`span`);n.className=`dict-pos`,n.textContent=t.pos,e.append(n)}e.append(document.createTextNode(t.gloss)),r.append(e)}if(n.push(r),e.examples.length){let t=document.createElement(`div`);t.className=`dict-examples`;for(let n of e.examples){let e=document.createElement(`div`);e.className=`dict-example`;let r=document.createElement(`div`);r.className=`dict-example-source`,r.textContent=n.source;let i=document.createElement(`div`);i.className=`dict-example-translation`,i.textContent=n.translation,e.append(r,i),t.append(e)}n.push(t)}this.dictCard.replaceChildren(...n)}placePanel(e,t,n){let r=window.innerWidth,i=window.innerHeight,a=this.panel.getBoundingClientRect(),o=Math.max(a.width,this.widthPx),s=Math.max(a.height,80),c=e+16,l=t+16;if(n&&n.width>0){let a=[];a.push({left:j(n.left,8,r-o-8),top:n.bottom+12,score:4}),a.push({left:j(n.left,8,r-o-8),top:n.top-s-12,score:3}),a.push({left:n.right+12,top:j(n.top,8,i-s-8),score:2}),a.push({left:n.left-o-12,top:j(n.top,8,i-s-8),score:1});let u=null;for(let e of a){if(!(e.left>=8&&e.top>=8&&e.left+o<=r-8&&e.top+s<=i-8))continue;let t={left:e.left,top:e.top,right:e.left+o,bottom:e.top+s},a=!(t.right<n.left-4||t.left>n.right+4||t.bottom<n.top-4||t.top>n.bottom+4),c=e.score+(a?-10:0);(!u||c>u.score)&&(u={...e,score:c})}u?(c=u.left,l=u.top):(c=j(e+16,8,r-o-8),l=j(t+16,8,i-s-8),n&&(l=j(n.bottom+12,8,i-s-8)))}else c=j(c,8,r-o-8),l=j(l,8,i-s-8);this.panel.style.left=`${c}px`,this.panel.style.top=`${l}px`}hide(){this.panel.style.display=`none`,this.panel.classList.remove(`is-visible`),this.lastSourceKey=``,this.clearHighlight()}getHost(){return this.host}highlight(e){if(this.highlightEl===e){e&&this.positionRing(e);return}if(this.highlightEl=e,!e){this.ring.style.display=`none`;return}this.positionRing(e)}reposition(){this.highlightEl&&this.positionRing(this.highlightEl)}positionRing(e){if(!e.isConnected){this.ring.style.display=`none`;return}let t=e.getBoundingClientRect(),n=t.bottom<=0||t.right<=0||t.top>=window.innerHeight||t.left>=window.innerWidth;if(t.width<1||t.height<1||n){this.ring.style.display=`none`;return}this.ring.style.display=`block`,this.ring.style.left=`${t.left-3}px`,this.ring.style.top=`${t.top-3}px`,this.ring.style.width=`${t.width+6}px`,this.ring.style.height=`${t.height+6}px`}clearHighlight(){this.highlightEl=null,this.ring.style.display=`none`}};function j(e,t,n){return Math.max(t,Math.min(n,e))}var je=`
  :host, * { box-sizing: border-box; }

  .liquidGlass-wrapper {
    position: fixed;
    display: flex;
    overflow: hidden;
    padding: 0.85rem 1rem;
    border-radius: 14px;
    box-shadow:
      0 10px 32px rgba(15, 23, 42, 0.14),
      0 2px 8px rgba(15, 23, 42, 0.06),
      0 0 0 1px rgba(15, 23, 42, 0.06);
    transition: box-shadow 0.2s ease, transform 0.2s ease;
    font: 16px/1.55 var(--lens-font-family, Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, system-ui, sans-serif);
    -webkit-font-smoothing: antialiased;
    color: rgba(20, 24, 32, 0.94);
  }

  .liquidGlass-wrapper.is-visible {
    animation: glassIn 0.28s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }

  @keyframes glassIn {
    from { opacity: 0; transform: scale(0.96) translateY(4px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
  }

  .liquidGlass-effect {
    position: absolute;
    z-index: 0;
    inset: 0;
    border-radius: inherit;
    backdrop-filter: blur(16px) saturate(140%);
    -webkit-backdrop-filter: blur(16px) saturate(140%);
    isolation: isolate;
  }

  .liquidGlass-tint {
    position: absolute;
    z-index: 1;
    inset: 0;
    border-radius: inherit;
    background: rgba(255, 255, 255, 0.94);
  }

  .liquidGlass-shine {
    position: absolute;
    z-index: 2;
    inset: 0;
    border-radius: inherit;
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.7);
    pointer-events: none;
  }

  .liquidGlass-text {
    position: relative;
    z-index: 3;
    width: 100%;
    min-width: 0;
  }

  .panel {
    flex-direction: column;
    max-height: min(440px, 58vh);
    background: transparent;
    pointer-events: auto;
    user-select: text;
  }

  .panel .body,
  .panel .hint {
    cursor: text;
  }

  .panel .liquidGlass-text {
    overflow: auto;
    max-height: min(420px, 54vh);
  }

  .label {
    font-size: 10.5px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: rgba(91, 100, 114, 0.95);
    margin-bottom: 4px;
  }

  .label-target {
    margin-top: 2px;
  }

  .divider {
    height: 1px;
    margin: 10px 0;
    background: rgba(15, 23, 42, 0.08);
  }

  .body {
    white-space: pre-wrap;
    word-break: break-word;
    font-size: var(--lens-zh-size, 16.5px);
    line-height: 1.55;
    color: rgba(20, 24, 32, 0.94);
    font-weight: 520;
  }

  .body-source {
    font-size: var(--lens-en-size, 14.5px);
    line-height: 1.5;
    color: rgba(91, 100, 114, 0.95);
    font-weight: 450;
  }

  .body-zh,
  .body-target {
    font-size: var(--lens-zh-size, 16.5px);
    color: var(--lens-target-color, rgba(20, 24, 32, 0.94));
    background: var(--lens-target-background, transparent);
    padding: var(--lens-target-padding, 0);
    border-radius: var(--lens-target-radius, 0);
    font-weight: var(--lens-target-weight, 520);
    font-style: var(--lens-target-style, normal);
    text-decoration: var(--lens-target-decoration, none);
  }

  .body.muted {
    color: rgba(91, 100, 114, 0.95);
    font-weight: 400;
  }

  .hint {
    margin-top: 10px;
    font-size: 11.5px;
    color: rgba(139, 147, 160, 0.98);
    line-height: 1.4;
  }

  .toolbar {
    position: absolute;
    top: 6px;
    right: 8px;
    display: flex;
    gap: 2px;
    z-index: 4;
  }

  .icon-btn {
    appearance: none;
    border: 0;
    border-radius: 6px;
    background: transparent;
    padding: 3px 5px;
    font-size: 13px;
    line-height: 1;
    color: rgba(91, 100, 114, 0.95);
    cursor: pointer;
  }
  .icon-btn:hover { background: rgba(15, 23, 42, 0.07); }
  .icon-btn.is-active { color: #d97706; }

  .action-row {
    margin-top: 10px;
    display: flex;
    justify-content: flex-end;
  }

  .action-btn {
    appearance: none;
    border: 0;
    border-radius: 8px;
    background: #2563eb;
    color: #fff;
    font-size: 12.5px;
    font-weight: 600;
    padding: 7px 12px;
    cursor: pointer;
  }
  .action-btn:hover { background: #1d4ed8; }

  .dict-card {
    min-width: 0;
  }
  .dict-word {
    font-size: var(--lens-zh-size, 17px);
    font-weight: 700;
    color: rgba(20, 24, 32, 0.96);
    margin-bottom: 6px;
  }
  .dict-phonetic {
    margin-left: 8px;
    font-size: 12px;
    font-weight: 400;
    color: rgba(91, 100, 114, 0.95);
  }
  .dict-senses {
    margin: 0 0 6px;
    padding-left: 20px;
    font-size: 13.5px;
    line-height: 1.55;
  }
  .dict-senses li { margin-bottom: 2px; }
  .dict-pos {
    display: inline-block;
    margin-right: 6px;
    padding: 0 5px;
    border-radius: 4px;
    background: rgba(37, 99, 235, 0.1);
    color: #1d4ed8;
    font-size: 10.5px;
    font-weight: 700;
    font-style: italic;
  }
  .dict-examples {
    margin-top: 8px;
    border-top: 1px solid rgba(15, 23, 42, 0.08);
    padding-top: 8px;
  }
  .dict-example { margin-bottom: 6px; }
  .dict-example-source {
    font-size: 12.5px;
    color: rgba(20, 24, 32, 0.94);
  }
  .dict-example-translation {
    font-size: 12px;
    color: rgba(91, 100, 114, 0.95);
  }

  .source-outline {
    position: fixed;
    pointer-events: none;
    border-radius: 6px;
    border: 1.5px solid rgba(23, 105, 224, 0.55);
    box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.45);
    background: transparent;
  }

  @keyframes lens-pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
  }

  .pending-anim {
    animation: lens-pulse 1.1s ease-in-out infinite;
  }

  @media (prefers-color-scheme: dark) {
    .liquidGlass-wrapper {
      color: rgba(242, 244, 247, 0.96);
      box-shadow:
        0 12px 36px rgba(0, 0, 0, 0.45),
        0 0 0 1px rgba(255, 255, 255, 0.08);
    }
    .liquidGlass-tint {
      background: rgba(24, 27, 33, 0.94);
    }
    .liquidGlass-shine {
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.06);
    }
    .label { color: rgba(168, 176, 189, 0.95); }
    .divider { background: rgba(255, 255, 255, 0.08); }
    .body { color: rgba(242, 244, 247, 0.96); }
    .body-source { color: rgba(168, 176, 189, 0.95); }
    .body-zh,
    .body-target {
      color: var(--lens-target-color, rgba(242, 244, 247, 0.96));
    }
    .body.muted { color: rgba(168, 176, 189, 0.9); }
    .hint { color: rgba(123, 132, 148, 0.98); }
    .icon-btn { color: rgba(168, 176, 189, 0.95); }
    .icon-btn:hover { background: rgba(255, 255, 255, 0.1); }
    .dict-word { color: rgba(242, 244, 247, 0.96); }
    .dict-phonetic { color: rgba(168, 176, 189, 0.95); }
    .dict-example-source { color: rgba(242, 244, 247, 0.96); }
    .dict-example-translation { color: rgba(168, 176, 189, 0.95); }
    .dict-examples { border-top-color: rgba(255, 255, 255, 0.08); }
    .source-outline {
      border-color: rgba(77, 142, 240, 0.7);
      box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.35);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .liquidGlass-wrapper.is-visible { animation: none; }
    .pending-anim { animation: none; }
  }
`,Me=class{byId=new Map;byUrl=new Map;maxEntries;maxTranslations;constructor(e=300,t=500){this.maxEntries=Math.max(1,e),this.maxTranslations=Math.max(1,t)}upsert(e,t,n){let r=this.byId.get(e);r||this.makeRoom();let i=this.byUrl.get(n),a={id:e,el:t,url:n,status:r?.status??(i?`ready`:`pending`),translation:r?.translation??i,error:r?.error};return a.translation&&(a.error=void 0),this.byId.set(e,a),a}get(e){return this.byId.get(e)}setPending(e){let t=this.byId.get(e);t&&(t.status=`pending`,t.error=void 0)}setTranslation(e,t){let n=this.byId.get(e);if(n){for(this.byUrl.delete(n.url),this.byUrl.set(n.url,t);this.byUrl.size>this.maxTranslations;){let e=this.byUrl.keys().next().value;if(e===void 0)break;this.byUrl.delete(e)}for(let e of this.byId.values())e.url===n.url&&(e.translation=t,e.status=`ready`,e.error=void 0)}}setError(e,t){let n=this.byId.get(e);!n||n.translation||(n.status=`error`,n.error=t)}makeRoom(){if(!(this.byId.size<this.maxEntries)){for(let[e,t]of this.byId)t.el.isConnected||this.byId.delete(e);for(;this.byId.size>=this.maxEntries;){let e=this.byId.keys().next().value;if(e===void 0)break;this.byId.delete(e)}}}};function M(e=location){return`${e.origin}${e.pathname}`}var Ne=class{flush;windowMs;pending=new Map;timer=null;constructor(e,t=80){this.flush=e,this.windowMs=t}enqueue(e){this.pending.set(e.id,e),this.timer===null&&(this.timer=setTimeout(()=>{this.timer=null;let e=[...this.pending.values()];this.pending.clear(),e.length&&this.flush(e)},this.windowMs))}},N=`lens-page-alignment-match`,P=`data-lens-page-alignment-source`,Pe=`[data-lens-page-translated]`,Fe=`lens-translator-page-alignment-overlay`;function Ie(e){let t=[];for(let n of e.matchAll(/\p{Script=Han}|[\p{L}\p{M}\p{N}_'-]+/gu)){let e=n.index;t.push({text:n[0],start:e,end:e+n[0].length})}return t}function F(e,t){if(typeof Intl.Segmenter!=`function`)return Ie(e);let n=new Intl.Segmenter(t,{granularity:`word`}),r=[];for(let t of n.segment(e))t.isWordLike&&r.push({text:t.segment,start:t.index,end:t.index+t.segment.length});return r}function Le(e,t){let n=F(e,t),r=[],i=0;for(let t=0;t<n.length;t++){let a=n[t];a.start>i&&r.push({text:e.slice(i,a.start),start:i,end:a.start,wordIndex:null}),r.push({...a,wordIndex:t}),i=a.end}return i<e.length&&r.push({text:e.slice(i),start:i,end:e.length,wordIndex:null}),r}function Re(e){return e.normalize(`NFKD`).replace(/\p{M}/gu,``).toLocaleLowerCase().replace(/[^\p{L}\p{N}]/gu,``)}function ze(e,t){let n=Array.from({length:t.length+1},(e,t)=>t);for(let r=1;r<=e.length;r++){let i=n[0];n[0]=r;for(let a=1;a<=t.length;a++){let o=n[a];n[a]=Math.min(n[a]+1,n[a-1]+1,i+(e[r-1]===t[a-1]?0:1)),i=o}}return n[t.length]}function I(e,t){if(!e||!t)return 0;if(e===t)return 1;let n=Math.min(e.length,t.length),r=Math.max(e.length,t.length);return n>=3&&(e.includes(t)||t.includes(e))?Math.min(.9,.2+n/r):Math.max(0,1-ze(e,t)/r)}function Be(e,t,n){if(!e.length)return null;let r=(t+.5)/Math.max(1,n),i=Math.min(e.length-1,Math.floor(r*e.length));return{start:e[i].start,end:e[i].end}}function L(e,t,n,r,i){let a=F(e,i),o=Be(a,n,r),s=F(t,i).map(e=>Re(e.text)).filter(Boolean);if(!a.length||!s.length)return o;let c=a.map(e=>Re(e.text)),l=(n+.5)/Math.max(1,r),u=Math.max(1,s.length-1),d=Math.min(a.length,s.length+2),f=null;for(let e=u;e<=d;e++)for(let t=0;t+e<=a.length;t++){let n=c.slice(t,t+e),r=s.reduce((e,t)=>e+Math.max(...n.map(e=>I(t,e))),0)/s.length,i=n.reduce((e,t)=>e+Math.max(...s.map(e=>I(e,t))),0)/n.length,o=r*.7+i*.3,u=(t+e/2)/a.length,d=Math.max(0,1-Math.abs(u-l)),p=o*.82+d*.18;(!f||p>f.score)&&(f={lexical:o,score:p,start:t,end:t+e})}return!f||f.lexical<.34?o:{start:a[f.start].start,end:a[f.end-1].end}}function Ve(e){let t=[],n=[],r=``,i=null,a=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),o=a.nextNode(),s=(e,i,a)=>{r+=e;for(let r=0;r<e.length;r++)t.push(i),n.push(a)};for(;o;){let e=o.data;for(let t=0;t<e.length;){let n=e.codePointAt(t),a=String.fromCodePoint(n),c=a.length;/\s/u.test(a)?r&&!i&&(i={node:o,offset:t}):(i&&=(s(` `,i,{node:i.node,offset:i.offset+1}),null),s(a,{node:o,offset:t},{node:o,offset:t+c})),t+=c}o=a.nextNode()}return{text:r,starts:t,ends:n}}function He(e,t){let{host:n,sourceText:r}=e,i=e.textIndex;if((!i||i.text!==a(r))&&(i=Ve(n),e.textIndex=i,i.text!==a(r))||t.start<0||t.end>i.text.length)return null;let o=i.starts[t.start],s=i.ends[t.end-1];if(!o||!s)return null;let c=document.createRange();return c.setStart(o.node,o.offset),c.setEnd(s.node,s.offset),c}function R(e){let t=Number.parseFloat(e);return Number.isFinite(t)?t:0}var Ue=class{entries=new WeakMap;translator=new u;overlay=null;overlayHost=null;overlayWords=new Map;hovered=null;hoveredText=``;highlightedHost=null;starBtn=null;starContext=null;onWordStar=null;alignmentTimer=0;active=!1;pointerFrame=0;pendingPointer=null;measuredHost=null;measuredTranslationTop=0;measuredHostTop=0;measuredPseudoStyle=null;activate(){this.active||(this.active=!0,document.addEventListener(`pointermove`,this.onPointerMove,!0),window.addEventListener(`scroll`,this.onViewportChange,!0),window.addEventListener(`resize`,this.onViewportChange))}deactivate(){this.active=!1,document.removeEventListener(`pointermove`,this.onPointerMove,!0),window.removeEventListener(`scroll`,this.onViewportChange,!0),window.removeEventListener(`resize`,this.onViewportChange),this.pointerFrame&&window.cancelAnimationFrame(this.pointerFrame),this.pointerFrame=0,this.pendingPointer=null,this.clearInteraction(),this.entries=new WeakMap}register(e,t,n,r,i,a){let o=Le(n,i);this.entries.set(e,{host:e,sourceText:t,translation:n,sourceLanguage:r,targetLanguage:i,isUi:a,segments:o,wordCount:o.filter(e=>e.wordIndex!==null).length,alignments:new Map,textIndex:null})}unregister(e){this.entries.delete(e),(this.overlayHost===e||this.highlightedHost===e)&&this.clearInteraction()}onViewportChange=()=>this.clearInteraction();onPointerMove=e=>{this.pendingPointer=e,!this.pointerFrame&&(this.pointerFrame=window.requestAnimationFrame(()=>{this.pointerFrame=0;let e=this.pendingPointer;this.pendingPointer=null,e&&this.active&&this.handlePointerMove(e)}))};handlePointerMove(e){let t=e.composedPath().find(e=>e instanceof Element)?.closest(Pe)??null,n=t?this.entries.get(t):void 0;if(!t||!n||n.isUi||!t.isConnected){this.clearInteraction();return}let r=t.getBoundingClientRect().top;if(t!==this.measuredHost||!this.measuredPseudoStyle||r!==this.measuredHostTop){let e=window.getComputedStyle(t,`::after`);this.measuredHost=t,this.measuredPseudoStyle=e,this.measuredHostTop=r,this.measuredTranslationTop=this.sourceContentBottom(t)+R(e.marginTop)}let i=this.measuredTranslationTop,a=this.measuredPseudoStyle;if(e.clientY<i){this.clearInteraction();return}this.ensureOverlay(n,i,a);let o=this.overlay?.getBoundingClientRect();if(!o||e.clientX<o.left||e.clientX>o.right||e.clientY<o.top||e.clientY>o.bottom){this.clearInteraction();return}let s=this.segmentAtPoint(e.clientX,e.clientY,n);if(s?.wordIndex===null||s===void 0){window.clearTimeout(this.alignmentTimer),this.clearHighlight(),this.hovered=null,this.hoveredText=``;return}if(this.hovered?.host===t&&this.hovered.wordIndex===s.wordIndex)return;this.hovered={host:t,wordIndex:s.wordIndex},this.hoveredText=s.text;let c=L(n.sourceText,``,s.wordIndex,n.wordCount,n.sourceLanguage);c&&this.highlight(n,c),window.clearTimeout(this.alignmentTimer);let l=n.alignments.get(s.wordIndex);if(l){this.applyAlignmentWhenCurrent(l,t,s.wordIndex,n);return}this.alignmentTimer=window.setTimeout(()=>{if(this.hovered?.host!==t||this.hovered.wordIndex!==s.wordIndex)return;let e=this.alignSegment(n,s);n.alignments.set(s.wordIndex,e),this.applyAlignmentWhenCurrent(e,t,s.wordIndex,n)},160)}applyAlignmentWhenCurrent(e,t,n,r){e.then(e=>{!e||!this.active||this.hovered?.host!==t||this.hovered.wordIndex!==n||this.highlight(r,e)})}reverseReady=new Map;reversePairReady(e,t){let n=`${e}\0${t}`,r=this.reverseReady.get(n);return r||(r=this.translator.availability(e,t).then(e=>e===`available`).catch(()=>!1),this.reverseReady.set(n,r)),r}alignSegment(e,t){let n=L(e.sourceText,``,t.wordIndex??0,e.wordCount,e.sourceLanguage);return this.translator.isSupported()?this.reversePairReady(e.targetLanguage,e.sourceLanguage).then(async r=>{if(!r)return n;let i=await this.translator.translate(t.text,e.targetLanguage,e.sourceLanguage);return L(e.sourceText,i??``,t.wordIndex??0,e.wordCount,e.sourceLanguage)}):Promise.resolve(n)}ensureOverlay(e,t,n){if(this.overlay||(this.overlay=document.createElement(`div`),this.overlay.id=Fe,this.overlay.setAttribute(`data-lens-ignore`,``),document.documentElement.append(this.overlay)),this.overlayHost!==e.host){this.overlay.replaceChildren(),this.overlayWords.clear();for(let t of e.segments){if(t.wordIndex===null){this.overlay.append(document.createTextNode(t.text));continue}let e=document.createElement(`span`);e.textContent=t.text,this.overlayWords.set(t.wordIndex,e),this.overlay.append(e)}this.overlayHost=e.host}let r=e.host.getBoundingClientRect(),i=window.getComputedStyle(e.host),a=r.left+R(i.borderLeftWidth)+R(i.paddingLeft),o=Math.max(1,r.width-R(i.borderLeftWidth)-R(i.borderRightWidth)-R(i.paddingLeft)-R(i.paddingRight)),s=this.overlay.style;s.all=`initial`,s.position=`fixed`,s.zIndex=`2147483646`,s.pointerEvents=`none`,s.boxSizing=`border-box`,s.left=`${a}px`,s.top=`${t}px`,s.width=`${o}px`,s.margin=`0`,s.padding=n.padding,s.border=`0`,s.background=`transparent`,s.color=`transparent`,s.fontFamily=n.fontFamily,s.fontSize=n.fontSize,s.fontStyle=n.fontStyle,s.fontWeight=n.fontWeight,s.lineHeight=n.lineHeight,s.letterSpacing=n.letterSpacing,s.wordSpacing=n.wordSpacing,s.textAlign=n.textAlign,s.whiteSpace=n.whiteSpace,s.overflowWrap=n.overflowWrap,s.direction=n.direction}sourceContentBottom(e){let t=document.createRange();t.selectNodeContents(e);let n=[...t.getClientRects()];return t.detach(),n.reduce((e,t)=>Math.max(e,t.bottom),e.getBoundingClientRect().top)}segmentAtPoint(e,t,n){for(let r of n.segments){if(r.wordIndex===null)continue;let n=this.overlayWords.get(r.wordIndex);if(n){for(let i of n.getClientRects())if(e>=i.left-1&&e<=i.right+1&&t>=i.top&&t<=i.bottom)return r}}}highlight(e,t){let n=He(e,t);if(!n)return;this.clearHighlight();let r=globalThis.CSS?.highlights,i=globalThis.Highlight;r&&i?r.set(N,new i(n)):e.host.setAttribute(P,``),this.highlightedHost=e.host,this.showWordStar(e,t,n)}showWordStar(e,t,n){if(!this.onWordStar)return;let r=e.sourceText.slice(t.start,t.end).trim(),i=this.hoveredText.trim();if(!r||!i)return;this.starContext={source:r,translation:i,sourceLang:e.sourceLanguage,targetLang:e.targetLanguage},this.starBtn||(this.starBtn=document.createElement(`button`),this.starBtn.type=`button`,this.starBtn.id=`lens-translator-alignment-star`,this.starBtn.setAttribute(`data-lens-ignore`,``),this.starBtn.title=`收藏到生词本`,Object.assign(this.starBtn.style,{all:`initial`,position:`fixed`,zIndex:`2147483647`,padding:`2px 6px`,border:`1px solid rgb(15 23 42 / 18%)`,borderRadius:`6px`,background:`rgb(255 255 255 / 97%)`,boxShadow:`0 4px 12px rgb(15 23 42 / 18%)`,color:`#b45309`,font:`13px/1.2 system-ui, sans-serif`,cursor:`pointer`}),this.starBtn.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),this.starBtn&&this.starContext&&(this.onWordStar?.(this.starContext),this.starBtn.textContent=`★`)})),this.starBtn.textContent=`☆`,this.starBtn.isConnected||document.documentElement.append(this.starBtn);let a=n.getBoundingClientRect(),o=Math.min(Math.max(4,a.left),window.innerWidth-34),s=a.top>34?a.top-28:a.bottom+6;this.starBtn.style.left=`${o}px`,this.starBtn.style.top=`${Math.max(4,s)}px`}clearHighlight(){(globalThis.CSS?.highlights)?.delete(N),this.highlightedHost?.removeAttribute(P),this.highlightedHost=null}clearInteraction(){window.clearTimeout(this.alignmentTimer),this.clearHighlight(),this.hovered=null,this.hoveredText=``,this.starBtn?.remove(),this.starContext=null,this.measuredHost=null,this.measuredPseudoStyle=null,this.measuredTranslationTop=0,this.overlay?.remove(),this.overlay=null,this.overlayHost=null,this.overlayWords.clear()}},z=`data-lens-page-translated`,B=`data-lens-page-translation-text`,V=`data-lens-page-pending`,H=`data-lens-page-ui-pending`,U=`data-lens-page-ui-translation`,W=`data-lens-page-ui-stacked-translation`,G=`data-lens-page-ui-control-translation`,K=`lens-translator-page-style`,q=`lens-translator-page-status`,We=3,Ge=5e3,Ke=6,qe=8e3,Je=600,Ye=2,Xe=2e3;function Ze(e){let t=e.pageTranslationUseCustomColor?e.pageTranslationTextColor:`inherit`,n=e.pageTranslationUseBackground?e.pageTranslationBackgroundColor:`transparent`,r=e.pageTranslationUseBackground?`0.3em 0.5em`:`0`,i=e.pageTranslationUseBackground?`4px`:`0`,a=e.pageTranslationUseCustomColor||e.pageTranslationUseBackground?`1`:`0.78`;return`
[${z}]::after {
  content: attr(${B}) !important;
  display: block !important;
  box-sizing: border-box !important;
  margin: 0.24em 0 0.1em !important;
  padding: ${r} !important;
  border: 0 !important;
  border-radius: ${i} !important;
  background: ${n} !important;
  color: ${t} !important;
  font-family: ${{system:`inherit`,sans:`Inter, ui-sans-serif, system-ui, sans-serif`,serif:`Georgia, "Times New Roman", serif`,mono:`"SFMono-Regular", Consolas, "Liberation Mono", monospace`}[e.pageTranslationFontFamily]} !important;
  font-size: ${e.pageTranslationFontSizePx}px !important;
  font-style: ${e.pageTranslationItalic?`italic`:`normal`} !important;
  font-weight: ${e.pageTranslationBold?`700`:`400`} !important;
  line-height: 1.45 !important;
  letter-spacing: 0 !important;
  overflow-wrap: anywhere !important;
  text-align: start !important;
  text-decoration: ${e.pageTranslationUnderline?`underline`:`none`} !important;
  text-transform: none !important;
  unicode-bidi: plaintext !important;
  white-space: pre-wrap !important;
  opacity: ${a} !important;
}

[${z}][${U}]::after {
  content: " · " attr(${B}) !important;
  display: inline-block !important;
  vertical-align: baseline !important;
  margin: 0 0 0 0.32em !important;
  padding: 0 !important;
  border: 0 !important;
  background: transparent !important;
  color: inherit !important;
  font-size: 0.68em !important;
  font-style: normal !important;
  font-weight: 400 !important;
  line-height: inherit !important;
  text-decoration: none !important;
  white-space: normal !important;
  opacity: 0.62 !important;
}

[${z}][${U}][${W}]::after {
  content: attr(${B}) !important;
  display: block !important;
  margin: 0.12em 0 0 !important;
  font-size: 0.58em !important;
  line-height: 1.15 !important;
  white-space: normal !important;
}

[${z}][${U}][${G}]::after {
  content: " · " attr(${B}) !important;
  display: inline-block !important;
  vertical-align: baseline !important;
  margin-left: 0.3em !important;
  font-size: 0.7em !important;
  line-height: inherit !important;
  white-space: nowrap !important;
}

::highlight(${N}) {
  background: rgb(250 204 21 / 52%);
  color: inherit;
  text-decoration: underline;
  text-decoration-color: rgb(202 138 4 / 80%);
  text-decoration-thickness: 2px;
}

/* Pending LLM translation: shimmer placeholder where the translation will land. */
@keyframes lens-translator-pending-shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

[${V}]::after {
  content: '' !important;
  display: block !important;
  box-sizing: border-box !important;
  margin: 0.24em 0 0.1em !important;
  width: min(420px, 68%) !important;
  height: 1.05em !important;
  border: 0 !important;
  border-radius: 4px !important;
  background: linear-gradient(90deg, rgb(148 163 184 / 14%) 25%, rgb(148 163 184 / 32%) 50%, rgb(148 163 184 / 14%) 75%) !important;
  background-size: 200% 100% !important;
  animation: lens-translator-pending-shimmer 1.4s linear infinite !important;
}

[${V}][${H}]::after {
  display: inline-block !important;
  vertical-align: baseline !important;
  width: 2.8em !important;
  height: 0.8em !important;
  margin: 0 0 0 0.32em !important;
}

@media (prefers-reduced-motion: reduce) {
  [${V}]::after {
    animation: none !important;
  }
}

[${P}] {
  background-color: rgb(250 204 21 / 22%) !important;
}
${e.pageTranslationDisplayMode===`translation-only`?`
/* Translation-only: collapse the original text (font-size cascades; media and
   explicitly-sized children are unaffected), keep translations readable. */
[${z}] {
  font-size: 0 !important;
  letter-spacing: 0 !important;
}
[${z}]::after,
[${z}][${U}]::after,
[${z}][${U}][${W}]::after,
[${z}][${U}][${G}]::after {
  font-size: ${e.pageTranslationFontSizePx}px !important;
}
`:``}${e.pageTranslationDisplayMode===`learning`?`
/* Learning mode: translations stay blurred until hovered — read the original
   first, peek only when stuck. */
[${z}]::after {
  filter: blur(5px) !important;
  opacity: 0.35 !important;
  transition: filter 0.15s ease, opacity 0.15s ease !important;
}
[${z}]:hover::after {
  filter: none !important;
  opacity: 1 !important;
}
`:``}

#${q} {
  position: fixed !important;
  z-index: 2147483647 !important;
  top: 16px !important;
  right: 16px !important;
  max-width: min(360px, calc(100vw - 32px)) !important;
  padding: 9px 12px !important;
  border: 1px solid rgb(15 23 42 / 14%) !important;
  border-radius: 7px !important;
  background: rgb(255 255 255 / 96%) !important;
  box-shadow: 0 8px 24px rgb(15 23 42 / 16%) !important;
  color: #172033 !important;
  font: 500 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif !important;
  letter-spacing: 0 !important;
}

#${q}[data-error="true"] {
  border-color: rgb(185 28 28 / 24%) !important;
  color: #991b1b !important;
}

@media (prefers-color-scheme: dark) {
  #${q} {
    border-color: rgb(255 255 255 / 16%) !important;
    background: rgb(24 24 27 / 96%) !important;
    color: #f4f4f5 !important;
  }
  #${q}[data-error="true"] { color: #fca5a5 !important; }
}
`}function Qe(e){return!!(e&&typeof e==`object`&&`id`in e&&typeof e.id==`string`&&`translation`in e&&typeof e.translation==`string`)}function $e(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-batch-result`||typeof e.ok!=`boolean`||`translations`in e&&e.translations!==void 0&&(!Array.isArray(e.translations)||!e.translations.every(Qe))?!1:e.ok?`translations`in e&&Array.isArray(e.translations):`error`in e&&typeof e.error==`string`}function et(e){let t=[...e].sort((e,t)=>e.el===t.el?0:e.el.compareDocumentPosition(t.el)&4?-1:1),n=[],r=[];for(let e of t)y(e.el,0)?n.push(e):r.push(e);let i=[...n,...r],o=new Map;for(let e of i){let t=a(e.text),n=o.get(t);if(n){n.blocks.push(e);continue}o.set(t,{representative:{id:e.id,tag:e.tag,text:t},blocks:[e]})}return[...o.values()]}var tt=`nav, [role="navigation"], [role="banner"], [role="menu"], [role="tablist"], [role="search"], [role="toolbar"]`,nt=`button, [role="button"], [role="tab"], [role="menuitem"], [role="menuitemradio"], [role="option"]`,rt=`[role="grid"], [role="treegrid"], [class*="ContributionCalendar"], .js-calendar-graph, .contrib-legend, [class*="ContributionCalendar"] [data-level], .js-calendar-graph [data-level]`,it=/^(?:mon|tue|tues|wed|weds|thu|thur|thurs|fri|sat|sun|monday|tuesday|wednesday|thursday|friday|saturday|sunday|jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|january|february|march|april|june|july|august|september|october|november|december)$/i;function at(e){return it.test(a(e))}function J(e){return!!(T(e.el)||e.el.closest(tt)||e.el.closest(nt))}function ot(e){if(e.el.closest(`button, [role="button"]`))return!0;let t=`${e.el.getAttribute(`class`)??``} ${e.el.getAttribute(`data-testid`)??``}`;return/(?:^|[\s_-])(?:button|btn|submit)(?:$|[\s_-])/iu.test(t)}function st(e){if(!J(e))return e.el;let t=a(e.text),n=e.el;for(let r of e.el.querySelectorAll(`*`)){let e=r.tagName.toLowerCase();e===`svg`||e===`path`||e===`img`||a(x(r))===t&&(n=r)}return n}function ct(e,t){let{el:n,text:r}=e;if(n.closest(`time`)||n.closest(rt)||at(r))return!1;let i=J(e);if(i&&/@[\p{L}\p{N}_-]+/u.test(r)||!c(r,i?Math.min(2,t):t))return!1;if(i)return!0;if(T(n))return!1;let o=n.closest(`a, [role="link"]`);return!(o&&r.length<=48&&a(x(o))===a(r))}var lt=class{browserTranslator;active=!1;generation=0;statusTimer=0;mutationTimer=0;initialRetryTimer=0;anchorFrame=0;pendingAnchor=null;activationDeadline=0;processingGeneration=0;rescanRequested=!1;observer=null;observedRoots=new WeakSet;currentSettings=null;dirtyRoots=new Set;translatedHosts=new Set;pendingHosts=new Set;sourceHosts=new Map;attemptedTextByHost=new WeakMap;sourceBlockByHost=new WeakMap;volatileHosts=new WeakSet;hostChurn=new WeakMap;translationCache=new Map;retryAttempts=0;processedCount=0;translatedCount=0;totalCount=0;forceRefresh=!1;alignment=new Ue;constructor(e){this.browserTranslator=e}isActive(){return this.active}setWordStarHandler(e){this.alignment.onWordStar=e}async toggle(e,t){if(this.active){this.deactivate();return}await this.activate(e,t)}deactivate(){this.scheduleScrollAnchorRestore(),this.active=!1,this.generation++,this.observer?.disconnect(),this.observer=null,this.alignment.deactivate(),this.observedRoots=new WeakSet,this.lastStatusText=``,this.progressTick=0,window.clearTimeout(this.statusTimer),window.clearTimeout(this.mutationTimer),window.clearTimeout(this.initialRetryTimer);for(let e of this.translatedHosts)e.removeAttribute(z),e.removeAttribute(B),e.removeAttribute(U),e.removeAttribute(W),e.removeAttribute(G);for(let e of this.pendingHosts)e.removeAttribute(V),e.removeAttribute(H);this.pendingHosts.clear();for(let[e,t]of this.sourceHosts)t===null?e.removeAttribute(m):e.setAttribute(m,t);this.translatedHosts.clear(),this.sourceHosts.clear(),this.attemptedTextByHost=new WeakMap,this.sourceBlockByHost=new WeakMap,this.volatileHosts=new WeakSet,this.hostChurn=new WeakMap,this.translationCache.clear(),this.retryAttempts=0,this.dirtyRoots.clear(),this.currentSettings=null,this.forceRefresh=!1,this.processingGeneration=0,this.rescanRequested=!1,document.getElementById(q)?.remove(),document.getElementById(K)?.remove()}async refresh(e,t){this.deactivate(),await this.activate(e,t,{forceRefresh:!0})}restyle(e){this.active&&(this.scheduleScrollAnchorRestore(),this.currentSettings=e,this.ensureStyles(e))}async activate(e,t,n){window.clearTimeout(this.statusTimer),this.active=!0,this.forceRefresh=n?.forceRefresh===!0;let r=++this.generation;if(this.currentSettings=e,this.ensureStyles(e),e.pageTranslationEngine===`external`&&!t){this.failActivation(`整页翻译需要先配置外部 API`);return}if(e.pageTranslationEngine===`browser`){let t=await this.browserTranslator.availability(e.sourceLang,e.targetLang);if(t===`unsupported`){this.failActivation(`当前浏览器不支持 Chrome 内置翻译`);return}if(t===`unavailable`){this.failActivation(`Chrome 内置翻译不支持当前语言对`);return}}this.alignment.activate(),this.startObserving(),this.activationDeadline=Date.now()+qe,await this.scanAndTranslate(e,r,!0)}async scanAndTranslate(e,t,n=!1){if(this.isCurrent(t)){if(this.processingGeneration===t){this.rescanRequested=!0;return}if(this.processingGeneration===0){this.processingGeneration=t,window.clearTimeout(this.statusTimer);try{let r=n?[document]:[...this.dirtyRoots];this.dirtyRoots.clear(),this.observePageRoots(r),this.cleanupDisconnectedHosts(),n&&this.showStatus(`正在分析页面文本…`);let i=new Map;for(let t of r)if(!(t!==document&&t instanceof Node&&!t.isConnected))for(let n of we(e.minTextLength,t))i.set(n.el,n);let a=et([...i.values()].filter(t=>this.volatileHosts.has(t.el)||!ct(t,e.minTextLength)||o(t.text,e.targetLang)||this.translatedHosts.has(t.el)?!1:this.attemptedTextByHost.get(t.el)!==t.text));if(this.totalCount=a.reduce((e,t)=>e+t.blocks.length,0),this.processedCount=0,this.translatedCount=0,!a.length){n&&this.translatedHosts.size===0?Date.now()<this.activationDeadline?(this.showStatus(`正在等待页面内容加载…`),this.scheduleInitialRetry(t)):this.failActivation(`当前页面没有可翻译文本`):document.getElementById(q)?.remove();return}n||this.showStatus(`检测到新内容，正在翻译…`);for(let e of a)for(let t of e.blocks)this.attemptedTextByHost.set(t.el,t.text);this.updateProgress();let s=[];for(let t of a){let n=this.translationCache.get(t.representative.text);n?(this.renderGroup(t,n,e),this.processedCount+=t.blocks.length):s.push(t)}this.updateProgress();let c=null;if(s.length)try{e.pageTranslationEngine===`browser`?await this.translateWithBrowser(s,e,t):await this.translateWithExternal(s,e,t)}catch(e){c=e instanceof Error?e.message:String(e)}if(!this.isCurrent(t))return;if(n&&this.translatedCount===0&&this.translatedHosts.size===0){this.failActivation(c??`整页翻译失败，当前语言对可能不可用`);return}let l=a.filter(e=>!this.translationCache.has(e.representative.text)),u=!1;if(l.length===0)this.retryAttempts=0;else if(this.retryAttempts<Ye){this.retryAttempts++;for(let e of l)for(let t of e.blocks)this.attemptedTextByHost.delete(t.el);this.dirtyRoots.add(document),this.scheduleScan(Xe*this.retryAttempts),u=!0}let d=this.totalCount-this.translatedCount;u?(this.showStatus(`翻译完成：${this.translatedCount} 段，${d} 段失败，稍后自动重试…`),this.scheduleStatusRemoval(Xe*this.retryAttempts+1500)):d>0?(this.showStatus(c?`整页翻译部分失败：${c}`:`翻译完成：${this.translatedCount} 段成功，${d} 段失败`,!0),this.scheduleStatusRemoval(5e3)):(this.showStatus(`翻译完成：${this.translatedCount} 段`),this.scheduleStatusRemoval())}catch(e){if(!this.isCurrent(t))return;let r=e instanceof Error?e.message:String(e);n&&this.translatedHosts.size===0?this.failActivation(r):(this.showStatus(`整页翻译部分失败：${r}`,!0),this.scheduleStatusRemoval(5e3))}finally{if(this.processingGeneration!==t)return;this.processingGeneration=0,this.rescanRequested&&this.isCurrent(t)&&(this.rescanRequested=!1,this.scheduleScan(0))}}}}async translateWithBrowser(e,t,n){let r=await this.browserTranslator.prepare(t.sourceLang,t.targetLang);if(this.isCurrent(n)){if(!r)throw Error(`Chrome 内置翻译不支持当前语言对`);for(let r of e){if(!this.isCurrent(n))return;let e=await this.browserTranslator.translate(r.representative.text,t.sourceLang,t.targetLang);if(!this.isCurrent(n))return;e&&this.renderGroup(r,e,t),this.processedCount+=r.blocks.length,this.updateProgress()}}}async translateWithExternal(e,t,n){let r=M(),i=null;this.scheduleScrollAnchorRestore();for(let t of e)this.markGroupPending(t);if(await p(e,Ke,async e=>{if(!this.isCurrent(n))return;let a=!1;try{let o=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:r,blocks:[e.representative],sourceLang:t.sourceLang,targetLang:t.targetLang,...this.forceRefresh?{forceRefresh:!0}:{}});if(!this.isCurrent(n))return;if(!$e(o))throw Error(`翻译服务未返回有效结果`);let s=o.translations?.find(t=>t.id===e.representative.id);s&&(this.renderGroup(e,s.translation,t),a=!0),!o.ok&&i===null&&(i=o.error)}catch(e){i===null&&(i=e instanceof Error?e.message:String(e))}finally{a||this.clearGroupPending(e)}this.isCurrent(n)&&(this.processedCount+=e.blocks.length,this.updateProgress())}),this.isCurrent(n)&&i!==null&&e.some(e=>!this.translationCache.has(e.representative.text)))throw Error(i)}hostForBlock(e){let t=J(e);return{isUi:t,host:t?st(e):e.el}}markGroupPending(e){for(let t of e.blocks){if(!t.el.isConnected)continue;let{host:e,isUi:n}=this.hostForBlock(t);this.translatedHosts.has(e)||(e.setAttribute(V,``),n&&e.setAttribute(H,``),this.pendingHosts.add(e))}}clearHostPending(e){this.pendingHosts.delete(e)&&(e.removeAttribute(V),e.removeAttribute(H))}clearGroupPending(e){for(let t of e.blocks)t.el.isConnected&&this.clearHostPending(this.hostForBlock(t).host)}renderGroup(e,t,n){this.scheduleScrollAnchorRestore(),this.translationCache.set(e.representative.text,t);for(let r of e.blocks){if(!r.el.isConnected)continue;let{host:e,isUi:i}=this.hostForBlock(r);if(this.clearHostPending(e),!this.translatedHosts.has(e)){if(this.sourceHosts.has(e)||(this.sourceHosts.set(e,e.getAttribute(m)),e.setAttribute(m,r.text)),e.setAttribute(z,``),e.setAttribute(B,t),i)if(e.setAttribute(U,``),ot(r))e.setAttribute(G,``);else{let t=window.getComputedStyle(e).display;!t.includes(`flex`)&&!t.includes(`grid`)&&e.setAttribute(W,``)}this.translatedHosts.add(e),this.sourceBlockByHost.set(e,r.el),this.alignment.register(e,r.text,t,n.sourceLang,n.targetLang,J(r)),this.translatedCount++}}}startObserving(){this.observer?.disconnect(),this.observedRoots=new WeakSet,this.observer=new MutationObserver(e=>this.onMutations(e)),this.observePageRoots([document])}observePageRoots(e){if(this.observer)for(let t of e)for(let e of k(t)){let t=e===document?document.documentElement:e;this.observedRoots.has(t)||(this.observer.observe(t,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:[`class`,`style`,`hidden`,`aria-hidden`,`open`]}),this.observedRoots.add(t))}}onMutations(e){let t=!1;for(let n of e){let e=n.target.nodeType===1?n.target:n.target.parentElement;if(!e||e.closest(`[data-lens-ignore]`)||n.type===`attributes`&&(e===document.body||e===document.documentElement)&&(n.attributeName===`class`||n.attributeName===`style`)||n.type===`characterData`&&e.closest(`[contenteditable]:not([contenteditable="false"]), textarea, input`))continue;if(n.type===`childList`){let e=[...n.addedNodes,...n.removedNodes];if(e.length>0&&e.every(e=>this.isOwnNode(e)))continue}let r=e.closest(`[${z}]`);if(!(r&&n.type===`attributes`)){if(r){let e=r.getAttribute(`data-lens-translator-source`)??``;if(a(x(r))===e)continue;if(this.markChurnAndMaybeVolatile(r)){this.invalidateHost(r);continue}this.invalidateHost(r),this.dirtyRoots.add(r.parentElement??r),t=!0;continue}this.dirtyRoots.add(e.parentElement??e),t=!0}}t&&this.scheduleScan()}markChurnAndMaybeVolatile(e){let t=Date.now(),n=this.hostChurn.get(e);if(!n||t-n.since>Ge)return this.hostChurn.set(e,{count:1,since:t}),!1;if(n.count++,n.count<We)return!1;this.volatileHosts.add(e);let r=this.sourceBlockByHost.get(e);return r&&this.volatileHosts.add(r),!0}isOwnNode(e){return e.nodeType===1&&(e.hasAttribute(`data-lens-ignore`)||e.id===K||e.id===q)}invalidateHost(e){this.alignment.unregister(e),e.removeAttribute(z),e.removeAttribute(B),e.removeAttribute(U),e.removeAttribute(W),e.removeAttribute(G),this.translatedHosts.delete(e);let t=this.sourceHosts.get(e);t===null?e.removeAttribute(m):t!==void 0&&e.setAttribute(m,t),this.sourceHosts.delete(e),this.attemptedTextByHost.delete(this.sourceBlockByHost.get(e)??e),this.sourceBlockByHost.delete(e)}cleanupDisconnectedHosts(){for(let e of this.translatedHosts)e.isConnected||this.invalidateHost(e);for(let e of this.pendingHosts)e.isConnected||this.clearHostPending(e)}scheduleScan(e=250){window.clearTimeout(this.mutationTimer),this.mutationTimer=window.setTimeout(()=>{!this.active||!this.currentSettings||this.scanAndTranslate(this.currentSettings,this.generation)},e)}scheduleInitialRetry(e){window.clearTimeout(this.initialRetryTimer),this.initialRetryTimer=window.setTimeout(()=>{!this.isCurrent(e)||!this.currentSettings||this.scanAndTranslate(this.currentSettings,e,!0)},Je)}isCurrent(e){return this.active&&e===this.generation}scheduleScrollAnchorRestore(){(!this.pendingAnchor||Date.now()-this.pendingAnchor.at>1e3)&&(this.pendingAnchor=this.captureScrollAnchor()),!(!this.pendingAnchor||this.anchorFrame)&&(this.anchorFrame=window.requestAnimationFrame(()=>{this.anchorFrame=0;let e=this.pendingAnchor;if(this.pendingAnchor=null,!e||!e.el.isConnected||Date.now()-e.at>1e3)return;let t=e.el.getBoundingClientRect().top-e.top;if(Math.abs(t)<=1)return;let n=this.scrollContainerOf(e.el);n?n.scrollBy({top:t,left:0,behavior:`instant`}):window.scrollBy({top:t,left:0,behavior:`instant`})}))}captureScrollAnchor(){if(typeof document.elementsFromPoint!=`function`)return null;let e=Math.round(window.innerWidth/2),t=Math.min(window.innerHeight,480);for(let n=1;n<=t;n+=24)for(let t of document.elementsFromPoint(e,n)){if(t===document.body||t===document.documentElement||t.closest(`[data-lens-ignore]`))continue;let e=window.getComputedStyle(t).position;if(!(e===`fixed`||e===`sticky`))return{el:t,top:t.getBoundingClientRect().top,at:Date.now()}}return null}scrollContainerOf(e){let t=e.parentElement;for(;t&&t!==document.body;){let e=window.getComputedStyle(t);if(/(auto|scroll|overlay)/.test(e.overflowY)&&t.scrollHeight>t.clientHeight)return t;t=t.parentElement}return null}ensureStyles(e){let t=document.getElementById(K);t||(t=document.createElement(`style`),t.id=K,t.setAttribute(`data-lens-ignore`,``),(document.head??document.documentElement).append(t)),t.textContent=Ze(e)}lastStatusText=``;showStatus(e,t=!1){if(e===this.lastStatusText&&document.getElementById(q)?.dataset.error===(t?`true`:`false`))return;this.lastStatusText=e;let n=document.getElementById(q);n||(n=document.createElement(`div`),n.id=q,n.setAttribute(`data-lens-ignore`,``),n.setAttribute(`role`,`status`),n.setAttribute(`aria-live`,`polite`),document.documentElement.append(n)),n.dataset.error=t?`true`:`false`,n.textContent=e}progressTick=0;updateProgress(){let e=Date.now();e-this.progressTick<400&&this.processedCount<this.totalCount||(this.progressTick=e,this.showStatus(`整页翻译 ${Math.min(this.processedCount,this.totalCount)}/${this.totalCount}`))}failActivation(e){this.active=!1,window.clearTimeout(this.initialRetryTimer),this.observer?.disconnect(),this.observer=null,this.alignment.deactivate(),this.showStatus(e,!0),this.scheduleStatusRemoval(5e3)}scheduleStatusRemoval(e=3e3){window.clearTimeout(this.statusTimer),this.statusTimer=window.setTimeout(()=>{document.getElementById(q)?.remove()},e)}},ut=new Set(`a.an.and.are.as.at.be.by.for.from.has.have.in.is.it.not.of.on.or.that.the.this.to.was.we.will.with.you`.split(`.`));function Y(e){return e.trim().toLocaleLowerCase().split(/[-_]/u)[0]}function dt(e){let t=e.match(/\p{L}/gu)??[];if(t.length<40||(e.match(/[a-z]/giu)?.length??0)/t.length<.78)return!1;let n=e.toLocaleLowerCase().match(/[a-z]+(?:'[a-z]+)?/gu)??[];return n.length<12?!1:n.reduce((e,t)=>e+ +!!ut.has(t),0)>=Math.max(2,Math.ceil(n.length*.035))}function ft(e){return(e.match(/\p{L}/gu)??[]).length<40}function pt(e,t=document){let n=t.documentElement.lang||t.querySelector(`meta[http-equiv="content-language" i]`)?.content||``,r=(t.body?.innerText||t.body?.textContent||``).slice(0,12e3),i=Y(e),a=Y(n),o=ft(r);return i===`en`&&dt(r)?{matches:!0,shouldRetry:!1,reason:`english-text`}:a?a===i?i===`en`?o?{matches:!0,shouldRetry:!0,reason:`declared-en-waiting-body`}:{matches:!1,shouldRetry:!1,reason:`declared-en-body-not-english`}:{matches:!0,shouldRetry:!1,reason:`declared:${a}`}:{matches:!1,shouldRetry:o&&i===`en`,reason:`declared-mismatch:${a}`}:o?{matches:!1,shouldRetry:i===`en`,reason:`insufficient-sample`}:{matches:!1,shouldRetry:!1,reason:`text-not-source`}}var mt=[{lang:`ja`,re:/[\p{Script=Hiragana}\p{Script=Katakana}]/u},{lang:`ko`,re:/\p{Script=Hangul}/u},{lang:`zh`,re:/\p{Script=Han}/u},{lang:`ru`,re:/\p{Script=Cyrillic}/u},{lang:`ar`,re:/\p{Script=Arabic}/u},{lang:`hi`,re:/\p{Script=Devanagari}/u},{lang:`th`,re:/\p{Script=Thai}/u},{lang:`he`,re:/\p{Script=Hebrew}/u},{lang:`el`,re:/\p{Script=Greek}/u},{lang:`bn`,re:/\p{Script=Bengali}/u},{lang:`ta`,re:/\p{Script=Tamil}/u},{lang:`te`,re:/\p{Script=Telugu}/u},{lang:`kn`,re:/\p{Script=Kannada}/u}],ht=.45;function gt(e){let t=e.match(/\p{L}/gu)??[];if(t.length<8)return null;for(let{lang:e,re:n}of mt)if(t.filter(e=>n.test(e)).length/t.length>=ht)return e;return null}var X=null;function _t(){return X||(X=(async()=>{let e=globalThis.LanguageDetector;if(!e)return null;try{return await e.availability()===`available`?await e.create():null}catch{return null}})(),X)}async function vt(e){let t=await _t();if(!t)return null;try{let n=(await t.detect(e.slice(0,4e3)))[0];if(!n||n.confidence<.5)return null;let r=n.detectedLanguage?.trim();return r?r.toLowerCase():null}catch{return null}}async function yt(e,t){return await vt(e)||(gt(e)??t)}var bt=300,xt=class{host;root;panel;sourceLabel;sourceBody;targetLabel;targetBody;bound=!1;enabled=!1;paused=!1;sourceLang=`en`;targetLang=`zh`;requestId=0;lastText=``;lastTranslation=``;refreshTimer=0;actionRow;starBtn;speakBtn;translate;actions;constructor(e,t={}){this.translate=e,this.actions=t,this.host=document.createElement(`div`),this.host.id=`lens-translator-selection-root`,this.host.setAttribute(`data-lens-ignore`,``),Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,pointerEvents:`none`,zIndex:`2147483645`}),this.root=this.host.attachShadow({mode:`closed`});let n=document.createElement(`style`);n.textContent=wt,this.panel=document.createElement(`div`),this.panel.className=`panel`,this.panel.style.display=`none`,this.panel.addEventListener(`mousedown`,e=>e.stopPropagation()),this.sourceLabel=document.createElement(`div`),this.sourceLabel.className=`label`,this.sourceBody=document.createElement(`div`),this.sourceBody.className=`source`,this.targetLabel=document.createElement(`div`),this.targetLabel.className=`label target-label`,this.targetBody=document.createElement(`div`),this.targetBody.className=`target`,this.actionRow=document.createElement(`div`),this.actionRow.className=`actions`,this.actionRow.hidden=!0,this.starBtn=document.createElement(`button`),this.starBtn.type=`button`,this.starBtn.className=`icon-btn`,this.starBtn.title=`收藏到生词本`,this.starBtn.textContent=`☆`,this.starBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.lastText&&this.lastTranslation&&(this.actions.onStar?.(this.lastText,this.lastTranslation),this.starBtn.textContent=`★`)}),this.speakBtn=document.createElement(`button`),this.speakBtn.type=`button`,this.speakBtn.className=`icon-btn`,this.speakBtn.title=`朗读译文`,this.speakBtn.textContent=`🔊`,this.speakBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.lastTranslation&&this.actions.onSpeak?.(this.lastTranslation)}),this.actionRow.append(this.starBtn,this.speakBtn),this.panel.append(this.sourceLabel,this.sourceBody,this.targetLabel,this.targetBody,this.actionRow),this.root.append(n,this.panel)}bind(){this.bound||(this.bound=!0,document.addEventListener(`selectionchange`,this.onSelectionChange),document.addEventListener(`mousedown`,this.onMouseDown,!0),window.addEventListener(`scroll`,this.hide,!0),window.addEventListener(`resize`,this.hide))}setEnabled(e){this.enabled=e,e||this.hide()}setPaused(e){this.paused=e,e&&this.hide()}setLanguages(e,t){this.sourceLang=e,this.targetLang=t,this.sourceLabel.textContent=i(e),this.targetLabel.textContent=i(t)}onMouseDown=e=>{let t=e.composedPath();t.includes(this.host)||t.includes(this.panel)||this.panel.style.display!==`none`&&!this.getSelectedText()&&this.hide()};onSelectionChange=()=>{if(!this.enabled||this.paused){this.hide();return}window.clearTimeout(this.refreshTimer),this.refreshTimer=window.setTimeout(()=>void this.refreshFromSelection(),bt)};getSelectedText(){let e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return``;let t=a(e.toString());if(t.length<1||t.length>2e3)return``;let n=e.anchorNode;if(n&&Ct(n instanceof Element?n:n.parentElement))return``;let r=e.focusNode;return r&&Ct(r instanceof Element?r:r.parentElement)||St(document.activeElement)?``:t}async refreshFromSelection(){let e=this.getSelectedText();if(!e){this.hide();return}if(e===this.lastText&&this.panel.style.display!==`none`)return;this.lastText=e;let t=window.getSelection();if(!t||t.rangeCount===0){this.hide();return}let n=t.getRangeAt(0).getBoundingClientRect();if(n.width<1&&n.height<1){this.hide();return}if(this.mount(),this.sourceLabel.textContent=i(this.sourceLang),this.targetLabel.textContent=i(this.targetLang),this.sourceBody.textContent=e,this.panel.style.display=`block`,o(e,this.targetLang)){this.targetBody.classList.add(`muted`),this.targetBody.textContent=`已是目标语言`,this.place(n);return}this.targetBody.classList.add(`muted`,`pending`),this.targetBody.textContent=`翻译中…`,this.place(n);let r=++this.requestId;try{let t=await this.translate(e);if(r!==this.requestId||this.getSelectedText()!==e)return;if(!t){this.targetBody.classList.add(`muted`),this.targetBody.classList.remove(`pending`),this.targetBody.textContent=`暂无法翻译`;return}this.targetBody.classList.remove(`muted`,`pending`),this.targetBody.textContent=t,this.lastTranslation=t,this.starBtn.textContent=`☆`,this.actionRow.hidden=!this.actions.onSpeak&&!this.actions.onStar,this.place(n)}catch{if(r!==this.requestId)return;this.targetBody.classList.add(`muted`),this.targetBody.classList.remove(`pending`),this.targetBody.textContent=`暂无法翻译`}}place(e){let t=window.innerWidth,n=window.innerHeight,r=this.panel.getBoundingClientRect(),i=Math.max(r.width,220),a=Math.max(r.height,72),o=Math.min(Math.max(8,e.left),t-i-8),s=e.bottom+10;s+a>n-8&&(s=Math.max(8,e.top-a-10)),this.panel.style.left=`${o}px`,this.panel.style.top=`${s}px`}mount(){this.host.isConnected||document.documentElement.append(this.host)}hide=()=>{this.requestId++,this.lastText=``,this.lastTranslation=``,window.clearTimeout(this.refreshTimer),this.panel.style.display=`none`,this.actionRow.hidden=!0,this.targetBody.classList.remove(`muted`,`pending`)}};function St(e){if(!e||!(e instanceof HTMLElement))return!1;if(e.isContentEditable)return!0;let t=e.tagName;return t===`INPUT`||t===`TEXTAREA`||t===`SELECT`||!!e.closest(`input, textarea, select, [contenteditable=""], [contenteditable="true"]`)}function Ct(e){return e?St(e)?!0:!!e.closest(`#lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt, [data-lens-ignore]`):!1}var wt=`
  :host, * { box-sizing: border-box; }
  .panel {
    position: fixed;
    min-width: 180px;
    max-width: min(360px, calc(100vw - 16px));
    max-height: min(280px, 42vh);
    overflow: auto;
    padding: 10px 12px;
    border-radius: 12px;
    background: rgb(255 255 255 / 96%);
    box-shadow:
      0 12px 32px rgb(15 23 42 / 18%),
      0 0 0 1px rgb(15 23 42 / 8%);
    color: #0f172a;
    font: 13px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif;
    pointer-events: auto;
    user-select: text;
  }
  .label {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.05em;
    color: #94a3b8;
    margin-bottom: 2px;
  }
  .target-label { margin-top: 8px; }
  .source {
    color: #64748b;
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 12.5px;
  }
  .target {
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 14px;
    font-weight: 520;
    color: #0f172a;
  }
  .target.muted { color: #64748b; font-weight: 400; }
  .target.pending { animation: pulse 1.1s ease-in-out infinite; }
  .actions {
    margin-top: 6px;
    display: flex;
    gap: 2px;
    justify-content: flex-end;
  }
  .icon-btn {
    appearance: none;
    border: 0;
    border-radius: 6px;
    background: transparent;
    padding: 3px 5px;
    font-size: 13px;
    line-height: 1;
    color: #64748b;
    cursor: pointer;
  }
  .icon-btn:hover { background: rgb(15 23 42 / 8%); }
  @keyframes pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
  }
  @media (prefers-color-scheme: dark) {
    .panel {
      background: rgb(24 24 27 / 96%);
      color: #f4f4f5;
      box-shadow: 0 12px 32px rgb(0 0 0 / 45%), 0 0 0 1px rgb(255 255 255 / 8%);
    }
    .source { color: #a1a1aa; }
    .target { color: #fafafa; }
    .target.muted { color: #a1a1aa; }
  }
  @media (prefers-reduced-motion: reduce) {
    .target.pending { animation: none; }
  }
`,Tt=class{host=null;root=null;show(e,t,n){this.dismiss(),this.host=document.createElement(`div`),this.host.id=`lens-translator-setup-prompt`,this.host.setAttribute(`data-lens-ignore`,``),Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,zIndex:`2147483647`,pointerEvents:`auto`}),this.root=this.host.attachShadow({mode:`closed`});let i=r(t.sourceLang,t.targetLang),a=Et(e,i),o=document.createElement(`style`);o.textContent=Dt;let s=document.createElement(`div`);s.className=`backdrop`,s.addEventListener(`click`,e=>{e.target===s&&(n.onDismiss?.(),this.dismiss())});let c=document.createElement(`div`);c.className=`card`,c.setAttribute(`role`,`dialog`),c.setAttribute(`aria-modal`,`true`),c.setAttribute(`aria-labelledby`,`lens-setup-title`);let l=document.createElement(`h2`);l.id=`lens-setup-title`,l.textContent=a.title;let u=document.createElement(`p`);u.className=`body`,u.textContent=a.body;let d=document.createElement(`div`);d.className=`pair`,d.textContent=i;let f=document.createElement(`div`);if(f.className=`actions`,a.primary===`download`&&n.onDownload){let e=document.createElement(`button`);e.type=`button`,e.className=`btn primary`,e.textContent=`下载语言包`,e.addEventListener(`click`,()=>{Promise.resolve(n.onDownload?.())}),f.append(e)}if(n.onOpenLlmSetup){let e=document.createElement(`button`);e.type=`button`,e.className=a.primary===`llm`?`btn primary`:`btn`,e.textContent=`配置外部 LLM`,e.addEventListener(`click`,()=>{Promise.resolve(n.onOpenLlmSetup?.()),this.dismiss()}),f.append(e)}if(n.onOpenOnboarding){let e=document.createElement(`button`);e.type=`button`,e.className=`btn`,e.textContent=`打开设置向导`,e.addEventListener(`click`,()=>{Promise.resolve(n.onOpenOnboarding?.()),this.dismiss()}),f.append(e)}let p=document.createElement(`button`);p.type=`button`,p.className=`btn ghost`,p.textContent=`稍后`,p.addEventListener(`click`,()=>{n.onDismiss?.(),this.dismiss()}),f.append(p),c.append(l,u,d,f),s.append(c),this.root.append(o,s),document.documentElement.append(this.host),window.addEventListener(`keydown`,this.onKeyDown,!0)}setStatus(e,t=!1){if(!this.root)return;let n=this.root.querySelector(`.status`);n||(n=document.createElement(`p`),n.className=`status`,this.root.querySelector(`.card`)?.append(n)),n.textContent=e,n.dataset.error=t?`true`:`false`}dismiss(){window.removeEventListener(`keydown`,this.onKeyDown,!0),this.host?.remove(),this.host=null,this.root=null}isOpen(){return!!this.host?.isConnected}onKeyDown=e=>{e.key===`Escape`&&this.isOpen()&&(e.preventDefault(),e.stopPropagation(),this.dismiss())}};function Et(e,t){return e.kind===`browser-unsupported`?{title:`当前浏览器未提供内置翻译`,body:`需要桌面版 Chrome 138+。若你以前能用，可先重新加载扩展或重启 Chrome 再试；也可改用外部 LLM。`,primary:`llm`}:e.kind===`external-unconfigured`?{title:`尚未配置外部翻译服务`,body:`当前选择了外部 LLM。请填写 Base URL、API Key 与模型，或改回 Chrome 内置翻译。`,primary:`llm`}:e.availability===`downloadable`||e.availability===`downloading`?{title:`需要下载语言包`,body:`语言对 ${t} 的 Chrome 语言包尚未就绪。下载后即可离线翻译；也可以改用外部 LLM。`,primary:`download`}:e.availability===`unavailable`?{title:`当前语言对不可用`,body:`Chrome 内置翻译不支持 ${t}。请更换语言，或切换到外部 LLM。`,primary:`llm`}:e.availability===`unsupported`?{title:`当前浏览器不支持内置翻译`,body:`需要桌面版 Chrome 138+ 的 Translator API，或改用外部 LLM 完成翻译。`,primary:`llm`}:{title:`翻译尚未就绪`,body:`请检查语言包状态，或在设置中切换到外部 LLM。`,primary:`none`}}var Dt=`
  :host { all: initial; }
  * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
  .backdrop {
    position: fixed;
    inset: 0;
    display: grid;
    place-items: center;
    padding: 20px;
    background: rgb(15 23 42 / 42%);
    backdrop-filter: blur(4px);
  }
  .card {
    width: min(420px, 100%);
    padding: 22px 22px 18px;
    border-radius: 16px;
    background: #fff;
    box-shadow: 0 24px 60px rgb(15 23 42 / 28%);
    color: #0f172a;
  }
  h2 {
    margin: 0 0 10px;
    font-size: 17px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }
  .body {
    margin: 0 0 12px;
    font-size: 13.5px;
    line-height: 1.55;
    color: #475569;
  }
  .pair {
    display: inline-flex;
    margin-bottom: 16px;
    padding: 5px 10px;
    border-radius: 999px;
    background: #eff6ff;
    color: #1d4ed8;
    font-size: 12px;
    font-weight: 600;
  }
  .actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  .btn {
    appearance: none;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    background: #f8fafc;
    color: #0f172a;
    font-size: 13px;
    font-weight: 600;
    padding: 9px 12px;
    cursor: pointer;
  }
  .btn:hover { background: #f1f5f9; }
  .btn.primary {
    border-color: #2563eb;
    background: #2563eb;
    color: #fff;
  }
  .btn.primary:hover { background: #1d4ed8; }
  .btn.ghost {
    border-color: transparent;
    background: transparent;
    color: #64748b;
  }
  .status {
    margin: 12px 0 0;
    font-size: 12.5px;
    color: #0369a1;
  }
  .status[data-error="true"] { color: #b91c1c; }
  @media (prefers-color-scheme: dark) {
    .card { background: #18181b; color: #f4f4f5; }
    .body { color: #a1a1aa; }
    .pair { background: #172554; color: #93c5fd; }
    .btn { border-color: #3f3f46; background: #27272a; color: #f4f4f5; }
    .btn:hover { background: #3f3f46; }
    .btn.ghost { color: #a1a1aa; }
  }
`,Ot=320,kt=6;function At(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-image-result`||typeof e.ok!=`boolean`?!1:e.ok?`translation`in e&&typeof e.translation==`string`:`error`in e&&typeof e.error==`string`}function Z(e){return!e||typeof e!=`object`?!1:`id`in e&&typeof e.id==`string`&&`translation`in e&&typeof e.translation==`string`}function Q(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-batch-result`||typeof e.ok!=`boolean`?!1:e.ok?`translations`in e&&Array.isArray(e.translations)&&e.translations.every(Z):!(`error`in e)||typeof e.error!=`string`?!1:!(`translations`in e)||e.translations===void 0||Array.isArray(e.translations)&&e.translations.every(Z)}function jt(e){return!e||typeof e!=`object`||!(`type`in e)||e.type!==`settings`||!(`configured`in e)||typeof e.configured!=`boolean`||!(`settings`in e)||!e.settings||typeof e.settings!=`object`||!(`paused`in e)||typeof e.paused!=`boolean`?!1:`apiKey`in e.settings&&e.settings.apiKey===``}function Mt(e){return!e||typeof e!=`object`||!(`type`in e)||e.type!==`background-error`?null:`error`in e&&typeof e.error==`string`?e.error:null}function Nt(e,t){return[e.translationEngine!==`external`||t,e.sourceLang,e.targetLang,e.translationEngine,e.minTextLength,e.batchCharLimit].join(`\0`)}function Pt(e,t){return[e.pageTranslationEngine!==`external`||t,e.sourceLang,e.targetLang,e.pageTranslationEngine,e.minTextLength,e.batchCharLimit].join(`\0`)}function Ft(e){return[e.pageTranslationDisplayMode,e.pageTranslationFontFamily,e.pageTranslationFontSizePx,e.pageTranslationUseCustomColor,e.pageTranslationTextColor,e.pageTranslationUseBackground,e.pageTranslationBackgroundColor,e.pageTranslationBold,e.pageTranslationItalic,e.pageTranslationUnderline].join(`\0`)}var It=class r{registry=new ke;imageRegistry=new Me;browserTranslator=new u;pageTranslator=new lt(this.browserTranslator);lens;batcher;setupPrompt=new Tt;selectionTranslator;settings=t;configured=!1;pausedHere=!1;lensSettingsSig=``;pageSettingsSig=``;pageStyleSig=``;autoPageStartPending=!1;autoPageRetryTimer=0;autoPageRetryDeadline=0;autoPageRetryAttempts=0;autoPageRetryBackoffMs=1e3;autoPageSuppress=!1;autoPageAbandoned=!1;autoPageNoticeAt=0;autoPageNoticeText=``;settingsGeneration=0;translationGeneration=0;lensActive=!1;lensSticky=!1;hotkeyDownAt=0;hotkeyHeld=!1;lastMouse={x:0,y:0};inflight=new Map;inflightTexts=new Map;imageInflight=new Set;editableCache=new Map;editableInflight=new Set;dictCache=new Map;dictInflight=new Set;starredKeys=new Set;lensPayload=null;resolvedSourceLang=null;resolvingSourceLang=null;pointerFrame=0;stickyFrame=0;listenersBound=!1;autoScanMo=null;onBubbleVisibility=null;constructor(e=340){this.lens=new Ae(e),this.batcher=new Ne(e=>this.translateSpecific(e)),this.selectionTranslator=new xt(e=>this.translateSelectionText(e),{onSpeak:e=>this.speak(e,this.settings.targetLang),onStar:(e,t)=>{this.saveToVocabulary(e,t)}}),this.lens.onSpeak(e=>{let t=this.lensPayload;if(!t)return;let n=e===`source`?t.sourceText:t.translation;n&&this.speak(n,e===`source`?t.sourceLang:t.targetLang)}),this.lens.onStar(()=>{let e=this.lensPayload;e?.translation&&this.saveToVocabulary(e.sourceText,e.translation,e)}),this.lens.onAction(()=>{let e=this.lensPayload;!e?.editable||!e.translation||this.replaceEditableContent(e.editable,e.translation)}),this.pageTranslator.setWordStarHandler(e=>{this.saveToVocabulary(e.source,e.translation,{sourceLang:e.sourceLang,targetLang:e.targetLang})})}setBubbleVisibilityHandler(e){this.onBubbleVisibility=e,e(this.settings.showFloatingBubble!==!1&&!this.pausedHere)}bindListeners(){if(this.listenersBound)return;this.listenersBound=!0,this.selectionTranslator.bind(),window.addEventListener(`keydown`,this.onKeyDown,!0),window.addEventListener(`keyup`,this.onKeyUp,!0),window.addEventListener(`blur`,this.onBlur),window.addEventListener(`mousemove`,this.onMouseMove,!0);let e=Ht(()=>{this.settings.autoTranslate&&this.scanVisibleAndTranslate()},300);window.addEventListener(`scroll`,e,!0),window.addEventListener(`resize`,e),window.addEventListener(`scroll`,this.onStickyReposition,!0),window.addEventListener(`resize`,this.onStickyReposition),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e.settings&&this.refreshSettings()}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(t.id!==chrome.runtime.id||!e||typeof e!=`object`)return!1;let r=e.type;return r===`toggle-page-translation`?(this.togglePageTranslation().then(n,e=>{n($(e))}),!0):r===`toggle-lens`?(this.toggleStickyLensAsync().then(n,e=>{n($(e))}),!0):r===`bubble-control`&&Bt(e)?(this.handleBubbleControl(e).then(n,e=>{n($(e))}),!0):!1})}async refreshSettings(){try{let t=await chrome.runtime.sendMessage({type:`get-settings`}),n=Mt(t);if(n)throw Error(n);if(!jt(t))throw Error(`Invalid settings response`);let r=this.settings;this.configured=t.configured,this.settings=e(t.settings),this.settingsGeneration++,this.pausedHere=t.paused,this.pausedHere&&(this.lensActive&&this.deactivateLens(),this.pageTranslator.isActive()&&this.pageTranslator.deactivate(),this.selectionTranslator.hide(),this.suppressAutoPage(`paused`)),this.lens.setWidth(this.settings.lensWidthPx),this.lens.setFontSize(this.settings.pageTranslationFontSizePx),this.lens.setFontFamily(this.settings.pageTranslationFontFamily),this.lens.setAppearance(this.settings),this.lens.setLanguageLabels(i(this.syncSourceLang()),i(this.settings.targetLang)),this.selectionTranslator.setPaused(this.pausedHere),this.selectionTranslator.setEnabled(this.settings.selectionTranslate),this.selectionTranslator.setLanguages(this.syncSourceLang(),this.settings.targetLang),this.onBubbleVisibility?.(this.settings.showFloatingBubble&&!this.pausedHere),this.syncAutoScanObserver();let a=Nt(this.settings,this.configured),o=a!==this.lensSettingsSig,s=this.lensSettingsSig;this.lensSettingsSig=a;let c=Pt(this.settings,this.configured),l=c!==this.pageSettingsSig,u=this.pageSettingsSig;this.pageSettingsSig=c,(o||l)&&(this.resolvedSourceLang=null,this.editableCache.clear(),this.dictCache.clear(),this.dictErrors.clear(),this.lensPayload=null);let d=Ft(this.settings),f=d!==this.pageStyleSig;this.pageStyleSig=d,u!==``&&l&&this.pageTranslator.isActive()?this.pageTranslator.deactivate():f&&this.pageTranslator.isActive()&&this.pageTranslator.restyle(this.settings),this.settings.autoPageTranslation&&(!r.autoPageTranslation||l)&&(this.autoPageSuppress=!1,this.autoPageAbandoned=!1,this.resetAutoPageRetryBudget()),this.settings.autoPageTranslation||this.suppressAutoPage(`auto-off`),s!==``&&o&&(this.translationGeneration++,this.inflight.clear(),this.inflightTexts.clear(),this.registry.resetTranslationsToPending()),this.canTranslateText()&&this.settings.autoTranslate&&(o||!r.autoTranslate)&&this.scanVisibleAndTranslate(),this.settings.autoPageTranslation&&await this.maybeStartPageTranslation()}catch(e){console.warn(`[Lens Translator] settings refresh failed`,e instanceof Error?e.message:String(e))}}ensureMouseSeed(){this.lastMouse.x===0&&this.lastMouse.y===0&&(this.lastMouse={x:Math.round(window.innerWidth/2),y:Math.round(window.innerHeight/2)})}async togglePageTranslation(){if(this.pageTranslator.isActive())return this.pageTranslator.deactivate(),this.suppressAutoPage(`user-close`),{ok:!0};let e=await this.ensureEngineReady(`page`);if(!e.ok)return e;this.lensActive&&this.deactivateLens(),this.suppressAutoPage(`user-open`);let t={...this.settings,sourceLang:await this.effectiveSourceLang()};return await this.pageTranslator.toggle(t,this.configured),{ok:!0}}async toggleStickyLensAsync(){if(this.lensActive)return this.deactivateLens(),{ok:!0,lensActive:!1};if(this.pausedHere)return{ok:!1,error:`当前网站已暂停翻译`};let e=await this.ensureEngineReady(`lens`);return e.ok?(this.activateStickyLens(),{ok:!0,lensActive:!0}):e}activateStickyLens(){this.lensActive=!0,this.lensSticky=!0,this.hotkeyHeld=!1,this.ensureMouseSeed(),this.warmBrowserEngine(),this.refreshLensView()}activateTemporaryLens(e){this.lensActive=!0,this.lensSticky=!1,this.hotkeyDownAt=e,this.ensureMouseSeed(),this.warmBrowserEngine(),this.refreshLensView()}warmBrowserEngine(){this.settings.translationEngine===`browser`&&this.effectiveSourceLang().then(e=>this.browserTranslator.prepare(e,this.settings.targetLang))}refreshLensView(){this.tryFocusEditableLens()||this.updateLens()}tryFocusEditableLens(){if(!this.settings.inputTranslate)return!1;let e=D(document.activeElement);return e?(this.updateEditableLens(e),!0):!1}async scanVisibleAndTranslate(){if(this.pausedHere||!this.settings.autoTranslate||!this.canTranslateText())return;let e=Math.round(window.innerHeight*this.settings.prefetchMarginRatio),t=Ce(this.settings.minTextLength,e);for(let e of t)this.registry.upsert({id:e.id,el:e.el,tag:e.tag,text:e.text});let n=this.registry.pendingBlocks().filter(e=>!this.inflight.has(e.id)&&!o(e.text,this.settings.targetLang));n.length&&await this.translateSpecific(n)}async maybeStartPageTranslation(){if(this.autoPageStartPending||this.autoPageSuppress||this.autoPageAbandoned||this.pausedHere||!this.settings.autoPageTranslation||this.pageTranslator.isActive())return;let e=this.settings;if(this.settings.sourceLang===`auto`){if(ft((document.body?.innerText||document.body?.textContent||``).slice(0,12e3))){this.scheduleAutoPageRetry(`auto:insufficient-sample`);return}let t=await this.effectiveSourceLang();if(Y(t)===Y(this.settings.targetLang)){this.abandonAutoPage(`auto:page-in-target-language`);return}e={...this.settings,sourceLang:t}}else{let e=pt(this.settings.sourceLang);if(!e.matches){e.shouldRetry?this.scheduleAutoPageRetry(`lang:${e.reason}`):this.abandonAutoPage(`lang:${e.reason}`);return}}if(this.settings.pageTranslationEngine===`external`&&!this.configured){this.abandonAutoPage(`external-unconfigured`);return}let t=this.settingsGeneration,n=e,r=this.configured;this.autoPageStartPending=!0;try{if(n.pageTranslationEngine===`browser`){let e=await this.browserTranslator.availability(n.sourceLang,n.targetLang);if(e!==`available`){e===`downloadable`||e===`downloading`?(this.scheduleAutoPageRetry(`pack:${e}`),this.noticeAutoPageBlocked(e===`downloading`?`Chrome 语言包下载中，就绪后将自动开启整页翻译`:`请先在设置中下载 Chrome 语言包，才能自动开启整页翻译`)):(this.abandonAutoPage(`pack:${e}`),this.noticeAutoPageBlocked(`Chrome 内置翻译当前不可用，自动整页已跳过（可改用外部 LLM 或手动开启）`));return}}if(t!==this.settingsGeneration||this.autoPageSuppress||this.pausedHere||!this.settings.autoPageTranslation||this.pageTranslator.isActive())return;this.clearAutoPageRetry(),await this.pageTranslator.activate(n,r),this.pageTranslator.isActive()?this.suppressAutoPage(`auto-started`):this.abandonAutoPage(`activate-failed`)}finally{this.autoPageStartPending=!1,t!==this.settingsGeneration&&this.settings.autoPageTranslation&&!this.autoPageSuppress&&!this.autoPageAbandoned&&!this.pausedHere&&!this.pageTranslator.isActive()&&this.maybeStartPageTranslation()}}static AUTO_PAGE_RETRY_MAX_ATTEMPTS=12;static AUTO_PAGE_RETRY_WINDOW_MS=12e3;static AUTO_PAGE_RETRY_BACKOFF_MAX_MS=2500;scheduleAutoPageRetry(e){if(!this.settings.autoPageTranslation||this.pausedHere||this.autoPageSuppress||this.autoPageAbandoned||this.pageTranslator.isActive())return;let t=Date.now();if(this.autoPageRetryDeadline||(this.autoPageRetryDeadline=t+r.AUTO_PAGE_RETRY_WINDOW_MS,this.autoPageRetryAttempts=0,this.autoPageRetryBackoffMs=1e3),t>this.autoPageRetryDeadline||this.autoPageRetryAttempts>=r.AUTO_PAGE_RETRY_MAX_ATTEMPTS){this.abandonAutoPage(`retry-budget-exhausted`);return}if(this.autoPageRetryTimer)return;let n=this.autoPageRetryBackoffMs;this.autoPageRetryAttempts++,this.autoPageRetryBackoffMs=Math.min(Math.round(this.autoPageRetryBackoffMs*1.35),r.AUTO_PAGE_RETRY_BACKOFF_MAX_MS),this.autoPageRetryTimer=window.setTimeout(()=>{this.autoPageRetryTimer=0,this.settings.autoPageTranslation&&!this.autoPageSuppress&&!this.autoPageAbandoned&&!this.pausedHere&&!this.pageTranslator.isActive()&&this.maybeStartPageTranslation()},n)}clearAutoPageRetry(){this.autoPageRetryTimer&&window.clearTimeout(this.autoPageRetryTimer),this.autoPageRetryTimer=0}resetAutoPageRetryBudget(){this.clearAutoPageRetry(),this.autoPageRetryDeadline=0,this.autoPageRetryAttempts=0,this.autoPageRetryBackoffMs=1e3}suppressAutoPage(e){this.autoPageSuppress=!0,this.clearAutoPageRetry()}abandonAutoPage(e){this.autoPageAbandoned=!0,this.clearAutoPageRetry(),this.autoPageRetryDeadline=0,this.autoPageRetryAttempts=0}noticeAutoPageBlocked(e){let t=Date.now();e===this.autoPageNoticeText&&t-this.autoPageNoticeAt<3e4||(this.autoPageNoticeAt=t,this.autoPageNoticeText=e,console.info(`[Lens Translator]`,e))}onKeyDown=e=>{if(e.key===`Escape`){if(this.lensActive){e.preventDefault(),this.deactivateLens();return}if(this.pageTranslator.isActive()){e.preventDefault(),this.pageTranslator.deactivate(),this.suppressAutoPage(`escape`);return}}if(!this.pausedHere){if(n(e,this.settings.pageTranslationHotkey)){if(e.repeat){e.preventDefault();return}e.preventDefault(),e.stopPropagation(),this.togglePageTranslation();return}if(n(e,this.settings.hotkey)){if(e.repeat){e.preventDefault();return}if(e.preventDefault(),e.stopPropagation(),this.lensActive&&this.lensSticky){this.deactivateLens();return}this.lensActive||(this.hotkeyHeld=!0,this.hotkeyDownAt=Date.now(),this.beginHotkeyLens(this.hotkeyDownAt))}}};async beginHotkeyLens(e){if(!(await this.ensureEngineReady(`lens`)).ok){this.hotkeyHeld=!1;return}if(!this.lensActive){if(!this.hotkeyHeld){let t=Date.now()-e;t>0&&t<Ot&&this.activateStickyLens();return}this.activateTemporaryLens(e)}}onKeyUp=e=>{let t=e.code===this.settings.hotkey.code,n=this.isHotkeyModifierRelease(e);if((t||n)&&(this.hotkeyHeld=!1),!(!this.lensActive||this.lensSticky)){if(t){let e=Date.now()-this.hotkeyDownAt;if(e>0&&e<Ot){this.lensSticky=!0;return}this.deactivateLens();return}n&&this.deactivateLens()}};onBlur=()=>{this.hotkeyHeld=!1,this.lensActive&&!this.lensSticky&&this.deactivateLens()};onMouseMove=e=>{let t=e.composedPath();t.includes(this.lens.getHost())||t.some(e=>e instanceof Element&&e.id===`lens-translator-bubble-root`)||(this.lastMouse={x:e.clientX,y:e.clientY},!(!this.lensActive||this.pointerFrame)&&(this.pointerFrame=requestAnimationFrame(()=>{this.pointerFrame=0,this.updateLens()})))};onStickyReposition=()=>{!this.lensActive||!this.lensSticky||this.stickyFrame||(this.stickyFrame=requestAnimationFrame(()=>{this.stickyFrame=0,this.lens.reposition()}))};updateLens(){if(!this.lensActive){this.lens.hide();return}this.ensureMouseSeed();let e=this.lens.getHost(),t=document.elementsFromPoint(this.lastMouse.x,this.lastMouse.y).filter(t=>t!==e&&!e.contains(t))[0]??null,n=this.imageEntryForHit(t);if(n){if(!this.configured){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`unconfigured`}),this.lens.highlight(null);return}let e=n.el.getBoundingClientRect();if(this.lens.highlight(n.el),n.status===`ready`&&n.translation){this.lensPayload={sourceText:``,translation:n.translation,sourceLang:this.syncSourceLang(),targetLang:this.settings.targetLang},this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`ready`,text:n.translation,sourceRect:e});return}if(n.status===`error`&&!this.imageInflight.has(n.id)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`error`,message:n.error??`图片翻译失败`,sourceRect:e});return}this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceRect:e}),this.translateImageEntry(n);return}if(!this.canTranslateText()){this.lensPayload=null,this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`unconfigured`}),this.lens.highlight(null);return}if(this.settings.inputTranslate){let e=D(t);if(e){this.updateEditableLens(e);return}}let r=Math.min(2,this.settings.minTextLength),i=this.registry.getByElement(t);if(i){let e=O(this.lastMouse.x,this.lastMouse.y,r);e&&e.el!==i.el&&e.text.length<i.text.length&&(i=this.registry.upsert(e))}else{let e=O(this.lastMouse.x,this.lastMouse.y,r);e&&(i=this.registry.upsert(e))}if(!i){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`empty`}),this.lens.highlight(null);return}if(o(i.text,this.settings.targetLang)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`target-language`}),this.lens.highlight(i.el);return}this.lens.highlight(i.el);let s=i.el.getBoundingClientRect(),c=i.text,l=a(c);if(!(this.settings.translationEngine===`external`&&this.configured&&zt(l)&&this.updateDictLens(i.id,l,s))){if(i.status===`ready`&&i.translation){this.lensPayload={sourceText:c,translation:i.translation,sourceLang:this.syncSourceLang(),targetLang:this.settings.targetLang},this.updateStarMarker(c,this.lensPayload.sourceLang),this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`ready`,text:i.translation,sourceText:c,sourceRect:s});return}if(i.status===`error`&&!this.inflight.has(i.id)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`error`,message:i.error??`翻译失败`,sourceText:c,sourceRect:s});return}this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceText:c,sourceRect:s}),this.inflight.has(i.id)||this.batcher.enqueue({id:i.id,tag:i.tag,text:i.text})}}updateEditableLens(e){let t=a(e.text),n=e.el.getBoundingClientRect();this.lens.highlight(e.el);let r=this.editableCache.get(t);if(r){this.lensPayload={sourceText:e.text,translation:r.translation,sourceLang:r.sourceLang,targetLang:r.targetLang,editable:e},this.updateStarMarker(e.text,r.sourceLang),this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`editable`,sourceText:e.text,translation:r.translation,status:`ready`,writable:e.writable,sourceRect:n});return}this.lensPayload={sourceText:e.text,translation:null,sourceLang:this.syncSourceLang(),targetLang:this.settings.targetLang,editable:e},this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`editable`,sourceText:e.text,translation:null,status:`pending`,writable:e.writable,sourceRect:n}),!this.editableInflight.has(t)&&(this.editableInflight.add(t),this.translateInputText(e.text).then(r=>{if(r)this.editableCache.set(t,r);else if(this.lensPayload?.editable&&a(this.lensPayload.editable.text)===t){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`editable`,sourceText:e.text,translation:null,status:`error`,error:`回译失败，请检查引擎或语言包`,writable:e.writable,sourceRect:n});return}this.lensActive&&this.updateLens()}).finally(()=>{this.editableInflight.delete(t)}))}updateDictLens(e,t,n){let r=this.settings.sourceLang===`auto`?this.resolvedSourceLang??gt(t)??`en`:this.settings.sourceLang,i=`${r}|${this.settings.targetLang}|${t.toLowerCase()}`,a=this.dictCache.get(i);if(a){let i=a.senses[0]?.gloss??``;return i&&this.registry.setTranslation(e,i),this.lensPayload={sourceText:t,translation:i||null,sourceLang:r,targetLang:this.settings.targetLang},this.updateStarMarker(t,r),this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`dict`,entry:a,sourceText:t,sourceRect:n}),!0}return this.dictErrors.has(i)?!1:(this.lensPayload={sourceText:t,translation:null,sourceLang:r,targetLang:this.settings.targetLang},this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceText:t,sourceRect:n}),this.dictInflight.has(i)?!0:(this.dictInflight.add(i),this.fetchDictionaryEntry(t,r).then(e=>{e?this.dictCache.set(i,e):this.dictErrors.add(i),this.lensActive&&this.updateLens()}).finally(()=>{this.dictInflight.delete(i)}),!0))}dictErrors=new Set;deactivateLens(){this.lensActive=!1,this.lensSticky=!1,this.hotkeyHeld=!1,this.hotkeyDownAt=0,this.lensPayload=null,this.stopSpeaking(),this.lens.hide()}async translateImageEntry(e){if(!(this.pausedHere||!this.configured||this.imageInflight.has(e.id))){this.imageInflight.add(e.id),this.imageRegistry.setPending(e.id);try{let t=await chrome.runtime.sendMessage({type:`translate-image`,imageUrl:e.url});At(t)?t.ok?this.imageRegistry.setTranslation(e.id,t.translation):this.imageRegistry.setError(e.id,Vt(t.error)):this.imageRegistry.setError(e.id,`图片翻译服务未返回有效结果`)}catch(t){this.imageRegistry.setError(e.id,t instanceof Error?t.message:String(t))}finally{this.imageInflight.delete(e.id)}this.lensActive&&this.updateLens()}}async translateWithBrowser(e){if(!this.browserTranslator.isSupported())return;let t=this.translationGeneration,n=await this.effectiveSourceLang(),r=this.settings.targetLang;for(let i of e){if(t!==this.translationGeneration)return;let e=await this.browserTranslator.translate(i.text,n,r);if(t!==this.translationGeneration)return;e&&this.registry.setTranslation(i.id,e)}}async translateSpecific(e){if(this.pausedHere)return;let t=this.translationGeneration,n=this.settings.translationEngine,r=this.configured,i=[],s=new Set;for(let t of e){if(o(t.text,this.settings.targetLang))continue;let e=this.registry.get(t.id);if(!e||e.status===`ready`&&e.translation||this.inflight.has(t.id))continue;let n=a(t.text);if(!this.inflightTexts.has(n)){if(s.has(n)){this.registry.setPending(t.id);continue}s.add(n),i.push({id:t.id,tag:t.tag,text:n})}}if(!i.length)return;for(let e of i)this.inflight.set(e.id,t),this.inflightTexts.set(a(e.text),t),this.registry.setPending(e.id);let c=n===`browser`?`Chrome 内置翻译不可用或不支持当前语言对`:`外部 API 未配置`;try{if(n===`browser`)await this.translateWithBrowser(i);else if(r){let e=M(),n=await this.effectiveSourceLang(),r=this.settings.targetLang,a=null;if(await p(i,kt,async i=>{if(t===this.translationGeneration){try{let o=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:e,blocks:[i],sourceLang:n,targetLang:r});if(t!==this.translationGeneration)return;if(!Q(o)){a===null&&(a=`翻译服务未返回有效结果`);return}for(let e of o.translations??[])this.registry.setTranslation(e.id,e.translation);!o.ok&&a===null&&(a=o.error)}catch(e){a===null&&(a=e instanceof Error?e.message:String(e))}this.lensActive&&this.updateLens()}}),t!==this.translationGeneration)return;a!==null&&(c=a)}if(t!==this.translationGeneration)return;for(let e of i)this.registry.get(e.id)?.translation||this.registry.setError(e.id,c)}catch(e){if(t!==this.translationGeneration)return;c=e instanceof Error?e.message:String(e);for(let e of i)this.registry.get(e.id)?.translation||this.registry.setError(e.id,c)}finally{for(let e of i){this.inflight.get(e.id)===t&&this.inflight.delete(e.id);let n=a(e.text);this.inflightTexts.get(n)===t&&this.inflightTexts.delete(n)}}this.lensActive&&this.updateLens()}canTranslateText(){return this.settings.translationEngine===`browser`?this.browserTranslator.isSupported():this.configured}speak(e,t){e&&chrome.runtime.sendMessage({type:`tts-speak`,text:e.slice(0,4e3),lang:t}).catch(()=>{})}stopSpeaking(){chrome.runtime.sendMessage({type:`tts-stop`}).catch(()=>void 0)}async saveToVocabulary(e,t,n){let r=n?.sourceLang??this.syncSourceLang(),i=n?.targetLang??this.settings.targetLang;await d({source:e,translation:t,sourceLang:r,targetLang:i,pageUrl:location.href})&&(this.starredKeys.add(l(e,r,i)),this.lens.setStarActive(!0))}updateStarMarker(e,t){let n=l(e,t,this.settings.targetLang);this.lens.setStarActive(this.starredKeys.has(n))}async effectiveSourceLang(){return this.settings.sourceLang===`auto`?this.resolvedSourceLang?this.resolvedSourceLang:(this.resolvingSourceLang||=(async()=>{let e=(document.body?.innerText||document.body?.textContent||``).slice(0,4e3);return this.resolvedSourceLang=await yt(e,`en`),this.resolvedSourceLang})().finally(()=>{this.resolvingSourceLang=null}),this.resolvingSourceLang):this.settings.sourceLang}syncSourceLang(){return this.settings.sourceLang===`auto`?this.resolvedSourceLang??`en`:this.settings.sourceLang}async translateInputText(e){let t=await this.effectiveSourceLang(),n=!o(e,this.settings.targetLang),r=n?t:this.settings.targetLang,i=n?this.settings.targetLang:t;if(this.settings.translationEngine===`browser`){let t=await this.browserTranslator.translate(e,r,i);return t?{translation:t,sourceLang:r,targetLang:i}:null}if(!this.configured)return null;let a=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:M(),blocks:[{id:`input`,tag:`editable`,text:e}],sourceLang:r,targetLang:i});if(!Q(a)||!a.ok)return null;let s=a.translations.find(e=>e.id===`input`)?.translation;return s?{translation:s,sourceLang:r,targetLang:i}:null}replaceEditableContent(e,t){let n=e.el;n.focus();let r=!1;try{e.kind===`contenteditable`?r=document.execCommand(`selectAll`,!1)&&document.execCommand(`insertText`,!1,t):(n.select(),r=document.execCommand(`insertText`,!1,t))}catch{r=!1}if(!r)if(e.kind===`contenteditable`)n.textContent=t,n.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`,data:t}));else{let e=n;e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}this.editableCache.set(a(t),{translation:t,sourceLang:this.settings.targetLang,targetLang:this.syncSourceLang()}),this.updateLens()}async fetchDictionaryEntry(e,t){let n=await chrome.runtime.sendMessage({type:`translate-dict`,text:e,sourceLanguage:t,targetLanguage:this.settings.targetLang});return!Lt(n)||!n.ok?null:n.entry}syncAutoScanObserver(){if(this.settings.autoTranslate&&!this.pausedHere){this.autoScanMo||(this.autoScanMo=new MutationObserver(Ht(()=>{this.settings.autoTranslate&&this.scanVisibleAndTranslate()},500)),this.autoScanMo.observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0}));return}this.autoScanMo?.disconnect(),this.autoScanMo=null}async ensureEngineReady(e,t){if(this.pausedHere)return{ok:!1,error:`当前网站已暂停翻译`};let n=e===`lens`?this.settings.translationEngine:this.settings.pageTranslationEngine,r=t?.quiet===!0;if(n===`external`)return this.configured?{ok:!0}:(r||this.showEngineSetupPrompt({kind:`external-unconfigured`}),{ok:!1,error:e===`lens`?`透镜翻译需要先配置外部 API`:`整页翻译需要先配置外部 API`});let i=await this.browserTranslator.availability(await this.effectiveSourceLang(),this.settings.targetLang);return i===`available`?{ok:!0}:i===`unsupported`?(r||this.showEngineSetupPrompt({kind:`browser-unsupported`}),{ok:!1,error:`当前浏览器不支持 Chrome 内置翻译（需桌面版 Chrome 138+）`}):(r||this.showEngineSetupPrompt({kind:`language-pack`,availability:i}),{ok:!1,error:i===`downloadable`||i===`downloading`?`需要先下载 Chrome 语言包`:`Chrome 内置翻译暂时不可用（语言包未就绪或本页策略限制），请稍后重试或改用外部 LLM`})}showEngineSetupPrompt(e){this.setupPrompt.isOpen()||this.setupPrompt.show(e,{sourceLang:this.settings.sourceLang,targetLang:this.settings.targetLang},{onDownload:e.kind===`language-pack`?async()=>{if(this.setupPrompt.setStatus(`正在下载语言包…`),await this.browserTranslator.prepare(this.settings.sourceLang,this.settings.targetLang,e=>{this.setupPrompt.setStatus(`语言包下载 ${Math.round(e*100)}%`)})){this.setupPrompt.setStatus(`语言包已就绪，请再次开启翻译`),window.setTimeout(()=>this.setupPrompt.dismiss(),900);return}let e=this.browserTranslator.lastError?.trim();this.setupPrompt.setStatus(e?`语言包下载失败：${e}`:`语言包下载失败，请检查网络或改用外部 LLM`,!0)}:void 0,onOpenLlmSetup:()=>{chrome.runtime.sendMessage({type:`open-options`,hash:`#external-api`}).catch(()=>{})},onOpenOnboarding:()=>{chrome.runtime.sendMessage({type:`open-options`,hash:`#onboarding`}).catch(()=>{})}})}async translateSelectionText(e){if(this.pausedHere)return null;if(this.settings.translationEngine===`browser`)return(await this.ensureEngineReady(`lens`,{quiet:!0})).ok?this.browserTranslator.translate(e,await this.effectiveSourceLang(),this.settings.targetLang):null;if(!(await this.ensureEngineReady(`lens`,{quiet:!0})).ok)return null;let t=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:M(),blocks:[{id:`sel`,tag:`selection`,text:e}],sourceLang:await this.effectiveSourceLang(),targetLang:this.settings.targetLang});return!Q(t)||!t.ok?null:t.translations.find(e=>e.id===`sel`)?.translation??null}bubbleState(){return{ok:!0,lensActive:this.lensActive,pageTranslationActive:this.pageTranslator.isActive()}}async handleBubbleControl(e){if(e.command===`get-state`)return this.bubbleState();if(e.command===`toggle-lens`){let e=await this.toggleStickyLensAsync();return e.ok?this.bubbleState():e}if(e.command===`retranslate-page`){let e=await this.retranslatePage();return e.ok?this.bubbleState():e}let t=await this.togglePageTranslation();return t.ok?this.bubbleState():t}async retranslatePage(){let e=await this.ensureEngineReady(`page`);if(!e.ok)return e;this.lensActive&&this.deactivateLens(),this.suppressAutoPage(`user-open`);let t={...this.settings,sourceLang:await this.effectiveSourceLang()};return await this.pageTranslator.refresh(t,this.configured),{ok:!0}}imageEntryForHit(e){if(!(e instanceof HTMLImageElement)||!e.complete||e.naturalWidth<2||e.naturalHeight<2)return;let t=e.currentSrc||e.src;if(t)return this.imageRegistry.upsert(f(`img`,t,v(e)),e,t)}isHotkeyModifierRelease(e){let t=this.settings.hotkey;return!!(t.altKey&&(e.code===`AltLeft`||e.code===`AltRight`)||t.shiftKey&&(e.code===`ShiftLeft`||e.code===`ShiftRight`)||t.ctrlKey&&(e.code===`ControlLeft`||e.code===`ControlRight`)||t.metaKey&&(e.code===`MetaLeft`||e.code===`MetaRight`))}};function Lt(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-dict-result`||typeof e.ok!=`boolean`?!1:e.ok?`entry`in e&&typeof e.entry==`object`:`error`in e&&typeof e.error==`string`}var Rt=/^[\p{L}\p{M}'-]+(?: [\p{L}\p{M}'-]+)?$/u;function zt(e){return e.length<=60&&Rt.test(e)}function Bt(e){return`command`in e?e.command===`get-state`||e.command===`toggle-page-translation`||e.command===`toggle-lens`||e.command===`retranslate-page`:!1}function $(e){return{ok:!1,error:e instanceof Error?e.message:String(e)}}function Vt(e){let t=e.toLowerCase();return e.includes(`API not configured`)||e.includes(`未配置`)?`图片翻译需要外部多模态模型：请先配置 Base URL、API Key 与支持 image 的模型`:t.includes(`image`)&&(t.includes(`not support`)||t.includes(`unsupported`)||t.includes(`invalid`)||t.includes(`不支持`))?e:e.includes(`400`)||t.includes(`invalid_request`)||t.includes(`unknown field`)?`当前模型可能不支持图片输入：${e}`:e}function Ht(e,t){let n=0;return((...r)=>{window.clearTimeout(n),n=window.setTimeout(()=>e(...r),t)})}var Ut=`lens-translator-bubble-shell`,Wt=class{host;frame;pinned=!1;collapseTimer=0;mountObserver;constructor(){this.host=document.createElement(`div`),this.host.id=`lens-translator-bubble-root`,this.host.setAttribute(`data-lens-ignore`,``);let e=this.host.attachShadow({mode:`closed`}),t=document.createElement(`style`);t.textContent=Kt,this.frame=document.createElement(`iframe`),this.frame.src=chrome.runtime.getURL(`src/bubble/index.html`),this.frame.title=`Lens Translator 快捷控制`,this.frame.setAttribute(`allow`,`clipboard-write`),e.append(t,this.frame),this.host.addEventListener(`pointerenter`,()=>this.expand()),this.host.addEventListener(`pointerleave`,()=>this.scheduleCollapse()),window.addEventListener(`message`,this.onMessage),this.mountObserver=new MutationObserver(()=>{this.host.isConnected||this.mount()}),this.mountObserver.observe(document.documentElement,{childList:!0})}mount(){this.host.isConnected||document.documentElement.append(this.host)}setVisible(e){this.host.style.display=e?``:`none`,e||(this.pinned=!1,delete this.host.dataset.expanded)}expand(){window.clearTimeout(this.collapseTimer),this.host.dataset.expanded=`true`}scheduleCollapse(){this.pinned||(window.clearTimeout(this.collapseTimer),this.collapseTimer=window.setTimeout(()=>{delete this.host.dataset.expanded},420))}onMessage=e=>{if(!(e.source!==this.frame.contentWindow||!Gt(e.data))){if(e.data.action===`pin`){this.pinned=!0,this.expand();return}this.pinned=!1,e.data.action===`collapse`?delete this.host.dataset.expanded:this.scheduleCollapse()}}};function Gt(e){if(!e||typeof e!=`object`)return!1;let t=e;return t.type===Ut&&(t.action===`pin`||t.action===`unpin`||t.action===`collapse`)}var Kt=`
  :host { all: initial; }
  iframe {
    display: block;
    width: 100%;
    height: 100%;
    border: 0;
    background: transparent;
  }
  :host {
    position: fixed;
    z-index: 2147483646;
    top: clamp(88px, 42vh, calc(100vh - 88px));
    right: -13px;
    width: 62px;
    height: 62px;
    overflow: hidden;
    pointer-events: auto;
    border-radius: 18px 0 0 18px;
    filter: drop-shadow(0 10px 24px rgb(15 23 42 / 16%));
    transition:
      width 280ms cubic-bezier(.2,.8,.2,1),
      height 280ms cubic-bezier(.2,.8,.2,1),
      right 280ms cubic-bezier(.2,.8,.2,1),
      top 280ms cubic-bezier(.2,.8,.2,1),
      border-radius 220ms ease;
  }
  :host([data-expanded="true"]) {
    top: clamp(12px, calc(50vh - 260px), 28px);
    right: 12px;
    width: min(360px, calc(100vw - 24px));
    height: min(520px, calc(100vh - 24px));
    border-radius: 12px;
  }
  @media (max-width: 520px) {
    :host([data-expanded="true"]) {
      top: 8px;
      right: 8px;
      width: calc(100vw - 16px);
      height: min(520px, calc(100vh - 16px));
    }
  }
  @media (prefers-reduced-motion: reduce) {
    :host { transition-duration: 1ms; }
  }
`,qt=`__lensTranslatorMounted`,Jt=window;async function Yt(){if(Jt[qt])return;Jt[qt]=!0;let e=new It(340),t=new Wt;t.mount(),e.setBubbleVisibilityHandler(e=>t.setVisible(e)),e.bindListeners(),e.ensureMouseSeed(),await e.refreshSettings()}Yt();
//# sourceMappingURL=main.ts-42-T_kAS.js.map
import{i as e,t}from"./settings-defaults-zipe6u-T.js";import{i as n}from"./hotkey-tZ8Jri1V.js";import{n as r,r as i}from"./languages-CqtD30Wb.js";import{i as a,n as o,r as s,t as c}from"./text-BWXmprjd.js";import{a as l,c as u,t as d}from"./vocabulary-CJExWyZ0.js";function f(e,t,n){let r=`${e.toLowerCase()}|${a(t)}|${n}`,i=2166136261;for(let e=0;e<r.length;e++)i^=r.charCodeAt(e),i=Math.imul(i,16777619);return`b_${(i>>>0).toString(36)}`}async function p(e,t,n){let r=e.slice(),i=async()=>{let e=r.shift();e!==void 0&&(await n(e),await i())},a=[];for(let n=0;n<Math.min(t,e.length);n++)a.push(i());await Promise.all(a)}var m=`data-lens-translator-source`,ee=`data-lens-page-segment`,h=[`p`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`li`,`blockquote`,`figcaption`,`caption`,`td`,`th`,`dt`,`dd`,`summary`,`legend`,`address`,`article`],g=[`[role="heading"]`,`[role="listitem"]`,`[role="paragraph"]`,`[role="article"]`,`[role="text"]`],te=`[class*="DraftEditorPlaceholder"], [class*="EditorPlaceholder"], [class*="editor-placeholder"]`,ne=[`a`,`button`,`label`,`summary`,`[role="button"]`,`[role="link"]`,`[role="tab"]`,`[role="menuitem"]`,`[role="menuitemradio"]`,`[role="menuitemcheckbox"]`,`[role="option"]`,`[role="switch"]`].join(`, `),re=`.markdown-body,.markdown-content,.markdown,.md-content,.md-typeset,.prose,.Post-body,.post-content,.entry-content,.article-content,.article-body,.post-body,.rich-text,.RichText,.notion-page-content,[data-testid="post_message"],.message-body,.comment-body,.js-comment-body,.wiki-body,.doc-content,.docs-content,.content__default,.theme-default-content,.vp-doc,.mdx-content,[class*="Markdown"],[class*="markdown"],[class*="ProseMirror"],[class*="DraftEditor"],[class*="ql-editor"],[class*="tiptap"],[class*="slate-"],[data-slate-editor]`.split(`,`),_=/(?:^|[\s_-])(?:paragraph|text-block|textblock|richtext|rich-text|post-body|postbody|entry-content|article-body|md-p|md-block|markdown-p|block-paragraph|block-text|notion-text|notion-page-block|pw-post-body|reader-word|transcript|caption-text|message-text|comment-text|answer-text|question-title|issue-body)(?:$|[\s_-])/i,ie=/paragraph|text|heading|list.?item|quote|callout|toggle|bulleted|numbered|to.?do/i,v=new Set(`a.abbr.b.bdi.bdo.br.cite.code.data.dfn.em.i.kbd.mark.q.rp.rt.ruby.s.samp.small.span.strong.sub.sup.time.u.var.wbr.svg.img.picture.source.font.strike.big.tt.acronym.del.ins.math.mi.mo.mn.mrow.msup.msub`.split(`.`)),y=[`script`,`style`,`noscript`,`template`,`svg`,`canvas`,`video`,`audio`,`iframe`,`object`,`embed`,`textarea`,`input`,`select`,`[contenteditable]:not([contenteditable="false"])`,`[role="textbox"]`,te,`[aria-hidden="true"]`,`[class*="author-name"]`,`[data-testid="User-Name"]`,`[role="tooltip"]`,`tool-tip`,`[data-lens-ignore]`,`[data-lens-page-translation]`,`#lens-translator-root`].join(`, `),ae=new Set(`script.style.noscript.template.svg.canvas.video.audio.iframe.object.embed.textarea.input.select.option.nav.pre.code.br.hr.img.path.meta.link.head.html.body`.split(`.`));function b(e){let t=[],n=e,r=0;for(;n&&r<8;){let e=n.parentElement,i=0;if(e){let t=[...e.children].filter(e=>e.tagName===n.tagName);i=Math.max(0,t.indexOf(n))}let a=n.tagName.toLowerCase();t.push(`${a}[${i}]`),n=e,r++}return`/`+t.reverse().join(`/`)}function x(e,t){let n=e.getBoundingClientRect();if(!S(e,n))return!1;let r=window.innerHeight,i=window.innerWidth;return!(n.bottom<-t||n.top>r+t||n.right<0||n.left>i)}function S(e,t=e.getBoundingClientRect()){if(t.width<2||t.height<2)return!1;let n=window.getComputedStyle(e);return!(n.display===`none`||n.visibility===`hidden`||n.opacity===`0`)}var oe=new Set([`script`,`style`,`noscript`,`template`,`svg`]),se=`script, style, noscript, template, svg, [data-lens-ignore]`;function C(e,t){if(e.hasAttribute?.(`data-lens-ignore`))return``;if(!(typeof document<`u`&&typeof document.createTreeWalker==`function`)||t===void 0&&(typeof e.querySelector!=`function`||!e.querySelector(se))){let n=e.textContent??``;return t!==void 0&&n.length>t?n.slice(0,t):n}let n=document.createTreeWalker(e,4,{acceptNode(t){let n=t.parentElement;for(;n&&n!==e;){if(oe.has(n.tagName.toLowerCase())||n.hasAttribute?.(`data-lens-ignore`))return 2;n=n.parentElement}return 1}}),r=``,i=n.nextNode();for(;i;){if(r+=i.nodeValue??``,t!==void 0&&r.length>t)return r;i=n.nextNode()}return r}function*ce(e){let t=!1;function*n(e){if(e.nodeType===3){e.textContent?.trim()?(yield{node:e,separator:t},t=!1):e.textContent&&(t=!0);return}if(e.nodeType!==1)return;let r=e;if(r.matches(y))return;let i=window.getComputedStyle(r).display;if(i===`none`)return;let a=r.tagName===`BR`||/^(block|flow-root|list-item|table|flex|grid)/.test(i);a&&(t=!0);for(let e of r.childNodes)yield*n(e);a&&(t=!0)}yield*n(e)}function w(e){if(!e.ownerDocument?.createTreeWalker)return a(e.innerText??C(e));let t=``;for(let n of ce(e))t+=(n.separator?` `:``)+n.node.data;return a(t)}function T(e){let t=e.getAttribute(m);return t===null?w(e):a(t)}function E(e){for(let t of e.children){let e=t.tagName.toLowerCase();if(e.includes(`-`)||!v.has(e)||e!==`br`&&e!==`img`&&e!==`source`&&e!==`wbr`&&e!==`path`&&!E(t))return!1}return!0}function le(e){return typeof e.className==`string`?e.className:e.getAttribute(`class`)??``}function ue(e){let t=le(e);if(_.test(t))return!0;let n=e.getAttribute(`data-testid`)||e.getAttribute(`data-test`)||``;if(_.test(n))return!0;let r=e.getAttribute(`data-block-type`)||e.getAttribute(`data-type`)||e.getAttribute(`data-slate-type`)||e.getAttribute(`data-text-type`)||``;if(r&&ie.test(r))return!0;let i=e.getAttribute(`role`)||``;return i===`heading`||i===`listitem`||i===`paragraph`||i===`text`}function de(e){return e.tagName.includes(`-`)}function D(e){let t=0;for(let n of h)if(t+=e.querySelectorAll(n).length,t>3)return t;for(let n of g)if(t+=e.querySelectorAll(n).length,t>3)return t;return t}function O(e){return e.querySelectorAll(`a, button, [role="link"], [role="button"], [role="tab"], [role="menuitem"], [role="menuitemradio"], [role="option"]`).length>1}function k(e){let t=(e.getAttribute(`role`)||``).toLowerCase(),n=e.tagName.toLowerCase(),r=e.closest(ne);if(r&&r!==e&&k(r))return!0;if((n===`a`||t===`link`)&&(e.closest(`p, blockquote, td, th, h1, h2, h3, h4, h5, h6`)||e.closest(`li`)&&!e.closest(`nav, [role="navigation"], [role="menu"]`)))return!1;if(n===`a`||t===`link`){let t=[...e.querySelectorAll(`div, p, h1, h2, h3, h4, h5, h6`)].filter(e=>E(e)&&a(C(e)));if(T(e).length>80||t.length>1)return!1}if(t===`tab`||t===`menuitem`||t===`menuitemradio`||t===`menuitemcheckbox`||t===`option`||t===`button`||t===`link`||t===`switch`||n===`button`||n===`summary`||n===`label`)return!0;if(n===`a`){let t=T(e);if(t.length>0&&t.length<=48)return!0}if(e.closest(`[role="tablist"]`)&&(n===`div`||n===`span`||n===`li`)&&(E(e)||e.children.length===0)){let t=T(e);if(t.length>0&&t.length<=48)return!0}return!1}function fe(e){let t=e.ownerDocument?.createTreeWalker?.(e,4);if(!t)return e;let n=null,r=t.nextNode();for(;r;){let i=r.parentElement;if(i&&a(r.textContent??``)&&!i.closest(y)){if(n&&n!==i)return e;n=i}r=t.nextNode()}return n??e}function pe(e,t){let n=e.tagName.toLowerCase(),r=T(e);if(ae.has(n)||!s(r,t))return!1;if(E(e))return!O(e);if(ue(e)){let n=D(e);if(n<=2&&r.length<=2e3||n===0&&r.length>=t&&r.length<=1500)return!0}if(de(e)){let n=D(e);if(n===0&&E(e)||n<=1&&r.length<=1200&&r.length>=t)return!0}return!1}function me(e,t){return D(e)>1&&T(e).length>t*2}function A(e,t=!1){if(e.closest(`#lens-translator-root`))return!0;let n=e.closest(`shreddit-comment`);if(n){let t=e.closest(`[slot="comment"]`),r=e.closest(`shreddit-comment-action-row, [slot="comment-action-row"], [slot="actionRow"]`);if((!t||t.closest(`shreddit-comment`)!==n)&&!r)return!0}if(!t&&!e.hasAttribute(`data-lens-translator-source`)&&e.querySelector(`[data-lens-page-inserted]`)||e.parentElement?.closest(`[data-lens-page-translated], [data-lens-page-pending]`)||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`||e.closest(y))return!0;let r=e.tagName.toLowerCase();return!!ae.has(r)}function he(e=document){let t=[],n=new Set,r=e=>{for(let r of e)n.has(r)||(n.add(r),t.push(r))};r(e.querySelectorAll(h.join(`,`))),r(e.querySelectorAll(g.join(`,`))),r(e.querySelectorAll(ne)),r(e.querySelectorAll(`[${ee}]`));for(let t of e.querySelectorAll(re.join(`,`)))r(t.querySelectorAll(h.join(`,`))),r(t.querySelectorAll(`:scope > div, :scope > span, :scope > section`)),r(t.querySelectorAll(`div > p, div > li, div > h1, div > h2, div > h3, section > p`));return r(e.querySelectorAll([`[data-block-type]`,`[data-slate-type]`,`[data-text-type]`,`[class*="paragraph"]`,`[class*="Paragraph"]`,`[class*="text-block"]`,`[class*="TextBlock"]`,`[class*="notion-text"]`,`[class*="markdown"] p`,`[class*="Markdown"] p`,`[class*="prose"] p`,`[class*="prose"] li`].join(`,`))),t}function j(e,t,n){let r=k(e);r&&(e=fe(e));let i=r?1:t;if(A(e)||(n===null?!S(e):!x(e,n)))return;let o=e.tagName.toLowerCase(),c=h.includes(o),l=e.getAttribute(`role`)||``,u=e.parentElement;if(!r&&u&&typeof window<`u`&&typeof window.getComputedStyle==`function`){let e=window.getComputedStyle(u);if(e.display?.includes(`flex`)&&e.flexDirection?.startsWith(`row`)){let e=0;for(let t of u.children)if(a(C(t)).length>0&&e++,e>1)return}}if(c||l===`heading`||l===`listitem`||l===`paragraph`||l===`text`){if(!s(T(e),i)||me(e,t)||O(e)&&(o===`article`||o===`li`&&e.closest(`nav, aside, [role="navigation"], [role="complementary"]`)))return}else if(!r&&!pe(e,i))return;let d=T(e);if(s(d,i))return{id:f(o,d,b(e)),el:e,tag:o,text:d}}function ge(e,t,n){let r=e.querySelector(`br + br`);if(!r)return null;if(A(e,!0)||(n===null?!S(e):!x(e,n)))return[];let i=r.parentElement;if(!i)return null;let o=[...i.childNodes],c=[],l=0;for(let e=0;e<o.length-1;e++)o[e].nodeType===1&&o[e].tagName.toLowerCase()===`br`&&o[e+1].nodeType===1&&o[e+1].tagName.toLowerCase()===`br`&&(c.push(o.slice(l,e)),e++,l=e+1);c.push(o.slice(l));let u=e.tagName.toLowerCase(),d=[];for(let e of c){let i=e.filter(e=>!(e.nodeType===1&&e.hasAttribute?.(`data-lens-ignore`))),o=i.find(e=>e.nodeType===1&&e.hasAttribute?.(`data-lens-page-segment`));if(o){let e=j(o,t,n);e&&d.push(e);continue}let c=a(i.map(e=>e.textContent??``).join(``));if(!s(c,t))continue;let l=i.find(e=>e.nodeType===1&&e.tagName.toLowerCase()!==`br`)??r;d.push({id:f(u,c,b(l)),el:l,tag:u,text:c,segmentNodes:i})}return d.length>=2?d:null}var _e=4e3,ve=new Set([`script`,`style`,`noscript`,`template`,`canvas`,`video`,`audio`,`iframe`,`object`,`embed`,`textarea`,`input`,`select`,`option`,`br`,`hr`,`img`,`path`,`meta`,`link`,`head`,`html`,`body`,`svg`]),ye=`script, style, noscript, template, canvas, video, audio, iframe, object, embed, textarea, input, select, [data-lens-ignore], #lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt`;function be(e){if(e.closest(ye)||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`)return!0;let t=e.tagName.toLowerCase();return!!ve.has(t)}function xe(e,t){return t.length<280?!1:e.querySelectorAll(`p, li, h1, h2, h3, h4, h5, h6, tr, blockquote, pre, section, article`).length>=4}function Se(e,t){return k(e)?1:Math.max(1,Math.min(t,2))}function Ce(e,t=1){let n=e;for(;n!==null;){let e=n,r=e.tagName.toLowerCase();if(r===`html`||r===`body`)break;let i=!0;if(!be(e)){try{i=S(e)}catch{i=!0}if(i){let n=a(C(e,4001));if(s(n,Se(e,t))&&n.length<=4e3&&!xe(e,n))return{id:f(r,n,b(e)),el:e,tag:r,text:n}}}n=e.parentElement}}var we=new Set([``,`text`,`search`,`url`,`email`]);function Te(e,t=_e){let n=e?.closest(`textarea, input, [contenteditable]:not([contenteditable="false"])`);if(!n||n.closest(`[data-lens-ignore], #lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt`))return null;let r=n.tagName.toLowerCase();if(r===`textarea`){let e=n,r=a(e.value);return!r||r.length>t?null:{el:e,kind:`textarea`,text:r,writable:!e.disabled&&!e.readOnly}}if(r===`input`){let e=n;if(!we.has(e.type))return null;let r=a(e.value);return!r||r.length>t?null:{el:e,kind:`input`,text:r,writable:!e.disabled&&!e.readOnly}}if(n.isContentEditable){let e=a(C(n,t+1));return!e||e.length>t?null:{el:n,kind:`contenteditable`,text:e,writable:!0}}return null}function Ee(e,t,n=1){let r=null;try{let n=document;if(typeof n.caretRangeFromPoint==`function`){let i=n.caretRangeFromPoint(e,t)?.startContainer;i&&(r=i.nodeType===Node.TEXT_NODE?i.parentElement:i instanceof Element?i:null)}else if(typeof n.caretPositionFromPoint==`function`){let i=n.caretPositionFromPoint(e,t)?.offsetNode;i&&(r=i.nodeType===Node.TEXT_NODE?i.parentElement:i instanceof Element?i:null)}}catch{}if(!r)try{r=document.elementsFromPoint(e,t).find(e=>e.id!==`lens-translator-root`&&!e.closest?.(`#lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root`)&&!be(e))??null}catch{r=null}return Ce(r,n)||De(r,n)}function De(e,t){let n=e;for(;n&&n.tagName.toLowerCase()!==`html`;){let e=j(n,t,0);if(e)return e;n=n.parentElement}}function Oe(e,t){return M(document,e,t)}function ke(e,t=document){let n=Ae(t),r=n.flatMap(t=>M(t,e,null)),i=new Set(r.map(e=>e.segmentNodes?.[0]?.parentElement??e.el)),a=n.flatMap(t=>Ne(t,e,i));return Pe([...r,...a])}function Ae(e=document){let t=[e];`shadowRoot`in e&&e.shadowRoot&&!A(e)&&t.push(e.shadowRoot);for(let e=0;e<t.length;e++)for(let n of t[e].querySelectorAll(`*`))n.shadowRoot&&!A(n)&&t.push(n.shadowRoot);return t}function je(e){let t=e.parentElement;if(!t)return null;let n=t;for(;v.has(n.tagName.toLowerCase());){let e=n.parentElement;if(!e||e.tagName.toLowerCase()===`body`)break;n=e}let r=n.tagName.toLowerCase();return r===`html`||r===`body`?null:n}function Me(e,t){let n=e;for(;n;){if(t.has(n))return!0;n=n.parentElement}return!1}function Ne(e,t,n){let r=new Set,i=document.createTreeWalker(e,4),o=i.nextNode();for(;o;){let e=o,t=a(e.data),s=e.parentElement;if(t&&s&&!s.closest?.(`[data-lens-ignore]`)&&!Me(s,n)){let t=je(e);t&&!A(t)&&r.add(t)}o=i.nextNode()}let c=[];for(let e of r){if(!S(e))continue;let r=T(e);if(!s(r,t))continue;let i=e.tagName.toLowerCase(),a=(i===`ul`||i===`ol`)&&!e.querySelector(`li, ul, ol`);if(i!==`div`&&i!==`section`&&i!==`article`&&!a||O(e)&&(!e.matches(`article, [role="article"]`)||r.length<20))continue;if(typeof window<`u`&&typeof window.getComputedStyle==`function`){let t=window.getComputedStyle(e);if(t.display?.includes(`flex`)&&t.flexDirection?.startsWith(`row`))continue;let n=e.parentElement;if(n){let e=window.getComputedStyle(n);if(e.display?.includes(`flex`)&&e.flexDirection?.startsWith(`row`))continue}}let o={id:f(i,r,b(e)),el:e,tag:i,text:r};c.push(o),n.add(e)}return c}function M(e,t,n){let r=he(e);typeof Element<`u`&&e instanceof Element&&r.unshift(e);let i=[],a=new Set,o=new Set;for(let e of r){if(o.has(e))continue;let r=ge(e,t,n)??[j(e,t,n)].filter(e=>e!==void 0);for(let e of r){let t=e.segmentNodes?.[0]??e.el;a.has(e.id)||o.has(t)||(a.add(e.id),o.add(t),i.push(e))}}return Pe(i)}function Pe(e){if(e.length<=1)return e;let t=new Map(e.map(e=>[e.el,e])),n=new Set,r=new Set(e.filter(e=>h.includes(e.tag)&&E(e.el))),i=new Set;for(let n of e){let e=n.el.parentElement;for(;e;){let n=t.get(e);n&&i.add(n),e=e.parentElement}}let a=new Map;for(let n of e){if(i.has(n))continue;let e=n.el.parentElement;for(;e;){let r=t.get(e);r&&a.set(r,(a.get(r)??r.text).replace(n.text,` `)),e=e.parentElement}}for(let e of i)r.has(e)||/[\p{L}\p{N}]/u.test(a.get(e)??e.text)||n.add(e);let o=e.filter(e=>!n.has(e)),s=new Set(o.filter(e=>!e.segmentNodes).map(e=>e.el));return o.filter(e=>{let t=e.el.parentElement;for(;t;){if(s.has(t))return!1;t=t.parentElement}return!0})}var Fe=class{byId=new Map;byEl=new WeakMap;byNormText=new Map;maxEntries;maxTranslations;constructor(e=1500,t=2500){this.maxEntries=Math.max(1,e),this.maxTranslations=Math.max(1,t)}upsert(e){let t=this.byId.get(e.id);t||this.makeRoom();let n=a(e.text),r=this.byNormText.get(n),i={id:e.id,el:e.el,tag:e.tag,text:e.text,status:e.status??t?.status??`pending`,translation:t?.translation,error:t?.error};return t&&t.text===i.text&&t.translation?(i.translation=t.translation,i.status=`ready`):r&&(i.translation=r,i.status=`ready`,i.error=void 0),this.byId.set(i.id,i),this.byEl.set(i.el,i.id),i}setTranslation(e,t){let n=this.byId.get(e);if(!n)return;let r=a(n.text);for(this.byNormText.delete(r),this.byNormText.set(r,t);this.byNormText.size>this.maxTranslations;){let e=this.byNormText.keys().next().value;if(e===void 0)break;this.byNormText.delete(e)}for(let e of this.byId.values())a(e.text)===r&&(e.translation=t,e.status=`ready`,e.error=void 0)}setError(e,t){let n=this.byId.get(e);n&&(n.status=`error`,n.error=t)}setPending(e){let t=this.byId.get(e);t&&t.status!==`ready`&&(t.status=`pending`)}get(e){return this.byId.get(e)}getByElement(e){if(!e)return;let t=e;for(;t;){let e=this.byEl.get(t);if(e)return this.byId.get(e);t=t.parentElement}}pendingBlocks(){return[...this.byId.values()].filter(e=>e.status===`pending`).map(e=>({id:e.id,tag:e.tag,text:e.text}))}resetTranslationsToPending(){this.byNormText.clear();for(let e of this.byId.values())e.status=`pending`,e.translation=void 0,e.error=void 0}makeRoom(){if(!(this.byId.size<this.maxEntries)){for(let[e,t]of this.byId)t.el.isConnected||this.byId.delete(e);for(;this.byId.size>=this.maxEntries;){let e=this.byId.keys().next().value;if(e===void 0)break;this.byId.delete(e)}}}},Ie=class e{host;root;panel;textLayer;sourceLabel;sourceBody;zhLabel;body;divider;hint;ring;toolbar;starBtn;speakSourceBtn;speakTargetBtn;dictCard;actionRow;actionBtn;actionHandler=null;starHandler=null;speakHandler=null;highlightEl=null;widthPx;lastSourceKey=``;sourceLangLabel=`源语言`;targetLangLabel=`译文`;constructor(t=340){this.widthPx=t,this.host=document.createElement(`div`),this.host.id=`lens-translator-root`,Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,pointerEvents:`none`,zIndex:`2147483647`}),this.root=this.host.attachShadow({mode:`open`});let n=document.createElement(`style`);n.textContent=Le;let r=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);r.setAttribute(`aria-hidden`,`true`),r.setAttribute(`width`,`0`),r.setAttribute(`height`,`0`),r.style.position=`absolute`,r.innerHTML=`
      <defs>
        <filter id="glass-distortion" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.008 0.008" numOctaves="2" seed="3" result="noise" />
          <feGaussianBlur in="noise" stdDeviation="0.5" result="softNoise" />
          <feDisplacementMap in="SourceGraphic" in2="softNoise" scale="12" xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </defs>
    `,this.ring=document.createElement(`div`),this.ring.className=`source-outline`,this.ring.style.display=`none`,this.panel=document.createElement(`div`),this.panel.className=`liquidGlass-wrapper panel`,this.panel.style.display=`none`;let i=document.createElement(`div`);i.className=`liquidGlass-effect`;let a=document.createElement(`div`);a.className=`liquidGlass-tint`;let o=document.createElement(`div`);o.className=`liquidGlass-shine`,this.textLayer=document.createElement(`div`),this.textLayer.className=`liquidGlass-text`,this.sourceLabel=document.createElement(`div`),this.sourceLabel.className=`label label-source`,this.sourceLabel.textContent=this.sourceLangLabel,this.sourceBody=document.createElement(`div`),this.sourceBody.className=`body body-source`,this.divider=document.createElement(`div`),this.divider.className=`divider`,this.zhLabel=document.createElement(`div`),this.zhLabel.className=`label label-target`,this.zhLabel.textContent=this.targetLangLabel,this.body=document.createElement(`div`),this.body.className=`body body-zh`,this.hint=document.createElement(`div`),this.hint.className=`hint`,this.toolbar=document.createElement(`div`),this.toolbar.className=`toolbar`,this.starBtn=e.iconButton(`star`,`收藏到生词本`),this.starBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.starHandler?.()}),this.speakSourceBtn=e.iconButton(`speak`,`朗读原文`),this.speakSourceBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.speakHandler?.(`source`)}),this.speakTargetBtn=e.iconButton(`speak`,`朗读译文`),this.speakTargetBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.speakHandler?.(`target`)}),this.toolbar.append(this.starBtn,this.speakSourceBtn,this.speakTargetBtn),this.dictCard=document.createElement(`div`),this.dictCard.className=`dict-card`,this.actionRow=document.createElement(`div`),this.actionRow.className=`action-row`,this.actionBtn=document.createElement(`button`),this.actionBtn.type=`button`,this.actionBtn.className=`action-btn`,this.actionBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.actionHandler?.()}),this.actionRow.append(this.actionBtn),this.textLayer.append(this.toolbar,this.sourceLabel,this.sourceBody,this.divider,this.zhLabel,this.body,this.dictCard,this.actionRow,this.hint),this.panel.append(i,a,o,this.textLayer),this.root.append(n,r,this.ring,this.panel),this.applyWidth()}applyWidth(){this.panel.style.width=`${this.widthPx}px`,this.panel.style.maxWidth=`${this.widthPx}px`}static iconButton(e,t){let n=document.createElement(`button`);return n.type=`button`,n.className=`icon-btn icon-${e}`,n.title=t,n.setAttribute(`aria-label`,t),n.textContent=e===`star`?`☆`:`🔊`,n}onAction(e){this.actionHandler=e}onStar(e){this.starHandler=e}onSpeak(e){this.speakHandler=e}setStarActive(e){this.starBtn.textContent=e?`★`:`☆`,this.starBtn.classList.toggle(`is-active`,e)}mount(){this.host.isConnected||document.documentElement.appendChild(this.host)}setWidth(e){this.widthPx=Math.max(280,e),this.applyWidth()}setLanguageLabels(e,t){this.sourceLangLabel=e||`源语言`,this.targetLangLabel=t||`译文`,this.sourceLabel.textContent=this.sourceLangLabel,this.zhLabel.textContent=this.targetLangLabel}setFontSize(e){let t=Math.max(10,Math.min(28,e));this.host.style.setProperty(`--lens-zh-size`,`${t+2.5}px`),this.host.style.setProperty(`--lens-en-size`,`${t+.5}px`)}setFontFamily(e){let t={system:`-apple-system, BlinkMacSystemFont, 'SF Pro Text', system-ui, sans-serif`,sans:`Inter, ui-sans-serif, system-ui, sans-serif`,serif:`Georgia, 'Times New Roman', serif`,mono:`'SFMono-Regular', Consolas, 'Liberation Mono', monospace`}[e];this.host.style.setProperty(`--lens-font-family`,t)}setAppearance(e){let t=typeof matchMedia==`function`&&matchMedia(`(prefers-color-scheme: dark)`).matches?`rgba(242, 244, 247, 0.96)`:`rgba(20, 24, 32, 0.94)`;this.host.style.setProperty(`--lens-target-color`,e.pageTranslationUseCustomColor?e.pageTranslationTextColor:t),this.host.style.setProperty(`--lens-target-background`,e.pageTranslationUseBackground?e.pageTranslationBackgroundColor:`transparent`),this.host.style.setProperty(`--lens-target-padding`,e.pageTranslationUseBackground?`6px 8px`:`0`),this.host.style.setProperty(`--lens-target-radius`,e.pageTranslationUseBackground?`4px`:`0`),this.host.style.setProperty(`--lens-target-weight`,e.pageTranslationBold?`700`:`520`),this.host.style.setProperty(`--lens-target-style`,e.pageTranslationItalic?`italic`:`normal`),this.host.style.setProperty(`--lens-target-decoration`,e.pageTranslationUnderline?`underline`:`none`)}showAt(e,t,n){this.mount(),this.panel.style.display=`flex`,this.panel.classList.add(`is-visible`),this.body.classList.remove(`muted`,`pending-anim`),this.sourceBody.classList.remove(`muted`);let r=n.kind===`dict`,i=n.kind===`editable`,a=`sourceText`in n&&n.sourceText?n.sourceText:``,o=n.kind===`ready`?n.text:i&&n.status===`ready`?n.translation:null,s=!!a&&!r;switch(this.sourceLabel.hidden=!s,this.sourceBody.hidden=!s,this.divider.hidden=!s,this.zhLabel.hidden=r||n.kind===`empty`||n.kind===`target-language`||n.kind===`unconfigured`,s?this.sourceBody.textContent=a:this.sourceBody.textContent=``,this.dictCard.hidden=!r,r&&this.renderDictCard(n.entry),this.actionRow.hidden=!(i&&n.status===`ready`&&n.writable&&n.translation),n.kind){case`ready`:this.zhLabel.textContent=this.targetLangLabel,this.body.textContent=n.text;break;case`pending`:this.zhLabel.textContent=this.targetLangLabel,this.body.classList.add(`muted`,`pending-anim`),this.body.textContent=`翻译中…`;break;case`empty`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`此处无可译文本（请移到文字上）`;break;case`target-language`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`此段已是目标语言`;break;case`error`:this.zhLabel.textContent=this.targetLangLabel,this.body.classList.add(`muted`),this.body.textContent=n.message;break;case`unconfigured`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`翻译引擎未就绪，请下载语言包或配置外部 LLM`;break;case`editable`:this.zhLabel.textContent=`回译`,n.status===`pending`?(this.body.classList.add(`muted`,`pending-anim`),this.body.textContent=`回译中…`):n.status===`error`?(this.body.classList.add(`muted`),this.body.textContent=n.error??`回译失败`):this.body.textContent=n.translation??``;break;case`dict`:this.body.textContent=``;break}this.hint.textContent=i?`「替换为译文」会改写输入框全部内容 · Esc 关闭`:`可选择文本复制 · Esc 关闭`,this.starBtn.hidden=!(n.kind===`ready`||r||i&&n.status===`ready`),this.speakSourceBtn.hidden=!a,this.speakTargetBtn.hidden=!o,this.toolbar.hidden=this.starBtn.hidden&&this.speakSourceBtn.hidden&&this.speakTargetBtn.hidden;let c=`sourceRect`in n&&n.sourceRect?n.sourceRect:null;if(c){let r=`${n.kind}:${a.length}:${`text`in n&&n.text?n.text.length:0}:${`message`in n&&n.message?n.message.length:0}:${`translation`in n&&n.translation?n.translation.length:0}:${`entry`in n?n.entry.senses.length*100+n.entry.examples.length*10:0}`,i=`${Math.round(c.left)}|${Math.round(c.top)}|${Math.round(c.right)}|${Math.round(c.bottom)}|${r}`;i!==this.lastSourceKey&&(this.lastSourceKey=i,this.placePanel(e,t,c))}else this.lastSourceKey=``,this.placePanel(e,t,null)}renderDictCard(e){let t=document.createElement(`div`);t.className=`dict-word`,t.textContent=e.word;let n=[t];if(e.phonetic){let n=document.createElement(`span`);n.className=`dict-phonetic`,n.textContent=e.phonetic,t.append(n)}let r=document.createElement(`ol`);r.className=`dict-senses`;for(let t of e.senses){let e=document.createElement(`li`);if(t.pos){let n=document.createElement(`span`);n.className=`dict-pos`,n.textContent=t.pos,e.append(n)}e.append(document.createTextNode(t.gloss)),r.append(e)}if(n.push(r),e.examples.length){let t=document.createElement(`div`);t.className=`dict-examples`;for(let n of e.examples){let e=document.createElement(`div`);e.className=`dict-example`;let r=document.createElement(`div`);r.className=`dict-example-source`,r.textContent=n.source;let i=document.createElement(`div`);i.className=`dict-example-translation`,i.textContent=n.translation,e.append(r,i),t.append(e)}n.push(t)}this.dictCard.replaceChildren(...n)}placePanel(e,t,n){let r=window.innerWidth,i=window.innerHeight,a=this.panel.getBoundingClientRect(),o=Math.max(a.width,this.widthPx),s=Math.max(a.height,80),c=e+16,l=t+16;if(n&&n.width>0){let a=[];a.push({left:N(n.left,8,r-o-8),top:n.bottom+12,score:4}),a.push({left:N(n.left,8,r-o-8),top:n.top-s-12,score:3}),a.push({left:n.right+12,top:N(n.top,8,i-s-8),score:2}),a.push({left:n.left-o-12,top:N(n.top,8,i-s-8),score:1});let u=null;for(let e of a){if(!(e.left>=8&&e.top>=8&&e.left+o<=r-8&&e.top+s<=i-8))continue;let t={left:e.left,top:e.top,right:e.left+o,bottom:e.top+s},a=!(t.right<n.left-4||t.left>n.right+4||t.bottom<n.top-4||t.top>n.bottom+4),c=e.score+(a?-10:0);(!u||c>u.score)&&(u={...e,score:c})}u?(c=u.left,l=u.top):(c=N(e+16,8,r-o-8),l=N(t+16,8,i-s-8),n&&(l=N(n.bottom+12,8,i-s-8)))}else c=N(c,8,r-o-8),l=N(l,8,i-s-8);this.panel.style.left=`${c}px`,this.panel.style.top=`${l}px`}hide(){this.panel.style.display=`none`,this.panel.classList.remove(`is-visible`),this.lastSourceKey=``,this.clearHighlight()}getHost(){return this.host}highlight(e){if(this.highlightEl===e){e&&this.positionRing(e);return}if(this.highlightEl=e,!e){this.ring.style.display=`none`;return}this.positionRing(e)}reposition(){this.highlightEl&&this.positionRing(this.highlightEl)}positionRing(e){if(!e.isConnected){this.ring.style.display=`none`;return}let t=e.getBoundingClientRect(),n=t.bottom<=0||t.right<=0||t.top>=window.innerHeight||t.left>=window.innerWidth;if(t.width<1||t.height<1||n){this.ring.style.display=`none`;return}this.ring.style.display=`block`,this.ring.style.left=`${t.left-3}px`,this.ring.style.top=`${t.top-3}px`,this.ring.style.width=`${t.width+6}px`,this.ring.style.height=`${t.height+6}px`}clearHighlight(){this.highlightEl=null,this.ring.style.display=`none`}};function N(e,t,n){return Math.max(t,Math.min(n,e))}var Le=`
  :host, * { box-sizing: border-box; }

  .liquidGlass-wrapper {
    position: fixed;
    display: flex;
    overflow: hidden;
    padding: 0.85rem 1rem;
    border-radius: 14px;
    box-shadow:
      0 10px 32px rgba(15, 23, 42, 0.14),
      0 2px 8px rgba(15, 23, 42, 0.06),
      0 0 0 1px rgba(15, 23, 42, 0.06);
    transition: box-shadow 0.2s ease, transform 0.2s ease;
    font: 16px/1.55 var(--lens-font-family, Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, system-ui, sans-serif);
    -webkit-font-smoothing: antialiased;
    color: rgba(20, 24, 32, 0.94);
  }

  .liquidGlass-wrapper.is-visible {
    animation: glassIn 0.28s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }

  @keyframes glassIn {
    from { opacity: 0; transform: scale(0.96) translateY(4px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
  }

  .liquidGlass-effect {
    position: absolute;
    z-index: 0;
    inset: 0;
    border-radius: inherit;
    backdrop-filter: blur(16px) saturate(140%);
    -webkit-backdrop-filter: blur(16px) saturate(140%);
    isolation: isolate;
  }

  .liquidGlass-tint {
    position: absolute;
    z-index: 1;
    inset: 0;
    border-radius: inherit;
    background: rgba(255, 255, 255, 0.94);
  }

  .liquidGlass-shine {
    position: absolute;
    z-index: 2;
    inset: 0;
    border-radius: inherit;
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.7);
    pointer-events: none;
  }

  .liquidGlass-text {
    position: relative;
    z-index: 3;
    width: 100%;
    min-width: 0;
  }

  .panel {
    flex-direction: column;
    max-height: min(440px, 58vh);
    background: transparent;
    pointer-events: auto;
    user-select: text;
  }

  .panel .body,
  .panel .hint {
    cursor: text;
  }

  .panel .liquidGlass-text {
    overflow: auto;
    max-height: min(420px, 54vh);
  }

  .label {
    font-size: 10.5px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: rgba(91, 100, 114, 0.95);
    margin-bottom: 4px;
  }

  .label-target {
    margin-top: 2px;
  }

  .divider {
    height: 1px;
    margin: 10px 0;
    background: rgba(15, 23, 42, 0.08);
  }

  .body {
    white-space: pre-wrap;
    word-break: break-word;
    font-size: var(--lens-zh-size, 16.5px);
    line-height: 1.55;
    color: rgba(20, 24, 32, 0.94);
    font-weight: 520;
  }

  .body-source {
    font-size: var(--lens-en-size, 14.5px);
    line-height: 1.5;
    color: rgba(91, 100, 114, 0.95);
    font-weight: 450;
  }

  .body-zh,
  .body-target {
    font-size: var(--lens-zh-size, 16.5px);
    color: var(--lens-target-color, rgba(20, 24, 32, 0.94));
    background: var(--lens-target-background, transparent);
    padding: var(--lens-target-padding, 0);
    border-radius: var(--lens-target-radius, 0);
    font-weight: var(--lens-target-weight, 520);
    font-style: var(--lens-target-style, normal);
    text-decoration: var(--lens-target-decoration, none);
  }

  .body.muted {
    color: rgba(91, 100, 114, 0.95);
    font-weight: 400;
  }

  .hint {
    margin-top: 10px;
    font-size: 11.5px;
    color: rgba(139, 147, 160, 0.98);
    line-height: 1.4;
  }

  .toolbar {
    position: absolute;
    top: 6px;
    right: 8px;
    display: flex;
    gap: 2px;
    z-index: 4;
  }

  .icon-btn {
    appearance: none;
    border: 0;
    border-radius: 6px;
    background: transparent;
    padding: 3px 5px;
    font-size: 13px;
    line-height: 1;
    color: rgba(91, 100, 114, 0.95);
    cursor: pointer;
  }
  .icon-btn:hover { background: rgba(15, 23, 42, 0.07); }
  .icon-btn.is-active { color: #d97706; }

  .action-row {
    margin-top: 10px;
    display: flex;
    justify-content: flex-end;
  }

  .action-btn {
    appearance: none;
    border: 0;
    border-radius: 8px;
    background: #2563eb;
    color: #fff;
    font-size: 12.5px;
    font-weight: 600;
    padding: 7px 12px;
    cursor: pointer;
  }
  .action-btn:hover { background: #1d4ed8; }

  .dict-card {
    min-width: 0;
  }
  .dict-word {
    font-size: var(--lens-zh-size, 17px);
    font-weight: 700;
    color: rgba(20, 24, 32, 0.96);
    margin-bottom: 6px;
  }
  .dict-phonetic {
    margin-left: 8px;
    font-size: 12px;
    font-weight: 400;
    color: rgba(91, 100, 114, 0.95);
  }
  .dict-senses {
    margin: 0 0 6px;
    padding-left: 20px;
    font-size: 13.5px;
    line-height: 1.55;
  }
  .dict-senses li { margin-bottom: 2px; }
  .dict-pos {
    display: inline-block;
    margin-right: 6px;
    padding: 0 5px;
    border-radius: 4px;
    background: rgba(37, 99, 235, 0.1);
    color: #1d4ed8;
    font-size: 10.5px;
    font-weight: 700;
    font-style: italic;
  }
  .dict-examples {
    margin-top: 8px;
    border-top: 1px solid rgba(15, 23, 42, 0.08);
    padding-top: 8px;
  }
  .dict-example { margin-bottom: 6px; }
  .dict-example-source {
    font-size: 12.5px;
    color: rgba(20, 24, 32, 0.94);
  }
  .dict-example-translation {
    font-size: 12px;
    color: rgba(91, 100, 114, 0.95);
  }

  .source-outline {
    position: fixed;
    pointer-events: none;
    border-radius: 6px;
    border: 1.5px solid rgba(23, 105, 224, 0.55);
    box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.45);
    background: transparent;
  }

  @keyframes lens-pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
  }

  .pending-anim {
    animation: lens-pulse 1.1s ease-in-out infinite;
  }

  @media (prefers-color-scheme: dark) {
    .liquidGlass-wrapper {
      color: rgba(242, 244, 247, 0.96);
      box-shadow:
        0 12px 36px rgba(0, 0, 0, 0.45),
        0 0 0 1px rgba(255, 255, 255, 0.08);
    }
    .liquidGlass-tint {
      background: rgba(24, 27, 33, 0.94);
    }
    .liquidGlass-shine {
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.06);
    }
    .label { color: rgba(168, 176, 189, 0.95); }
    .divider { background: rgba(255, 255, 255, 0.08); }
    .body { color: rgba(242, 244, 247, 0.96); }
    .body-source { color: rgba(168, 176, 189, 0.95); }
    .body-zh,
    .body-target {
      color: var(--lens-target-color, rgba(242, 244, 247, 0.96));
    }
    .body.muted { color: rgba(168, 176, 189, 0.9); }
    .hint { color: rgba(123, 132, 148, 0.98); }
    .icon-btn { color: rgba(168, 176, 189, 0.95); }
    .icon-btn:hover { background: rgba(255, 255, 255, 0.1); }
    .dict-word { color: rgba(242, 244, 247, 0.96); }
    .dict-phonetic { color: rgba(168, 176, 189, 0.95); }
    .dict-example-source { color: rgba(242, 244, 247, 0.96); }
    .dict-example-translation { color: rgba(168, 176, 189, 0.95); }
    .dict-examples { border-top-color: rgba(255, 255, 255, 0.08); }
    .source-outline {
      border-color: rgba(77, 142, 240, 0.7);
      box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.35);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .liquidGlass-wrapper.is-visible { animation: none; }
    .pending-anim { animation: none; }
  }
`,Re=class{byId=new Map;byUrl=new Map;maxEntries;maxTranslations;constructor(e=300,t=500){this.maxEntries=Math.max(1,e),this.maxTranslations=Math.max(1,t)}upsert(e,t,n){let r=this.byId.get(e);r||this.makeRoom();let i=this.byUrl.get(n),a={id:e,el:t,url:n,status:r?.status??(i?`ready`:`pending`),translation:r?.translation??i,error:r?.error};return a.translation&&(a.error=void 0),this.byId.set(e,a),a}get(e){return this.byId.get(e)}setPending(e){let t=this.byId.get(e);t&&(t.status=`pending`,t.error=void 0)}setTranslation(e,t){let n=this.byId.get(e);if(n){for(this.byUrl.delete(n.url),this.byUrl.set(n.url,t);this.byUrl.size>this.maxTranslations;){let e=this.byUrl.keys().next().value;if(e===void 0)break;this.byUrl.delete(e)}for(let e of this.byId.values())e.url===n.url&&(e.translation=t,e.status=`ready`,e.error=void 0)}}setError(e,t){let n=this.byId.get(e);!n||n.translation||(n.status=`error`,n.error=t)}makeRoom(){if(!(this.byId.size<this.maxEntries)){for(let[e,t]of this.byId)t.el.isConnected||this.byId.delete(e);for(;this.byId.size>=this.maxEntries;){let e=this.byId.keys().next().value;if(e===void 0)break;this.byId.delete(e)}}}};function P(e=location){return`${e.origin}${e.pathname}`}var ze=class{flush;windowMs;pending=new Map;timer=null;constructor(e,t=80){this.flush=e,this.windowMs=t}enqueue(e){this.pending.set(e.id,e),this.timer===null&&(this.timer=setTimeout(()=>{this.timer=null;let e=[...this.pending.values()];this.pending.clear(),e.length&&this.flush(e)},this.windowMs))}},F=`lens-page-alignment-match`,I=`data-lens-page-alignment-source`,Be=`lens-translator-page-alignment-overlay`;function Ve(e){let t=[];for(let n of e.matchAll(/\p{Script=Han}|[\p{L}\p{M}\p{N}_'-]+/gu)){let e=n.index;t.push({text:n[0],start:e,end:e+n[0].length})}return t}function L(e,t){if(typeof Intl.Segmenter!=`function`)return Ve(e);let n=new Intl.Segmenter(t,{granularity:`word`}),r=[];for(let t of n.segment(e))t.isWordLike&&r.push({text:t.segment,start:t.index,end:t.index+t.segment.length});return r}function He(e,t){let n=L(e,t),r=[],i=0;for(let t=0;t<n.length;t++){let a=n[t];a.start>i&&r.push({text:e.slice(i,a.start),start:i,end:a.start,wordIndex:null}),r.push({...a,wordIndex:t}),i=a.end}return i<e.length&&r.push({text:e.slice(i),start:i,end:e.length,wordIndex:null}),r}function Ue(e){return e.normalize(`NFKD`).replace(/\p{M}/gu,``).toLocaleLowerCase().replace(/[^\p{L}\p{N}]/gu,``)}function We(e,t){let n=Array.from({length:t.length+1},(e,t)=>t);for(let r=1;r<=e.length;r++){let i=n[0];n[0]=r;for(let a=1;a<=t.length;a++){let o=n[a];n[a]=Math.min(n[a]+1,n[a-1]+1,i+(e[r-1]===t[a-1]?0:1)),i=o}}return n[t.length]}function Ge(e,t){if(!e||!t)return 0;if(e===t)return 1;let n=Math.min(e.length,t.length),r=Math.max(e.length,t.length);return n>=3&&(e.includes(t)||t.includes(e))?Math.min(.9,.2+n/r):Math.max(0,1-We(e,t)/r)}function Ke(e,t,n){if(!e.length)return null;let r=(t+.5)/Math.max(1,n),i=Math.min(e.length-1,Math.floor(r*e.length));return{start:e[i].start,end:e[i].end}}function R(e,t,n,r,i){let a=L(e,i),o=Ke(a,n,r),s=L(t,i).map(e=>Ue(e.text)).filter(Boolean);if(!a.length||!s.length)return o;let c=a.map(e=>Ue(e.text)),l=(n+.5)/Math.max(1,r),u=Math.max(1,s.length-1),d=Math.min(a.length,s.length+2),f=null;for(let e=u;e<=d;e++)for(let t=0;t+e<=a.length;t++){let n=c.slice(t,t+e),r=s.reduce((e,t)=>e+Math.max(...n.map(e=>Ge(t,e))),0)/s.length,i=n.reduce((e,t)=>e+Math.max(...s.map(e=>Ge(e,t))),0)/n.length,o=r*.7+i*.3,u=(t+e/2)/a.length,d=Math.max(0,1-Math.abs(u-l)),p=o*.82+d*.18;(!f||p>f.score)&&(f={lexical:o,score:p,start:t,end:t+e})}return!f||f.lexical<.34?o:{start:a[f.start].start,end:a[f.end-1].end}}function qe(e){let t=[],n=[],r=``,i=null,a=(e,i,a)=>{r+=e;for(let r=0;r<e.length;r++)t.push(i),n.push(a)};for(let{node:t,separator:n}of ce(e)){n&&r&&!i&&(i={node:t,offset:0});let e=t.data;for(let n=0;n<e.length;){let o=e.codePointAt(n),s=String.fromCodePoint(o),c=s.length;/\s/u.test(s)?r&&!i&&(i={node:t,offset:n}):(i&&=(a(` `,i,{node:i.node,offset:i.offset+1}),null),a(s,{node:t,offset:n},{node:t,offset:n+c})),n+=c}}return{text:r,starts:t,ends:n}}function Je(e,t){let{host:n,sourceText:r}=e,i=e.textIndex;if((!i||i.text!==a(r))&&(i=qe(n),e.textIndex=i,i.text!==a(r))||t.start<0||t.end>i.text.length)return null;let o=i.starts[t.start],s=i.ends[t.end-1];if(!o||!s)return null;let c=document.createRange();return c.setStart(o.node,o.offset),c.setEnd(s.node,s.offset),c}var Ye=class{entries=new WeakMap;entryByTranslationEl=new Map;translator=new u;overlay=null;overlayHost=null;overlayWords=new Map;hovered=null;hoveredText=``;highlightedHost=null;starBtn=null;starContext=null;onWordStar=null;alignmentTimer=0;active=!1;pointerFrame=0;pendingPointer=null;measuredTranslationEl=null;measuredTranslationTop=0;measuredTranslationStyle=null;activate(){this.active||(this.active=!0,document.addEventListener(`pointermove`,this.onPointerMove,!0),window.addEventListener(`scroll`,this.onViewportChange,!0),window.addEventListener(`resize`,this.onViewportChange))}deactivate(){this.active=!1,document.removeEventListener(`pointermove`,this.onPointerMove,!0),window.removeEventListener(`scroll`,this.onViewportChange,!0),window.removeEventListener(`resize`,this.onViewportChange),this.pointerFrame&&window.cancelAnimationFrame(this.pointerFrame),this.pointerFrame=0,this.pendingPointer=null,this.clearInteraction(),this.entries=new WeakMap,this.entryByTranslationEl.clear()}register(e,t,n,r,i,a){let o=He(n,i),s={host:e,sourceText:t,translation:n,sourceLanguage:r,targetLanguage:i,translationEl:a,segments:o,wordCount:o.filter(e=>e.wordIndex!==null).length,alignments:new Map,textIndex:null};this.entries.set(e,s),this.entryByTranslationEl.set(a,s)}unregister(e){let t=this.entries.get(e);t&&this.entryByTranslationEl.delete(t.translationEl),this.entries.delete(e),(this.overlayHost===e||this.highlightedHost===e)&&this.clearInteraction()}onViewportChange=()=>this.clearInteraction();onPointerMove=e=>{this.pendingPointer=e,!this.pointerFrame&&(this.pointerFrame=window.requestAnimationFrame(()=>{this.pointerFrame=0;let e=this.pendingPointer;this.pendingPointer=null,e&&this.active&&this.handlePointerMove(e)}))};handlePointerMove(e){let t=(e.target instanceof Element?e.target:null)?.closest(`[data-lens-page-inserted]`)??null,n=t?this.entryByTranslationEl.get(t):void 0;if(!t||!n||!n.host.isConnected||!t.isConnected){this.clearInteraction();return}let r=n.host,i=t.getBoundingClientRect().top;(t!==this.measuredTranslationEl||!this.measuredTranslationStyle||i!==this.measuredTranslationTop)&&(this.measuredTranslationEl=t,this.measuredTranslationStyle=window.getComputedStyle(t),this.measuredTranslationTop=i);let a=this.measuredTranslationTop,o=this.measuredTranslationStyle;if(!o||e.clientY<a){this.clearInteraction();return}this.ensureOverlay(n,a,o);let s=this.overlay?.getBoundingClientRect();if(!s||e.clientX<s.left||e.clientX>s.right||e.clientY<s.top||e.clientY>s.bottom){this.clearInteraction();return}let c=this.segmentAtPoint(e.clientX,e.clientY,n);if(c?.wordIndex===null||c===void 0){window.clearTimeout(this.alignmentTimer),this.clearHighlight(),this.hovered=null,this.hoveredText=``;return}if(this.hovered?.host===r&&this.hovered.wordIndex===c.wordIndex)return;this.hovered={host:r,wordIndex:c.wordIndex},this.hoveredText=c.text;let l=R(n.sourceText,``,c.wordIndex,n.wordCount,n.sourceLanguage);l&&this.highlight(n,l),window.clearTimeout(this.alignmentTimer);let u=n.alignments.get(c.wordIndex);if(u){this.applyAlignmentWhenCurrent(u,r,c.wordIndex,n);return}this.alignmentTimer=window.setTimeout(()=>{if(this.hovered?.host!==r||this.hovered.wordIndex!==c.wordIndex)return;let e=this.alignSegment(n,c);n.alignments.set(c.wordIndex,e),this.applyAlignmentWhenCurrent(e,r,c.wordIndex,n)},160)}applyAlignmentWhenCurrent(e,t,n,r){e.then(e=>{!e||!this.active||this.hovered?.host!==t||this.hovered.wordIndex!==n||this.highlight(r,e)})}reverseReady=new Map;reversePairReady(e,t){let n=`${e}\0${t}`,r=this.reverseReady.get(n);return r||(r=this.translator.availability(e,t).then(e=>e===`available`).catch(()=>!1),this.reverseReady.set(n,r)),r}alignSegment(e,t){let n=R(e.sourceText,``,t.wordIndex??0,e.wordCount,e.sourceLanguage);return this.translator.isSupported()?this.reversePairReady(e.targetLanguage,e.sourceLanguage).then(async r=>{if(!r)return n;let i=await this.translator.translate(t.text,e.targetLanguage,e.sourceLanguage);return R(e.sourceText,i??``,t.wordIndex??0,e.wordCount,e.sourceLanguage)}):Promise.resolve(n)}ensureOverlay(e,t,n){if(this.overlay||(this.overlay=document.createElement(`div`),this.overlay.id=Be,this.overlay.setAttribute(`data-lens-ignore`,``),document.documentElement.append(this.overlay)),this.overlayHost!==e.host){this.overlay.replaceChildren(),this.overlayWords.clear();for(let t of e.segments){if(t.wordIndex===null){this.overlay.append(document.createTextNode(t.text));continue}let e=document.createElement(`span`);e.textContent=t.text,this.overlayWords.set(t.wordIndex,e),this.overlay.append(e)}this.overlayHost=e.host}let r=e.translationEl.getBoundingClientRect(),i=r.left,a=Math.max(1,r.width),o=this.overlay.style;o.all=`initial`,o.position=`fixed`,o.zIndex=`2147483646`,o.pointerEvents=`none`,o.boxSizing=`border-box`,o.left=`${i}px`,o.top=`${t}px`,o.width=`${a}px`,o.margin=`0`,o.padding=n.padding,o.border=`0`,o.background=`transparent`,o.color=`transparent`,o.fontFamily=n.fontFamily,o.fontSize=n.fontSize,o.fontStyle=n.fontStyle,o.fontWeight=n.fontWeight,o.lineHeight=n.lineHeight,o.letterSpacing=n.letterSpacing,o.wordSpacing=n.wordSpacing,o.textAlign=n.textAlign,o.whiteSpace=n.whiteSpace,o.overflowWrap=n.overflowWrap,o.direction=n.direction}segmentAtPoint(e,t,n){for(let r of n.segments){if(r.wordIndex===null)continue;let n=this.overlayWords.get(r.wordIndex);if(n){for(let i of n.getClientRects())if(e>=i.left-1&&e<=i.right+1&&t>=i.top&&t<=i.bottom)return r}}}highlight(e,t){let n=Je(e,t);if(!n)return;this.clearHighlight();let r=globalThis.CSS?.highlights,i=globalThis.Highlight;r&&i?r.set(F,new i(n)):e.host.setAttribute(I,``),this.highlightedHost=e.host,this.showWordStar(e,t,n)}showWordStar(e,t,n){if(!this.onWordStar)return;let r=e.sourceText.slice(t.start,t.end).trim(),i=this.hoveredText.trim();if(!r||!i)return;this.starContext={source:r,translation:i,sourceLang:e.sourceLanguage,targetLang:e.targetLanguage},this.starBtn||(this.starBtn=document.createElement(`button`),this.starBtn.type=`button`,this.starBtn.id=`lens-translator-alignment-star`,this.starBtn.setAttribute(`data-lens-ignore`,``),this.starBtn.title=`收藏到生词本`,Object.assign(this.starBtn.style,{all:`initial`,position:`fixed`,zIndex:`2147483647`,padding:`2px 6px`,border:`1px solid rgb(15 23 42 / 18%)`,borderRadius:`6px`,background:`rgb(255 255 255 / 97%)`,boxShadow:`0 4px 12px rgb(15 23 42 / 18%)`,color:`#b45309`,font:`13px/1.2 system-ui, sans-serif`,cursor:`pointer`}),this.starBtn.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),this.starBtn&&this.starContext&&(this.onWordStar?.(this.starContext),this.starBtn.textContent=`★`)})),this.starBtn.textContent=`☆`,this.starBtn.isConnected||document.documentElement.append(this.starBtn);let a=n.getBoundingClientRect(),o=Math.min(Math.max(4,a.left),window.innerWidth-34),s=a.top>34?a.top-28:a.bottom+6;this.starBtn.style.left=`${o}px`,this.starBtn.style.top=`${Math.max(4,s)}px`}clearHighlight(){(globalThis.CSS?.highlights)?.delete(F),this.highlightedHost?.removeAttribute(I),this.highlightedHost=null}clearInteraction(){window.clearTimeout(this.alignmentTimer),this.clearHighlight(),this.hovered=null,this.hoveredText=``,this.starBtn?.remove(),this.starContext=null,this.measuredTranslationEl=null,this.measuredTranslationStyle=null,this.measuredTranslationTop=0,this.overlay?.remove(),this.overlay=null,this.overlayHost=null,this.overlayWords.clear()}},z=`data-lens-page-translated`,B=`lens-translator-page-style`,V=`lens-translator-page-status`,H=`data-lens-page-inserted`,U=`data-lens-page-control`,W=`data-lens-page-pending`,Xe=3,Ze=5e3,Qe=6,$e=8e3,et=600,tt=2,nt=2e3;function rt(e){let t=e.pageTranslationUseCustomColor?e.pageTranslationTextColor:`inherit`,n=e.pageTranslationUseBackground?e.pageTranslationBackgroundColor:`transparent`,r=e.pageTranslationUseBackground?`0.3em 0.5em`:`0`,i=e.pageTranslationUseBackground?`4px`:`0`,a=e.pageTranslationUseCustomColor||e.pageTranslationUseBackground?`1`:`0.78`,o=e.pageTranslationUseOriginalFontSize?`inherit`:`${e.pageTranslationFontSizePx}px`;return`
/* Every translation is a source-owned child. It never climbs into an ancestor
   layout, so component, table, list, and slot boundaries remain intact.
   "all: initial" cuts it off from hostile site wildcard styles. */
[${H}] {
  all: initial !important;
  display: block !important;
  min-width: 0 !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  margin: 0.24em 0 0.1em !important;
  padding: ${r} !important;
  border: 0 !important;
  border-radius: ${i} !important;
  background: ${n} !important;
  color: ${t} !important;
  font-family: ${{system:`inherit`,sans:`Inter, ui-sans-serif, system-ui, sans-serif`,serif:`Georgia, "Times New Roman", serif`,mono:`"SFMono-Regular", Consolas, "Liberation Mono", monospace`}[e.pageTranslationFontFamily]} !important;
  font-size: ${o} !important;
  font-style: ${e.pageTranslationItalic?`italic`:`inherit`} !important;
  font-weight: ${e.pageTranslationBold?`700`:`inherit`} !important;
  line-height: inherit !important;
  letter-spacing: 0 !important;
  overflow-wrap: anywhere !important;
  text-align: inherit !important;
  text-decoration: ${e.pageTranslationUnderline?`underline`:`none`} !important;
  text-transform: none !important;
  unicode-bidi: plaintext !important;
  white-space: pre-wrap !important;
  opacity: ${a} !important;
}

[${H}]:not([${U}]) {
  width: 100% !important;
  flex: 0 0 100% !important;
  grid-column: 1 / -1 !important;
}

[${H}][${U}] {
  display: inline !important;
  margin: 0 0 0 0.35em !important;
  vertical-align: baseline !important;
  white-space: nowrap !important;
}

[${H}][${W}] {
  cursor: progress !important;
  user-select: none !important;
  text-decoration: none !important;
}

[${H}][${W}]::before {
  content: '' !important;
  display: inline-block !important;
  width: min(45%, 18em) !important;
  height: 0.55em !important;
  margin-right: 0.65em !important;
  vertical-align: 0.08em !important;
  border-radius: 0.3em !important;
  background: currentColor !important;
  opacity: 0.18;
  animation: lens-page-pending 1.6s ease-in-out infinite !important;
}

[${H}][${W}][${U}] {
  display: inline-block !important;
  width: 1.8em !important;
}

[${H}][${W}][${U}]::before {
  width: 100% !important;
  margin-right: 0 !important;
}

@keyframes lens-page-pending {
  50% { opacity: 0.38; }
}

@media (prefers-reduced-motion: reduce) {
  [${H}][${W}]::before { animation: none !important; }
}


::highlight(${F}) {
  background: rgb(250 204 21 / 52%);
  color: inherit;
  text-decoration: underline;
  text-decoration-color: rgb(202 138 4 / 80%);
  text-decoration-thickness: 2px;
}

[${I}] {
  background-color: rgb(250 204 21 / 22%) !important;
}
${e.pageTranslationDisplayMode===`translation-only`?`
/* Hide original glyphs but keep every box's geometry — no holes, no collapse.
   The source-owned translation child is restored below. */
[${z}],
[${z}] * {
  visibility: hidden !important;
}
[${z}] :is(input, textarea, select, video, audio, canvas, iframe, img, svg) {
  visibility: visible !important;
}
[${H}] {
  visibility: visible !important;
}
`:``}${e.pageTranslationDisplayMode===`learning`?`
/* Learning mode: translations stay blurred until hovered — read the original
   first, peek only when stuck. */
[${H}]:not([${W}]) {
  filter: blur(5px) !important;
  opacity: 0.35 !important;
  transition: filter 0.15s ease, opacity 0.15s ease !important;
}
[${H}]:not([${W}]):hover {
  filter: none !important;
  opacity: 1 !important;
}
`:``}

#${V} {
  position: fixed !important;
  z-index: 2147483647 !important;
  top: 16px !important;
  right: 16px !important;
  max-width: min(360px, calc(100vw - 32px)) !important;
  padding: 9px 12px !important;
  border: 1px solid rgb(15 23 42 / 14%) !important;
  border-radius: 7px !important;
  background: rgb(255 255 255 / 96%) !important;
  box-shadow: 0 8px 24px rgb(15 23 42 / 16%) !important;
  color: #172033 !important;
  font: 500 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif !important;
  letter-spacing: 0 !important;
}

#${V}[data-error="true"] {
  border-color: rgb(185 28 28 / 24%) !important;
  color: #991b1b !important;
}

@media (prefers-color-scheme: dark) {
  #${V} {
    border-color: rgb(255 255 255 / 16%) !important;
    background: rgb(24 24 27 / 96%) !important;
    color: #f4f4f5 !important;
  }
  #${V}[data-error="true"] { color: #fca5a5 !important; }
}
`}function it(e){return!!(e&&typeof e==`object`&&`id`in e&&typeof e.id==`string`&&`translation`in e&&typeof e.translation==`string`)}function at(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-batch-result`||typeof e.ok!=`boolean`||`translations`in e&&e.translations!==void 0&&(!Array.isArray(e.translations)||!e.translations.every(it))?!1:e.ok?`translations`in e&&Array.isArray(e.translations):`error`in e&&typeof e.error==`string`}function ot(e){let t=[...e].sort((e,t)=>e.el===t.el?0:e.el.compareDocumentPosition(t.el)&4?-1:1),n=[],r=[];for(let e of t)x(e.el,0)?n.push(e):r.push(e);let i=[...n,...r],o=new Map;for(let e of i){let t=a(e.text),n=o.get(t);if(n){n.blocks.push(e);continue}o.set(t,{representative:{id:e.id,tag:e.tag,text:t},blocks:[e]})}return[...o.values()]}var st=new WeakMap;function ct(e){if(e.closest(`nav, aside, [role="navigation"], [role="complementary"]`))return null;let t=st.get(e);if(t!==void 0)return t;let n=e.parentElement,r=null;for(;n&&n!==document.body;){let e=window.getComputedStyle(n).overflowY;if((e===`auto`||e===`scroll`||e===`overlay`)&&n.clientHeight>0&&n.scrollHeight>=n.clientHeight*1.5){r=n;break}n=n.parentElement}return r&&st.set(e,r),r}var G=2.5,lt=new Set([`hidden`,`clip`]);function K(e){if(typeof e.getBoundingClientRect!=`function`)return null;try{return e.getBoundingClientRect()}catch{return null}}function q(e){if(typeof window>`u`||typeof window.getComputedStyle!=`function`)return null;try{return window.getComputedStyle(e)}catch{return null}}function ut(e,t,n){let r=K(t);if(!r)return`ok`;let i=q(t),a=i&&parseFloat(i.fontSize)||14,o=n?2:Math.min(t.textContent?.trim().length||G,G)*a;if(r.width+1<o||r.height<2)return`narrow`;if(n){let t=e.closest?.(`a, button, label, summary, [role="button"], [role="tab"], [role="link"], [role^="menuitem"], [role="option"], [role="switch"]`),n=t?K(t):null;if(n&&(r.left<n.left-1||r.right>n.right+1||r.top<n.top-1||r.bottom>n.bottom+1))return`clipped`}let s=K(e),c=q(e);if(s&&c&&c.display!==`inline`&&(r.right>s.right+1||r.left<s.left-1))return`clipped`;if(s&&c&&r.bottom>s.bottom+1){let e=c.height.endsWith(`px`)&&s.height<160,t=(c.display.includes(`flex`)||c.display.includes(`grid`))&&s.height<100;if(e||t)return`clipped`}return dt(t,r)}function dt(e,t){let n=e.parentElement,r=0;for(;n&&r++<14;){let e=q(n);if(!e)break;if(lt.has(e.overflowX)||lt.has(e.overflowY)){let e=K(n);if(e&&e.width>0&&e.height>0&&(t.bottom>e.bottom+1||t.top<e.top-1||t.right>e.right+1||t.left<e.left-1))return`clipped`}n=n.parentElement}return`ok`}function ft(e){let t=K(e);if(!t)return!1;let n=e,r=0;for(;n.parentElement&&r++<12;){let e=n.parentElement;if(e===document.body)break;let r=K(e);if(!r)break;if(t.bottom<=r.bottom+1){n=e;continue}let i=e.nextElementSibling;for(;i&&i.hasAttribute?.(`data-lens-ignore`);)i=i.nextElementSibling;if(i){let e=K(i);if(e&&e.height>0&&e.top<t.bottom-1&&e.bottom>t.top+1&&e.left<t.right&&e.right>t.left)return!0}n=e}return!1}var pt=class{browserTranslator;active=!1;generation=0;statusTimer=0;mutationTimer=0;initialRetryTimer=0;anchorFrame=0;pendingAnchor=null;activationDeadline=0;processingGeneration=0;rescanRequested=!1;observer=null;observedRoots=new WeakSet;currentSettings=null;dirtyRoots=new Set;translatedHosts=new Set;pendingHosts=new Set;sourceHosts=new Map;attemptedTextByHost=new WeakMap;sourceBlockByHost=new WeakMap;volatileHosts=new WeakSet;layoutFrame=0;layoutSkippedHosts=new Set;shadowStyles=new Map;hostChurn=new WeakMap;translationCache=new Map;retryAttempts=0;processedCount=0;translatedCount=0;totalCount=0;forceRefresh=!1;alignment=new Ye;insertedNodeByHost=new Map;hostByInsertedNode=new Map;segmentWrappers=new Set;constructor(e){this.browserTranslator=e}isActive(){return this.active}setWordStarHandler(e){this.alignment.onWordStar=e}async toggle(e,t){if(this.active){this.deactivate();return}await this.activate(e,t)}deactivate(){let e=this.captureScrollAnchors();this.active=!1,this.generation++,this.observer?.disconnect(),this.observer=null,window.removeEventListener(`resize`,this.onLayoutChange),window.cancelAnimationFrame(this.layoutFrame),this.layoutFrame=0,this.layoutSkippedHosts.clear(),this.alignment.deactivate(),this.observedRoots=new WeakSet,this.lastStatusText=``,this.progressTick=0,window.clearTimeout(this.statusTimer),window.clearTimeout(this.mutationTimer),this.mutationTimer=0,window.clearTimeout(this.initialRetryTimer),this.anchorFrame&&(window.cancelAnimationFrame(this.anchorFrame),this.anchorFrame=0,this.pendingAnchor=null);for(let e of this.translatedHosts)e.removeAttribute(z);for(let e of this.pendingHosts)e.removeAttribute(W);this.pendingHosts.clear();for(let e of this.insertedNodeByHost.values())e.remove();this.insertedNodeByHost.clear(),this.hostByInsertedNode.clear();for(let[e,t]of this.sourceHosts)t===null?e.removeAttribute(m):e.setAttribute(m,t);this.translatedHosts.clear(),this.sourceHosts.clear();for(let e of this.segmentWrappers)e.isConnected&&e.replaceWith(...e.childNodes);this.segmentWrappers.clear(),this.attemptedTextByHost=new WeakMap,this.sourceBlockByHost=new WeakMap,this.volatileHosts=new WeakSet,this.hostChurn=new WeakMap,this.translationCache.clear(),this.retryAttempts=0,this.dirtyRoots.clear(),this.currentSettings=null,this.forceRefresh=!1,this.processingGeneration=0,this.rescanRequested=!1,document.getElementById(V)?.remove(),document.getElementById(B)?.remove();for(let e of this.shadowStyles.values())e.remove();this.shadowStyles.clear(),this.restoreScrollAnchors(e)}captureScrollAnchors(){let e=new Map;for(let t of this.insertedNodeByHost.keys()){if(!t.isConnected)continue;let n=this.scrollContainerOf(t),r=n??`window`,i=n?n.getBoundingClientRect().top:0,a=t.getBoundingClientRect().top-i;if(a<0)continue;let o=e.get(r);(!o||a<o.top)&&e.set(r,{el:t,top:a})}return e}restoreScrollAnchors(e){let t=[];for(let[n,r]of e){if(!r.el.isConnected)continue;let e=n===`window`?0:n.getBoundingClientRect().top,i=r.el.getBoundingClientRect().top-e-r.top;i&&t.push({key:n,delta:i})}for(let{key:e,delta:n}of t)e===`window`?window.scrollBy(0,n):e.scrollBy(0,n)}async refresh(e,t){this.deactivate(),await this.activate(e,t,{forceRefresh:!0})}restyle(e){this.active&&(this.scheduleScrollAnchorRestore(),this.currentSettings=e,this.ensureStyles(e),this.onLayoutChange())}async activate(e,t,n){window.clearTimeout(this.statusTimer),this.active=!0,this.forceRefresh=n?.forceRefresh===!0;let r=++this.generation;if(this.currentSettings=e,this.ensureStyles(e),e.pageTranslationEngine===`external`&&!t){this.failActivation(`整页翻译需要先配置外部 API`);return}if(e.pageTranslationEngine===`browser`){let t=await this.browserTranslator.availability(e.sourceLang,e.targetLang);if(t===`unsupported`){this.failActivation(`当前浏览器不支持 Chrome 内置翻译`);return}if(t===`unavailable`){this.failActivation(`Chrome 内置翻译不支持当前语言对`);return}}this.alignment.activate(),this.startObserving(),this.activationDeadline=Date.now()+$e,await this.scanAndTranslate(e,r,!0)}async scanAndTranslate(e,t,n=!1){if(this.isCurrent(t)){if(this.processingGeneration===t){this.rescanRequested=!0;return}if(this.processingGeneration===0){this.processingGeneration=t,window.clearTimeout(this.statusTimer);try{let r=n?[document]:[...this.dirtyRoots];this.dirtyRoots.clear(),this.observePageRoots(r),this.cleanupDisconnectedHosts(),n&&this.showStatus(`正在分析页面文本…`);let i=new Map;for(let t of r)if(!(t!==document&&t instanceof Node&&!t.isConnected))for(let n of ke(e.minTextLength,t))i.set(n.segmentNodes?.[0]??n.el,n);let a=ot([...i.values()].filter(t=>this.volatileHosts.has(t.el)||t.el.closest(`time`)||!c(t.text,k(t.el)?1:e.minTextLength)||o(t.text,e.targetLang)||this.translatedHosts.has(t.el)?!1:this.attemptedTextByHost.get(t.el)!==t.text));if(this.totalCount=a.reduce((e,t)=>e+t.blocks.length,0),this.processedCount=0,this.translatedCount=0,!a.length){n&&this.translatedHosts.size===0?Date.now()<this.activationDeadline?(this.showStatus(`正在等待页面内容加载…`),this.scheduleInitialRetry(t)):this.failActivation(`当前页面没有可翻译文本`):document.getElementById(V)?.remove();return}n||this.showStatus(`检测到新内容，正在翻译…`);for(let e of a)for(let t of e.blocks)this.attemptedTextByHost.set(t.el,t.text);this.updateProgress();let s=[];for(let t of a){let n=this.translationCache.get(t.representative.text);n?(this.renderGroup(t,n,e),this.processedCount+=t.blocks.length):s.push(t)}this.updateProgress();let l=null;if(s.length){this.scheduleScrollAnchorRestore();for(let e of s)this.showPendingGroup(e);try{e.pageTranslationEngine===`browser`?await this.translateWithBrowser(s,e,t):await this.translateWithExternal(s,e,t)}catch(e){l=e instanceof Error?e.message:String(e)}}if(!this.isCurrent(t))return;if(n&&this.translatedCount===0&&this.translatedHosts.size===0&&!this.rescanRequested){this.failActivation(l??`整页翻译失败，当前语言对可能不可用`);return}let u=a.filter(e=>!this.translationCache.has(e.representative.text)),d=!1;if(u.length===0)this.retryAttempts=0;else if(this.retryAttempts<tt){this.retryAttempts++;for(let e of u)for(let t of e.blocks)this.attemptedTextByHost.delete(t.el);this.dirtyRoots.add(document),this.scheduleScan(nt*this.retryAttempts),d=!0}let f=this.totalCount-this.translatedCount;d?(this.showStatus(`翻译完成：${this.translatedCount} 段，${f} 段失败，稍后自动重试…`),this.scheduleStatusRemoval(nt*this.retryAttempts+1500)):f>0?(this.showStatus(l?`整页翻译部分失败：${l}`:`翻译完成：${this.translatedCount} 段成功，${f} 段失败`,!0),this.scheduleStatusRemoval(5e3)):(this.showStatus(`翻译完成：${this.translatedCount} 段`),this.scheduleStatusRemoval())}catch(e){if(!this.isCurrent(t))return;let r=e instanceof Error?e.message:String(e);n&&this.translatedHosts.size===0?this.failActivation(r):(this.showStatus(`整页翻译部分失败：${r}`,!0),this.scheduleStatusRemoval(5e3))}finally{if(this.processingGeneration!==t)return;for(let e of this.pendingHosts)this.clearPendingHost(e);this.processingGeneration=0,this.rescanRequested&&this.isCurrent(t)&&(this.rescanRequested=!1,this.scheduleScan(0))}}}}async translateWithBrowser(e,t,n){let r=await this.browserTranslator.prepare(t.sourceLang,t.targetLang);if(this.isCurrent(n)){if(!r)throw Error(`Chrome 内置翻译不支持当前语言对`);for(let r of e){if(!this.isCurrent(n))return;this.setPendingStatus(r,`正在翻译…`);let e=await this.browserTranslator.translate(r.representative.text,t.sourceLang,t.targetLang);if(!this.isCurrent(n))return;e&&this.renderGroup(r,e,t);for(let e of r.blocks)this.clearPendingHost(e.el);this.processedCount+=r.blocks.length,this.updateProgress()}}}async translateWithExternal(e,t,n){let r=P(),i=null;if(this.scheduleScrollAnchorRestore(),await p(e,Qe,async e=>{if(this.isCurrent(n)){this.setPendingStatus(e,`正在翻译…`);try{let a=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:r,blocks:[e.representative],sourceLang:t.sourceLang,targetLang:t.targetLang,...this.forceRefresh?{forceRefresh:!0}:{}});if(!this.isCurrent(n))return;if(!at(a))throw Error(`翻译服务未返回有效结果`);let o=a.translations?.find(t=>t.id===e.representative.id);o&&this.renderGroup(e,o.translation,t),!a.ok&&i===null&&(i=a.error)}catch(e){i===null&&(i=e instanceof Error?e.message:String(e))}if(this.isCurrent(n)){for(let t of e.blocks)this.clearPendingHost(t.el);this.processedCount+=e.blocks.length,this.updateProgress()}}}),this.isCurrent(n)&&i!==null&&e.some(e=>!this.translationCache.has(e.representative.text)))throw Error(i)}rememberSource(e,t){this.sourceHosts.has(e)||(this.sourceHosts.set(e,e.getAttribute(m)),e.setAttribute(m,t))}showPendingGroup(e){for(let t of e.blocks){if(!t.el.isConnected||this.insertedNodeByHost.has(t.el)||!t.segmentNodes&&w(t.el)!==t.text)continue;let e=t.el,n=this.materializeSegmentHost(t);n&&(t.el=n,delete t.segmentNodes,this.attemptedTextByHost.set(n,t.text),this.insertTranslationIntoHost(n,``,!0)&&(this.rememberSource(n,t.text),this.sourceBlockByHost.set(n,e),n.setAttribute(W,``),this.pendingHosts.add(n)))}this.setPendingStatus(e,`等待翻译…`)}setPendingStatus(e,t){for(let n of e.blocks){let e=this.insertedNodeByHost.get(n.el);e?.hasAttribute(W)&&e.setAttribute(`aria-label`,t)}}clearPendingHost(e){if(!this.pendingHosts.has(e))return;let t=this.attemptedTextByHost.get(e);this.invalidateHost(e),t!==void 0&&this.attemptedTextByHost.set(e,t)}renderGroup(e,t,n){this.scheduleScrollAnchorRestore(),this.translationCache.set(e.representative.text,t);for(let r of e.blocks){if(!r.el.isConnected||this.translatedHosts.has(r.el))continue;if(!r.segmentNodes&&w(r.el)!==r.text){this.clearPendingHost(r.el),this.attemptedTextByHost.delete(r.el),this.dirtyRoots.add(r.el),this.rescanRequested=!0;continue}let e=this.materializeSegmentHost(r);if(!e||!e.isConnected||this.translatedHosts.has(e))continue;this.rememberSource(e,r.text),this.pendingHosts.delete(e),e.removeAttribute(W),e.setAttribute(z,``);let i=this.insertTranslationIntoHost(e,t);if(!i){e.removeAttribute(z);let t=this.sourceHosts.get(e);t===null?e.removeAttribute(m):t!==void 0&&e.setAttribute(m,t),this.sourceHosts.delete(e),this.attemptedTextByHost.set(e,r.text),this.layoutSkippedHosts.add(e),this.totalCount=Math.max(0,this.totalCount-1);continue}this.translatedHosts.add(e),this.layoutSkippedHosts.delete(e),this.sourceBlockByHost.has(e)||this.sourceBlockByHost.set(e,r.el),this.alignment.register(e,r.text,t,n.sourceLang,n.targetLang,i),this.translatedCount++}}materializeSegmentHost(e){let t=e.segmentNodes;if(!t?.length)return e.el;let n=t[0].parentNode;if(!n||t.some(e=>!e.isConnected||e.parentNode!==n)||t.some((e,n)=>n>0&&t[n-1].nextSibling!==e)||a(t.map(e=>e.textContent??``).join(``))!==e.text)return null;let r=document.createElement(`span`);r.setAttribute(ee,``),n.insertBefore(r,t[0]);for(let e of t)r.append(e);return this.segmentWrappers.add(r),r}insertTranslationIntoHost(e,t,n=!1){let r=this.insertedNodeByHost.get(e);r&&!r.isConnected&&(this.removeInsertedNodeForHost(e),r=void 0);let i=r,a=k(e);if(r??=document.createElement(`span`),r.setAttribute(H,``),r.setAttribute(`data-lens-ignore`,``),a&&r.setAttribute(U,``),n)r.setAttribute(W,``),r.setAttribute(`aria-busy`,`true`),r.setAttribute(`role`,`status`),r.setAttribute(`aria-live`,`off`);else if(i)for(let e of[W,`aria-busy`,`aria-label`,`aria-live`,`role`,`title`])r.removeAttribute(e);r.textContent=n?``:t;let o=e.getRootNode();if(o instanceof ShadowRoot&&!this.shadowStyles.has(o)&&this.currentSettings){let e=document.createElement(`style`);e.setAttribute(`data-lens-ignore`,``),e.textContent=rt(this.currentSettings),o.prepend(e),this.shadowStyles.set(o,e)}return i||this.placeTranslationNode(e,r),ut(e,r,a)!==`ok`||ft(r)?(r.remove(),this.insertedNodeByHost.delete(e),this.hostByInsertedNode.delete(r),null):(this.insertedNodeByHost.set(e,r),this.hostByInsertedNode.set(r,e),r)}placeTranslationNode(e,t){e.append(t)}removeInsertedNodeForHost(e){let t=this.insertedNodeByHost.get(e);t&&(this.insertedNodeByHost.delete(e),this.hostByInsertedNode.delete(t),t.remove())}recordTranslationRemoval(e){let t=Date.now(),n=this.hostChurn.get(e);return!n||t-n.since>Ze?(this.hostChurn.set(e,{count:1,since:t}),!1):(n.count++,n.count>=Xe)}startObserving(){this.observer?.disconnect(),this.observedRoots=new WeakSet,this.observer=new MutationObserver(e=>this.onMutations(e)),this.observePageRoots([document]),window.addEventListener(`resize`,this.onLayoutChange)}onLayoutChange=()=>{!this.active||this.layoutFrame||(this.layoutFrame=window.requestAnimationFrame(()=>{this.layoutFrame=0;let e=[...this.layoutSkippedHosts];for(let[e,t]of this.insertedNodeByHost){if(!e.isConnected||!t.isConnected||ut(e,t,k(e))===`ok`&&!ft(t))continue;let n=e.getAttribute(`data-lens-translator-source`)??``;this.invalidateHost(e),this.attemptedTextByHost.set(e,n),this.layoutSkippedHosts.add(e)}for(let t of e)this.layoutSkippedHosts.delete(t),t.isConnected&&(this.attemptedTextByHost.delete(t),this.dirtyRoots.add(t));e.length&&this.scheduleScan()}))};observePageRoots(e){if(this.observer)for(let t of e)for(let e of Ae(t)){let t=e===document?document.documentElement:e;this.observedRoots.has(t)||(this.observer.observe(t,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:[`hidden`,`aria-hidden`,`class`,`style`,`open`]}),this.observedRoots.add(t))}}onMutations(e){let t=!1;for(let n of e){let e=n.target.nodeType===1?n.target:n.target.parentElement;if(!e||e.closest(`[data-lens-ignore]`))continue;if(n.type===`attributes`){this.dirtyRoots.add(e),t=!0;continue}if(n.type===`characterData`&&e.closest(`[contenteditable]:not([contenteditable="false"]), textarea, input`))continue;if(n.type===`childList`){for(let e of n.removedNodes){if(e.nodeType!==1||!e.hasAttribute(H))continue;let n=this.hostByInsertedNode.get(e);if(!n)continue;let r=n.getAttribute(`data-lens-translator-source`)??``,i=this.recordTranslationRemoval(n);this.invalidateHost(n),i?this.attemptedTextByHost.set(n,r):(this.dirtyRoots.add(n.parentElement??n),t=!0)}let e=[...n.addedNodes,...n.removedNodes];if(e.length>0&&e.every(e=>this.isOwnNode(e)))continue;if(this.isVirtualScrollChildList(n)){let e=!1,r=this.currentSettings?.minTextLength??10;for(let t of n.addedNodes){if(t.nodeType!==1)continue;let n=t;this.isOwnNode(n)||a(C(n)).length<r||(this.dirtyRoots.add(n),e=!0)}e&&(t=!0);continue}}let r=e.closest(`[${z}], [${W}]`);if(r){let e=r.getAttribute(`data-lens-translator-source`)??``;if(w(r)===e)continue;if(this.markChurnAndMaybeVolatile(r)){this.invalidateHost(r);continue}this.invalidateHost(r),this.dirtyRoots.add(r.parentElement??r),t=!0;continue}this.dirtyRoots.add(e.parentElement??e),t=!0}t&&(this.onLayoutChange(),this.scheduleScan())}isVirtualScrollChildList(e){if(e.type!==`childList`)return!1;let t=e.target.nodeType===1?e.target:e.target.parentElement;return!t||t.closest(`[${z}], [${W}]`)?!1:ct(t)!==null}markChurnAndMaybeVolatile(e){let t=Date.now(),n=this.hostChurn.get(e);if(!n||t-n.since>Ze)return this.hostChurn.set(e,{count:1,since:t}),!1;if(n.count++,n.count<Xe)return!1;this.volatileHosts.add(e);let r=this.sourceBlockByHost.get(e);return r&&this.volatileHosts.add(r),!0}isOwnNode(e){return e.nodeType===1&&(e.hasAttribute(`data-lens-ignore`)||e.id===B||e.id===V)}invalidateHost(e){this.alignment.unregister(e),this.removeInsertedNodeForHost(e),e.removeAttribute(z),e.removeAttribute(W),this.translatedHosts.delete(e),this.pendingHosts.delete(e);let t=this.sourceHosts.get(e);t===null?e.removeAttribute(m):t!==void 0&&e.setAttribute(m,t),this.sourceHosts.delete(e),this.attemptedTextByHost.delete(this.sourceBlockByHost.get(e)??e),this.attemptedTextByHost.delete(e),this.sourceBlockByHost.delete(e)}cleanupDisconnectedHosts(){for(let e of this.insertedNodeByHost.keys())e.isConnected||this.invalidateHost(e);for(let[e,t]of[...this.insertedNodeByHost])t.isConnected||!e.isConnected||(this.invalidateHost(e),this.dirtyRoots.add(e.parentElement??e))}scheduleScan(e=250){this.mutationTimer||=window.setTimeout(()=>{this.mutationTimer=0,!(!this.active||!this.currentSettings)&&this.scanAndTranslate(this.currentSettings,this.generation)},e)}scheduleInitialRetry(e){window.clearTimeout(this.initialRetryTimer),this.initialRetryTimer=window.setTimeout(()=>{!this.isCurrent(e)||!this.currentSettings||this.scanAndTranslate(this.currentSettings,e,!0)},et)}isCurrent(e){return this.active&&e===this.generation}scheduleScrollAnchorRestore(){(!this.pendingAnchor||Date.now()-this.pendingAnchor.at>1e3)&&(this.pendingAnchor=this.captureScrollAnchor()),!(!this.pendingAnchor||this.anchorFrame)&&(this.anchorFrame=window.requestAnimationFrame(()=>{this.anchorFrame=0;let e=this.pendingAnchor;if(this.pendingAnchor=null,!e||!e.el.isConnected||Date.now()-e.at>1e3)return;let t=e.el.getBoundingClientRect().top-e.top;if(Math.abs(t)<=1)return;let n=this.scrollContainerOf(e.el);n?n.scrollBy({top:t,left:0,behavior:`instant`}):window.scrollBy({top:t,left:0,behavior:`instant`})}))}captureScrollAnchor(){if(typeof document.elementsFromPoint!=`function`)return null;let e=Math.round(window.innerWidth/2),t=Math.min(window.innerHeight,480);for(let n=1;n<=t;n+=24)for(let t of document.elementsFromPoint(e,n)){if(t===document.body||t===document.documentElement||t.closest(`[data-lens-ignore]`))continue;let e=window.getComputedStyle(t).position;if(!(e===`fixed`||e===`sticky`)&&!ct(t))return{el:t,top:t.getBoundingClientRect().top,at:Date.now()}}return null}scrollContainerOf(e){let t=e.parentElement;for(;t&&t!==document.body;){let e=window.getComputedStyle(t);if(/(auto|scroll|overlay)/.test(e.overflowY)&&t.scrollHeight>t.clientHeight)return t;t=t.parentElement}return null}ensureStyles(e){let t=document.getElementById(B);t||(t=document.createElement(`style`),t.id=B,t.setAttribute(`data-lens-ignore`,``),(document.head??document.documentElement).append(t)),t.textContent=rt(e);for(let e of this.shadowStyles.values())e.textContent=t.textContent}lastStatusText=``;showStatus(e,t=!1){if(e===this.lastStatusText&&document.getElementById(V)?.dataset.error===(t?`true`:`false`))return;this.lastStatusText=e;let n=document.getElementById(V);n||(n=document.createElement(`div`),n.id=V,n.setAttribute(`data-lens-ignore`,``),n.setAttribute(`role`,`status`),n.setAttribute(`aria-live`,`polite`),document.documentElement.append(n)),n.dataset.error=t?`true`:`false`,n.textContent=e}progressTick=0;updateProgress(){let e=Date.now();e-this.progressTick<400&&this.processedCount<this.totalCount||(this.progressTick=e,this.showStatus(`整页翻译 ${Math.min(this.processedCount,this.totalCount)}/${this.totalCount}`))}failActivation(e){this.active=!1,window.clearTimeout(this.initialRetryTimer),this.observer?.disconnect(),this.observer=null,this.alignment.deactivate(),this.showStatus(e,!0),this.scheduleStatusRemoval(5e3)}scheduleStatusRemoval(e=3e3){window.clearTimeout(this.statusTimer),this.statusTimer=window.setTimeout(()=>{document.getElementById(V)?.remove()},e)}},mt=new Set(`a.an.and.are.as.at.be.by.for.from.has.have.in.is.it.not.of.on.or.that.the.this.to.was.we.will.with.you`.split(`.`));function J(e){return e.trim().toLocaleLowerCase().split(/[-_]/u)[0]}function ht(e){let t=e.match(/\p{L}/gu)??[];if(t.length<40||(e.match(/[a-z]/giu)?.length??0)/t.length<.78)return!1;let n=e.toLocaleLowerCase().match(/[a-z]+(?:'[a-z]+)?/gu)??[];return n.length<12?!1:n.reduce((e,t)=>e+ +!!mt.has(t),0)>=Math.max(2,Math.ceil(n.length*.035))}function gt(e){return(e.match(/\p{L}/gu)??[]).length<40}function _t(e,t=document){let n=t.documentElement.lang||t.querySelector(`meta[http-equiv="content-language" i]`)?.content||``,r=(t.body?.innerText||t.body?.textContent||``).slice(0,12e3),i=J(e),a=J(n),o=gt(r);return i===`en`&&ht(r)?{matches:!0,shouldRetry:!1,reason:`english-text`}:a?a===i?i===`en`?o?{matches:!0,shouldRetry:!0,reason:`declared-en-waiting-body`}:{matches:!1,shouldRetry:!1,reason:`declared-en-body-not-english`}:{matches:!0,shouldRetry:!1,reason:`declared:${a}`}:{matches:!1,shouldRetry:o&&i===`en`,reason:`declared-mismatch:${a}`}:o?{matches:!1,shouldRetry:i===`en`,reason:`insufficient-sample`}:{matches:!1,shouldRetry:!1,reason:`text-not-source`}}var vt=[{lang:`ja`,re:/[\p{Script=Hiragana}\p{Script=Katakana}]/u},{lang:`ko`,re:/\p{Script=Hangul}/u},{lang:`zh`,re:/\p{Script=Han}/u},{lang:`ru`,re:/\p{Script=Cyrillic}/u},{lang:`ar`,re:/\p{Script=Arabic}/u},{lang:`hi`,re:/\p{Script=Devanagari}/u},{lang:`th`,re:/\p{Script=Thai}/u},{lang:`he`,re:/\p{Script=Hebrew}/u},{lang:`el`,re:/\p{Script=Greek}/u},{lang:`bn`,re:/\p{Script=Bengali}/u},{lang:`ta`,re:/\p{Script=Tamil}/u},{lang:`te`,re:/\p{Script=Telugu}/u},{lang:`kn`,re:/\p{Script=Kannada}/u}],yt=.45;function bt(e){let t=e.match(/\p{L}/gu)??[];if(t.length<8)return null;for(let{lang:e,re:n}of vt)if(t.filter(e=>n.test(e)).length/t.length>=yt)return e;return null}var Y=null;function xt(){return Y||(Y=(async()=>{let e=globalThis.LanguageDetector;if(!e)return null;try{return await e.availability()===`available`?await e.create():null}catch{return null}})(),Y)}async function St(e){let t=await xt();if(!t)return null;try{let n=(await t.detect(e.slice(0,4e3)))[0];if(!n||n.confidence<.5)return null;let r=n.detectedLanguage?.trim();return r?r.toLowerCase():null}catch{return null}}async function Ct(e,t){return await St(e)||(bt(e)??t)}var wt=300,Tt=class{host;root;panel;sourceLabel;sourceBody;targetLabel;targetBody;bound=!1;enabled=!1;paused=!1;sourceLang=`en`;targetLang=`zh`;requestId=0;lastText=``;lastTranslation=``;refreshTimer=0;actionRow;starBtn;speakBtn;translate;actions;constructor(e,t={}){this.translate=e,this.actions=t,this.host=document.createElement(`div`),this.host.id=`lens-translator-selection-root`,this.host.setAttribute(`data-lens-ignore`,``),Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,pointerEvents:`none`,zIndex:`2147483645`}),this.root=this.host.attachShadow({mode:`closed`});let n=document.createElement(`style`);n.textContent=Ot,this.panel=document.createElement(`div`),this.panel.className=`panel`,this.panel.style.display=`none`,this.panel.addEventListener(`mousedown`,e=>e.stopPropagation()),this.sourceLabel=document.createElement(`div`),this.sourceLabel.className=`label`,this.sourceBody=document.createElement(`div`),this.sourceBody.className=`source`,this.targetLabel=document.createElement(`div`),this.targetLabel.className=`label target-label`,this.targetBody=document.createElement(`div`),this.targetBody.className=`target`,this.actionRow=document.createElement(`div`),this.actionRow.className=`actions`,this.actionRow.hidden=!0,this.starBtn=document.createElement(`button`),this.starBtn.type=`button`,this.starBtn.className=`icon-btn`,this.starBtn.title=`收藏到生词本`,this.starBtn.textContent=`☆`,this.starBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.lastText&&this.lastTranslation&&(this.actions.onStar?.(this.lastText,this.lastTranslation),this.starBtn.textContent=`★`)}),this.speakBtn=document.createElement(`button`),this.speakBtn.type=`button`,this.speakBtn.className=`icon-btn`,this.speakBtn.title=`朗读译文`,this.speakBtn.textContent=`🔊`,this.speakBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.lastTranslation&&this.actions.onSpeak?.(this.lastTranslation)}),this.actionRow.append(this.starBtn,this.speakBtn),this.panel.append(this.sourceLabel,this.sourceBody,this.targetLabel,this.targetBody,this.actionRow),this.root.append(n,this.panel)}bind(){this.bound||(this.bound=!0,document.addEventListener(`selectionchange`,this.onSelectionChange),document.addEventListener(`mousedown`,this.onMouseDown,!0),window.addEventListener(`scroll`,this.hide,!0),window.addEventListener(`resize`,this.hide))}setEnabled(e){this.enabled=e,e||this.hide()}setPaused(e){this.paused=e,e&&this.hide()}setLanguages(e,t){this.sourceLang=e,this.targetLang=t,this.sourceLabel.textContent=i(e),this.targetLabel.textContent=i(t)}onMouseDown=e=>{let t=e.composedPath();t.includes(this.host)||t.includes(this.panel)||this.panel.style.display!==`none`&&!this.getSelectedText()&&this.hide()};onSelectionChange=()=>{if(!this.enabled||this.paused){this.hide();return}window.clearTimeout(this.refreshTimer),this.refreshTimer=window.setTimeout(()=>void this.refreshFromSelection(),wt)};getSelectedText(){let e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return``;let t=a(e.toString());if(t.length<1||t.length>2e3)return``;let n=e.anchorNode;if(n&&Dt(n instanceof Element?n:n.parentElement))return``;let r=e.focusNode;return r&&Dt(r instanceof Element?r:r.parentElement)||Et(document.activeElement)?``:t}async refreshFromSelection(){let e=this.getSelectedText();if(!e){this.hide();return}if(e===this.lastText&&this.panel.style.display!==`none`)return;this.lastText=e;let t=window.getSelection();if(!t||t.rangeCount===0){this.hide();return}let n=t.getRangeAt(0).getBoundingClientRect();if(n.width<1&&n.height<1){this.hide();return}if(this.mount(),this.sourceLabel.textContent=i(this.sourceLang),this.targetLabel.textContent=i(this.targetLang),this.sourceBody.textContent=e,this.panel.style.display=`block`,o(e,this.targetLang)){this.targetBody.classList.add(`muted`),this.targetBody.textContent=`已是目标语言`,this.place(n);return}this.targetBody.classList.add(`muted`,`pending`),this.targetBody.textContent=`翻译中…`,this.place(n);let r=++this.requestId;try{let t=await this.translate(e);if(r!==this.requestId||this.getSelectedText()!==e)return;if(!t){this.targetBody.classList.add(`muted`),this.targetBody.classList.remove(`pending`),this.targetBody.textContent=`暂无法翻译`;return}this.targetBody.classList.remove(`muted`,`pending`),this.targetBody.textContent=t,this.lastTranslation=t,this.starBtn.textContent=`☆`,this.actionRow.hidden=!this.actions.onSpeak&&!this.actions.onStar,this.place(n)}catch{if(r!==this.requestId)return;this.targetBody.classList.add(`muted`),this.targetBody.classList.remove(`pending`),this.targetBody.textContent=`暂无法翻译`}}place(e){let t=window.innerWidth,n=window.innerHeight,r=this.panel.getBoundingClientRect(),i=Math.max(r.width,220),a=Math.max(r.height,72),o=Math.min(Math.max(8,e.left),t-i-8),s=e.bottom+10;s+a>n-8&&(s=Math.max(8,e.top-a-10)),this.panel.style.left=`${o}px`,this.panel.style.top=`${s}px`}mount(){this.host.isConnected||document.documentElement.append(this.host)}hide=()=>{this.requestId++,this.lastText=``,this.lastTranslation=``,window.clearTimeout(this.refreshTimer),this.panel.style.display=`none`,this.actionRow.hidden=!0,this.targetBody.classList.remove(`muted`,`pending`)}};function Et(e){if(!e||!(e instanceof HTMLElement))return!1;if(e.isContentEditable)return!0;let t=e.tagName;return t===`INPUT`||t===`TEXTAREA`||t===`SELECT`||!!e.closest(`input, textarea, select, [contenteditable=""], [contenteditable="true"]`)}function Dt(e){return e?Et(e)?!0:!!e.closest(`#lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt, [data-lens-ignore]`):!1}var Ot=`
  :host, * { box-sizing: border-box; }
  .panel {
    position: fixed;
    min-width: 180px;
    max-width: min(360px, calc(100vw - 16px));
    max-height: min(280px, 42vh);
    overflow: auto;
    padding: 10px 12px;
    border-radius: 12px;
    background: rgb(255 255 255 / 96%);
    box-shadow:
      0 12px 32px rgb(15 23 42 / 18%),
      0 0 0 1px rgb(15 23 42 / 8%);
    color: #0f172a;
    font: 13px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif;
    pointer-events: auto;
    user-select: text;
  }
  .label {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.05em;
    color: #94a3b8;
    margin-bottom: 2px;
  }
  .target-label { margin-top: 8px; }
  .source {
    color: #64748b;
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 12.5px;
  }
  .target {
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 14px;
    font-weight: 520;
    color: #0f172a;
  }
  .target.muted { color: #64748b; font-weight: 400; }
  .target.pending { animation: pulse 1.1s ease-in-out infinite; }
  .actions {
    margin-top: 6px;
    display: flex;
    gap: 2px;
    justify-content: flex-end;
  }
  .icon-btn {
    appearance: none;
    border: 0;
    border-radius: 6px;
    background: transparent;
    padding: 3px 5px;
    font-size: 13px;
    line-height: 1;
    color: #64748b;
    cursor: pointer;
  }
  .icon-btn:hover { background: rgb(15 23 42 / 8%); }
  @keyframes pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
  }
  @media (prefers-color-scheme: dark) {
    .panel {
      background: rgb(24 24 27 / 96%);
      color: #f4f4f5;
      box-shadow: 0 12px 32px rgb(0 0 0 / 45%), 0 0 0 1px rgb(255 255 255 / 8%);
    }
    .source { color: #a1a1aa; }
    .target { color: #fafafa; }
    .target.muted { color: #a1a1aa; }
  }
  @media (prefers-reduced-motion: reduce) {
    .target.pending { animation: none; }
  }
`,X=`lens-shot-overlay`,Z=`lens-shot-card`,kt=`lens-shot-style`,At=8,jt=`
#${X} {
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  cursor: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'><circle cx='16' cy='16' r='8.5' fill='none' stroke='%232563eb' stroke-width='2'/><path d='M16 1v9M16 22v9M1 16h9M22 16h9' stroke='%232563eb' stroke-width='2'/><circle cx='16' cy='16' r='2' fill='%232563eb'/></svg>") 16 16, crosshair !important;
  background: rgb(15 23 42 / 18%) !important;
  user-select: none !important;
  outline: none !important;
}
#${X} .lens-shot-guide-h,
#${X} .lens-shot-guide-v {
  position: fixed !important;
  background: rgb(37 99 235 / 55%) !important;
  pointer-events: none !important;
}
#${X} .lens-shot-guide-h {
  left: 0 !important;
  right: 0 !important;
  height: 1px !important;
}
#${X} .lens-shot-guide-v {
  top: 0 !important;
  bottom: 0 !important;
  width: 1px !important;
}
#${X} .lens-shot-size {
  position: fixed !important;
  padding: 3px 8px !important;
  border-radius: 5px !important;
  background: rgb(15 23 42 / 85%) !important;
  color: #f8fafc !important;
  font: 500 12px/1.3 system-ui, sans-serif !important;
  pointer-events: none !important;
  white-space: nowrap !important;
}
#${X} .lens-shot-band {
  position: fixed !important;
  border: 1.5px solid #2563eb !important;
  background: rgb(37 99 235 / 12%) !important;
  box-shadow: 0 0 0 1px rgb(255 255 255 / 45%) !important;
  pointer-events: none !important;
}
#${X} .lens-shot-hint {
  position: fixed !important;
  top: 14px !important;
  left: 50% !important;
  transform: translateX(-50%) !important;
  padding: 7px 14px !important;
  border-radius: 7px !important;
  background: rgb(15 23 42 / 85%) !important;
  color: #f8fafc !important;
  font: 500 13px/1.4 system-ui, sans-serif !important;
  pointer-events: none !important;
}
#${Z} {
  position: fixed !important;
  z-index: 2147483647 !important;
  max-width: 380px !important;
  min-width: 260px !important;
  max-height: calc(100vh - 16px) !important;
  overflow-y: auto !important;
  border: 1px solid rgb(15 23 42 / 14%) !important;
  border-radius: 8px !important;
  background: #ffffff !important;
  box-shadow: 0 12px 32px rgb(15 23 42 / 22%) !important;
  color: #172033 !important;
  font: 400 13px/1.55 system-ui, sans-serif !important;
  overflow-x: hidden !important;
}
#${Z} .lens-shot-grip {
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
  padding: 7px 12px !important;
  background: rgb(15 23 42 / 5%) !important;
  border-bottom: 1px solid rgb(15 23 42 / 10%) !important;
  cursor: move !important;
  user-select: none !important;
  font: 600 11.5px/1 system-ui, sans-serif !important;
  color: #64748b !important;
  letter-spacing: 0.02em !important;
}
#${Z} .lens-shot-grip::before {
  content: '⠿' !important;
  font-size: 13px !important;
  color: #94a3b8 !important;
}
#${Z} .lens-shot-image {
  display: block !important;
  max-width: 100% !important;
  max-height: 180px !important;
  object-fit: contain !important;
  background: #f1f5f9 !important;
  border-bottom: 1px solid rgb(15 23 42 / 10%) !important;
}
#${Z} .lens-shot-text {
  padding: 10px 12px !important;
  white-space: pre-wrap !important;
  overflow-wrap: anywhere !important;
  max-height: 240px !important;
  overflow-y: auto !important;
}
#${Z} .lens-shot-text[data-state='pending'] {
  color: #64748b !important;
}
#${Z} .lens-shot-text[data-state='error'] {
  color: #b91c1c !important;
}
#${Z} .lens-shot-actions {
  display: flex !important;
  gap: 8px !important;
  padding: 0 12px 10px !important;
}
#${Z} button {
  font: 500 12px/1 system-ui, sans-serif !important;
  padding: 6px 10px !important;
  border: 1px solid rgb(15 23 42 / 16%) !important;
  border-radius: 6px !important;
  background: #ffffff !important;
  color: #172033 !important;
  cursor: pointer !important;
}
#${Z} button:hover {
  border-color: #2563eb !important;
}
@media (prefers-color-scheme: dark) {
  #${Z} {
    background: #1e293b !important;
    color: #f1f5f9 !important;
    border-color: rgb(255 255 255 / 16%) !important;
  }
  #${Z} button {
    background: #1e293b !important;
    color: #f1f5f9 !important;
    border-color: rgb(255 255 255 / 22%) !important;
  }
  #${Z} .lens-shot-image { background: #0f172a !important; }
  #${Z} .lens-shot-grip {
    background: rgb(255 255 255 / 7%) !important;
    color: #94a3b8 !important;
  }
}
`,Mt=class{translate;onSessionChange;overlay=null;card=null;keyHandler=null;moveHandler=null;upHandler=null;sessionActive=!1;generation=0;constructor(e,t){this.translate=e,this.onSessionChange=t}isSelecting(){return this.overlay!==null}start(){if(this.overlay)return;this.closeCard(),this.ensureStyles();let e=document.createElement(`div`);e.id=X,e.setAttribute(`data-lens-ignore`,``);let t=document.createElement(`div`);t.className=`lens-shot-hint`,t.textContent=`拖动框选要翻译的区域 · Esc 取消`,e.append(t);let n=document.createElement(`div`);n.className=`lens-shot-band`,n.hidden=!0,e.append(n);let r=document.createElement(`div`);r.className=`lens-shot-guide-h`;let i=document.createElement(`div`);i.className=`lens-shot-guide-v`;let a=document.createElement(`div`);a.className=`lens-shot-size`,a.hidden=!0,e.append(r,i,a);let o=null;e.addEventListener(`mousedown`,e=>{e.button===0&&(e.preventDefault(),o={x:e.clientX,y:e.clientY},n.hidden=!1,t.hidden=!0,a.hidden=!1)});let s=e=>{if(r.style.top=`${e.clientY}px`,i.style.left=`${e.clientX}px`,!o)return;let t=Nt(o,e);Object.assign(n.style,{left:`${t.x}px`,top:`${t.y}px`,width:`${t.width}px`,height:`${t.height}px`}),a.textContent=`${Math.round(t.width)} × ${Math.round(t.height)}`,a.style.left=`${Math.min(e.clientX+14,window.innerWidth-90)}px`,a.style.top=`${Math.min(e.clientY+14,window.innerHeight-30)}px`},c=e=>{if(e.button!==0||!o)return;let t=Nt(o,e);o=null,this.teardownOverlay(),t.width>=At&&t.height>=At?this.runTranslation(t):this.endSession()};document.addEventListener(`mousemove`,s,!0),document.addEventListener(`mouseup`,c,!0),this.moveHandler=s,this.upHandler=c;let l=e=>{e.key===`Escape`&&(e.stopPropagation(),this.teardownOverlay(),this.endSession())};document.addEventListener(`keydown`,l,!0),this.keyHandler=l,e.tabIndex=-1,this.overlay=e,document.documentElement.append(e),e.focus(),this.sessionActive=!0,this.onSessionChange?.(!0)}cancel(){this.teardownOverlay(),this.endSession()}endSession(){this.sessionActive&&(this.sessionActive=!1,this.onSessionChange?.(!1))}teardownOverlay(){this.overlay&&=(this.keyHandler&&=(document.removeEventListener(`keydown`,this.keyHandler,!0),null),this.moveHandler&&=(document.removeEventListener(`mousemove`,this.moveHandler,!0),null),this.upHandler&&=(document.removeEventListener(`mouseup`,this.upHandler,!0),null),this.overlay.remove(),null)}async runTranslation(e){let t=this.showCard(e),n=++this.generation,r=t.querySelector(`.lens-shot-text`);r.dataset.state=`pending`,r.textContent=`正在识别并翻译…`;let i;try{i=await this.translate(e,window.devicePixelRatio||1)}catch(e){i={ok:!1,error:e instanceof Error?e.message:String(e)}}finally{this.endSession()}if(!(n!==this.generation||!t.isConnected))if(i.ok){let e=document.createElement(`img`);e.className=`lens-shot-image`,e.alt=`选区截图`,e.addEventListener(`load`,()=>this.clampCard(t),{once:!0}),e.src=i.image,t.insertBefore(e,r),r.dataset.state=`done`,r.textContent=i.translation}else r.dataset.state=`error`,r.textContent=i.error}showCard(e){this.closeCard();let t=document.createElement(`div`);t.id=Z,t.setAttribute(`data-lens-ignore`,``);let n=document.createElement(`div`);n.className=`lens-shot-grip`,n.textContent=`翻译结果 · 可拖动`,this.makeDraggable(t,n);let r=document.createElement(`div`);r.className=`lens-shot-text`;let i=document.createElement(`div`);i.className=`lens-shot-actions`;let a=document.createElement(`button`);a.textContent=`复制译文`;let o=e=>{let n=document.createElement(`textarea`);n.value=e,n.style.cssText=`position:fixed;opacity:0;pointer-events:none`,t.append(n),n.select(),document.execCommand(`copy`),n.remove()};a.addEventListener(`click`,()=>{let e=r.textContent??``,t=()=>{a.textContent=`已复制`,setTimeout(()=>a.textContent=`复制译文`,1200)};if(navigator.clipboard?.writeText){navigator.clipboard.writeText(e).then(t,()=>{o(e),t()});return}o(e),t()});let s=document.createElement(`button`);s.textContent=`关闭`,s.addEventListener(`click`,()=>this.closeCard()),i.append(a,s),t.append(n,r,i),document.documentElement.append(t);let c=e.y+e.height+8,l=c+t.getBoundingClientRect().height<=window.innerHeight-8?c:e.y-t.getBoundingClientRect().height-8;return this.positionCard(t,e.x,l),this.card=t,t}positionCard(e,t,n){let r=Math.max(8,window.innerWidth-e.offsetWidth-8),i=Math.max(8,window.innerHeight-e.offsetHeight-8);e.style.left=`${Math.min(Math.max(8,t),r)}px`,e.style.top=`${Math.min(Math.max(8,n),i)}px`}clampCard(e){e.isConnected&&this.positionCard(e,e.offsetLeft,e.offsetTop)}makeDraggable(e,t){t.addEventListener(`pointerdown`,n=>{if(n.button!==0)return;n.preventDefault();let r=n.clientX-e.offsetLeft,i=n.clientY-e.offsetTop,a=t=>{this.positionCard(e,t.clientX-r,t.clientY-i)},o=()=>{t.removeEventListener(`pointermove`,a),t.removeEventListener(`pointerup`,o),t.removeEventListener(`pointercancel`,o)};t.addEventListener(`pointermove`,a),t.addEventListener(`pointerup`,o),t.addEventListener(`pointercancel`,o),t.setPointerCapture(n.pointerId)})}closeCard(){this.generation++,this.card?.remove(),this.card=null}ensureStyles(){if(document.getElementById(kt))return;let e=document.createElement(`style`);e.id=kt,e.setAttribute(`data-lens-ignore`,``),e.textContent=jt,(document.head??document.documentElement).append(e)}};function Nt(e,t){return{x:Math.min(e.x,t.clientX),y:Math.min(e.y,t.clientY),width:Math.abs(t.clientX-e.x),height:Math.abs(t.clientY-e.y)}}var Pt=class{host=null;root=null;show(e,t,n){this.dismiss(),this.host=document.createElement(`div`),this.host.id=`lens-translator-setup-prompt`,this.host.setAttribute(`data-lens-ignore`,``),Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,zIndex:`2147483647`,pointerEvents:`auto`}),this.root=this.host.attachShadow({mode:`closed`});let i=r(t.sourceLang,t.targetLang),a=Ft(e,i),o=document.createElement(`style`);o.textContent=It;let s=document.createElement(`div`);s.className=`backdrop`,s.addEventListener(`click`,e=>{e.target===s&&(n.onDismiss?.(),this.dismiss())});let c=document.createElement(`div`);c.className=`card`,c.setAttribute(`role`,`dialog`),c.setAttribute(`aria-modal`,`true`),c.setAttribute(`aria-labelledby`,`lens-setup-title`);let l=document.createElement(`h2`);l.id=`lens-setup-title`,l.textContent=a.title;let u=document.createElement(`p`);u.className=`body`,u.textContent=a.body;let d=document.createElement(`div`);d.className=`pair`,d.textContent=i;let f=document.createElement(`div`);if(f.className=`actions`,a.primary===`download`&&n.onDownload){let e=document.createElement(`button`);e.type=`button`,e.className=`btn primary`,e.textContent=`下载语言包`,e.addEventListener(`click`,()=>{Promise.resolve(n.onDownload?.())}),f.append(e)}if(n.onOpenLlmSetup){let e=document.createElement(`button`);e.type=`button`,e.className=a.primary===`llm`?`btn primary`:`btn`,e.textContent=`配置外部 LLM`,e.addEventListener(`click`,()=>{Promise.resolve(n.onOpenLlmSetup?.()),this.dismiss()}),f.append(e)}if(n.onOpenOnboarding){let e=document.createElement(`button`);e.type=`button`,e.className=`btn`,e.textContent=`打开设置向导`,e.addEventListener(`click`,()=>{Promise.resolve(n.onOpenOnboarding?.()),this.dismiss()}),f.append(e)}let p=document.createElement(`button`);p.type=`button`,p.className=`btn ghost`,p.textContent=`稍后`,p.addEventListener(`click`,()=>{n.onDismiss?.(),this.dismiss()}),f.append(p),c.append(l,u,d,f),s.append(c),this.root.append(o,s),document.documentElement.append(this.host),window.addEventListener(`keydown`,this.onKeyDown,!0)}setStatus(e,t=!1){if(!this.root)return;let n=this.root.querySelector(`.status`);n||(n=document.createElement(`p`),n.className=`status`,this.root.querySelector(`.card`)?.append(n)),n.textContent=e,n.dataset.error=t?`true`:`false`}dismiss(){window.removeEventListener(`keydown`,this.onKeyDown,!0),this.host?.remove(),this.host=null,this.root=null}isOpen(){return!!this.host?.isConnected}onKeyDown=e=>{e.key===`Escape`&&this.isOpen()&&(e.preventDefault(),e.stopPropagation(),this.dismiss())}};function Ft(e,t){return e.kind===`browser-unsupported`?{title:`当前浏览器未提供内置翻译`,body:`需要桌面版 Chrome 138+。若你以前能用，可先重新加载扩展或重启 Chrome 再试；也可改用外部 LLM。`,primary:`llm`}:e.kind===`external-unconfigured`?{title:`尚未配置外部翻译服务`,body:`当前选择了外部 LLM。请填写 Base URL、API Key 与模型，或改回 Chrome 内置翻译。`,primary:`llm`}:e.availability===`downloadable`||e.availability===`downloading`?{title:`需要下载语言包`,body:`语言对 ${t} 的 Chrome 语言包尚未就绪。下载后即可离线翻译；也可以改用外部 LLM。`,primary:`download`}:e.availability===`unavailable`?{title:`当前语言对不可用`,body:`Chrome 内置翻译不支持 ${t}。请更换语言，或切换到外部 LLM。`,primary:`llm`}:e.availability===`unsupported`?{title:`当前浏览器不支持内置翻译`,body:`需要桌面版 Chrome 138+ 的 Translator API，或改用外部 LLM 完成翻译。`,primary:`llm`}:{title:`翻译尚未就绪`,body:`请检查语言包状态，或在设置中切换到外部 LLM。`,primary:`none`}}var It=`
  :host { all: initial; }
  * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
  .backdrop {
    position: fixed;
    inset: 0;
    display: grid;
    place-items: center;
    padding: 20px;
    background: rgb(15 23 42 / 42%);
    backdrop-filter: blur(4px);
  }
  .card {
    width: min(420px, 100%);
    padding: 22px 22px 18px;
    border-radius: 16px;
    background: #fff;
    box-shadow: 0 24px 60px rgb(15 23 42 / 28%);
    color: #0f172a;
  }
  h2 {
    margin: 0 0 10px;
    font-size: 17px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }
  .body {
    margin: 0 0 12px;
    font-size: 13.5px;
    line-height: 1.55;
    color: #475569;
  }
  .pair {
    display: inline-flex;
    margin-bottom: 16px;
    padding: 5px 10px;
    border-radius: 999px;
    background: #eff6ff;
    color: #1d4ed8;
    font-size: 12px;
    font-weight: 600;
  }
  .actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  .btn {
    appearance: none;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    background: #f8fafc;
    color: #0f172a;
    font-size: 13px;
    font-weight: 600;
    padding: 9px 12px;
    cursor: pointer;
  }
  .btn:hover { background: #f1f5f9; }
  .btn.primary {
    border-color: #2563eb;
    background: #2563eb;
    color: #fff;
  }
  .btn.primary:hover { background: #1d4ed8; }
  .btn.ghost {
    border-color: transparent;
    background: transparent;
    color: #64748b;
  }
  .status {
    margin: 12px 0 0;
    font-size: 12.5px;
    color: #0369a1;
  }
  .status[data-error="true"] { color: #b91c1c; }
  @media (prefers-color-scheme: dark) {
    .card { background: #18181b; color: #f4f4f5; }
    .body { color: #a1a1aa; }
    .pair { background: #172554; color: #93c5fd; }
    .btn { border-color: #3f3f46; background: #27272a; color: #f4f4f5; }
    .btn:hover { background: #3f3f46; }
    .btn.ghost { color: #a1a1aa; }
  }
`,Lt=320,Rt=6;function zt(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-image-result`||typeof e.ok!=`boolean`?!1:e.ok?`translation`in e&&typeof e.translation==`string`:`error`in e&&typeof e.error==`string`}function Bt(e){return!e||typeof e!=`object`?!1:`id`in e&&typeof e.id==`string`&&`translation`in e&&typeof e.translation==`string`}function Q(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-batch-result`||typeof e.ok!=`boolean`?!1:e.ok?`translations`in e&&Array.isArray(e.translations)&&e.translations.every(Bt):!(`error`in e)||typeof e.error!=`string`?!1:!(`translations`in e)||e.translations===void 0||Array.isArray(e.translations)&&e.translations.every(Bt)}function Vt(e){return!e||typeof e!=`object`||!(`type`in e)||e.type!==`settings`||!(`configured`in e)||typeof e.configured!=`boolean`||!(`settings`in e)||!e.settings||typeof e.settings!=`object`||!(`paused`in e)||typeof e.paused!=`boolean`?!1:`apiKey`in e.settings&&e.settings.apiKey===``}function Ht(e){return!e||typeof e!=`object`||!(`type`in e)||e.type!==`background-error`?null:`error`in e&&typeof e.error==`string`?e.error:null}function Ut(e,t){return[e.translationEngine!==`external`||t,e.sourceLang,e.targetLang,e.translationEngine,e.minTextLength,e.batchCharLimit].join(`\0`)}function Wt(e,t){return[e.pageTranslationEngine!==`external`||t,e.sourceLang,e.targetLang,e.pageTranslationEngine,e.minTextLength,e.batchCharLimit].join(`\0`)}function Gt(e){return[e.pageTranslationDisplayMode,e.pageTranslationFontFamily,e.pageTranslationFontSizePx,e.pageTranslationUseOriginalFontSize,e.pageTranslationUseCustomColor,e.pageTranslationTextColor,e.pageTranslationUseBackground,e.pageTranslationBackgroundColor,e.pageTranslationBold,e.pageTranslationItalic,e.pageTranslationUnderline].join(`\0`)}var Kt=class r{registry=new Fe;imageRegistry=new Re;browserTranslator=new u;pageTranslator=new pt(this.browserTranslator);lens;batcher;setupPrompt=new Pt;selectionTranslator;shotTranslator=new Mt((e,t)=>this.translateShot(e,t),e=>this.onBubbleVisibility?.(!e&&this.bubbleVisibleNow()));settings=t;configured=!1;pausedHere=!1;lensSettingsSig=``;pageSettingsSig=``;pageStyleSig=``;autoPageStartPending=!1;autoPageRetryTimer=0;autoPageRetryDeadline=0;autoPageRetryAttempts=0;autoPageRetryBackoffMs=1e3;autoPageSuppress=!1;autoPageAbandoned=!1;autoPageNoticeAt=0;autoPageNoticeText=``;settingsGeneration=0;translationGeneration=0;lensActive=!1;lensSticky=!1;hotkeyDownAt=0;hotkeyHeld=!1;lastMouse={x:0,y:0};inflight=new Map;inflightTexts=new Map;imageInflight=new Set;editableCache=new Map;editableInflight=new Set;dictCache=new Map;dictInflight=new Set;starredKeys=new Set;lensPayload=null;resolvedSourceLang=null;resolvingSourceLang=null;pointerFrame=0;stickyFrame=0;listenersBound=!1;autoScanMo=null;onBubbleVisibility=null;constructor(e=340){this.lens=new Ie(e),this.batcher=new ze(e=>this.translateSpecific(e)),this.selectionTranslator=new Tt(e=>this.translateSelectionText(e),{onSpeak:e=>this.speak(e,this.settings.targetLang),onStar:(e,t)=>{this.saveToVocabulary(e,t)}}),this.lens.onSpeak(e=>{let t=this.lensPayload;if(!t)return;let n=e===`source`?t.sourceText:t.translation;n&&this.speak(n,e===`source`?t.sourceLang:t.targetLang)}),this.lens.onStar(()=>{let e=this.lensPayload;e?.translation&&this.saveToVocabulary(e.sourceText,e.translation,e)}),this.lens.onAction(()=>{let e=this.lensPayload;!e?.editable||!e.translation||this.replaceEditableContent(e.editable,e.translation)}),this.pageTranslator.setWordStarHandler(e=>{this.saveToVocabulary(e.source,e.translation,{sourceLang:e.sourceLang,targetLang:e.targetLang})})}setBubbleVisibilityHandler(e){this.onBubbleVisibility=e,e(this.settings.showFloatingBubble!==!1&&!this.pausedHere)}bindListeners(){if(this.listenersBound)return;this.listenersBound=!0,this.selectionTranslator.bind(),window.addEventListener(`keydown`,this.onKeyDown,!0),window.addEventListener(`keyup`,this.onKeyUp,!0),window.addEventListener(`blur`,this.onBlur),window.addEventListener(`mousemove`,this.onMouseMove,!0);let e=Qt(()=>{this.settings.autoTranslate&&this.scanVisibleAndTranslate()},300);window.addEventListener(`scroll`,e,!0),window.addEventListener(`resize`,e),window.addEventListener(`scroll`,this.onStickyReposition,!0),window.addEventListener(`resize`,this.onStickyReposition),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e.settings&&this.refreshSettings()}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(t.id!==chrome.runtime.id||!e||typeof e!=`object`)return!1;let r=e.type;return r===`toggle-page-translation`?(this.togglePageTranslation().then(n,e=>{n($(e))}),!0):r===`toggle-lens`?(this.toggleStickyLensAsync().then(n,e=>{n($(e))}),!0):r===`bubble-control`&&Xt(e)?(this.handleBubbleControl(e).then(n,e=>{n($(e))}),!0):!1})}async refreshSettings(){try{let t=await chrome.runtime.sendMessage({type:`get-settings`}),n=Ht(t);if(n)throw Error(n);if(!Vt(t))throw Error(`Invalid settings response`);let r=this.settings;this.configured=t.configured,this.settings=e(t.settings),this.settingsGeneration++,this.pausedHere=t.paused,this.pausedHere&&(this.lensActive&&this.deactivateLens(),this.pageTranslator.isActive()&&this.pageTranslator.deactivate(),this.selectionTranslator.hide(),this.suppressAutoPage(`paused`)),this.lens.setWidth(this.settings.lensWidthPx),this.lens.setFontSize(this.settings.pageTranslationFontSizePx),this.lens.setFontFamily(this.settings.pageTranslationFontFamily),this.lens.setAppearance(this.settings),this.lens.setLanguageLabels(i(this.syncSourceLang()),i(this.settings.targetLang)),this.selectionTranslator.setPaused(this.pausedHere),this.selectionTranslator.setEnabled(this.settings.selectionTranslate),this.selectionTranslator.setLanguages(this.syncSourceLang(),this.settings.targetLang),this.onBubbleVisibility?.(this.settings.showFloatingBubble&&!this.pausedHere),this.syncAutoScanObserver();let a=Ut(this.settings,this.configured),o=a!==this.lensSettingsSig,s=this.lensSettingsSig;this.lensSettingsSig=a;let c=Wt(this.settings,this.configured),l=c!==this.pageSettingsSig,u=this.pageSettingsSig;this.pageSettingsSig=c,(o||l)&&(this.resolvedSourceLang=null,this.editableCache.clear(),this.dictCache.clear(),this.dictErrors.clear(),this.lensPayload=null);let d=Gt(this.settings),f=d!==this.pageStyleSig;this.pageStyleSig=d,u!==``&&l&&this.pageTranslator.isActive()?this.pageTranslator.deactivate():f&&this.pageTranslator.isActive()&&this.pageTranslator.restyle(this.settings),this.settings.autoPageTranslation&&(!r.autoPageTranslation||l)&&(this.autoPageSuppress=!1,this.autoPageAbandoned=!1,this.resetAutoPageRetryBudget()),this.settings.autoPageTranslation||this.suppressAutoPage(`auto-off`),s!==``&&o&&(this.translationGeneration++,this.inflight.clear(),this.inflightTexts.clear(),this.registry.resetTranslationsToPending()),this.canTranslateText()&&this.settings.autoTranslate&&(o||!r.autoTranslate)&&this.scanVisibleAndTranslate(),this.settings.autoPageTranslation&&await this.maybeStartPageTranslation()}catch(e){console.warn(`[Lens Translator] settings refresh failed`,e instanceof Error?e.message:String(e))}}ensureMouseSeed(){this.lastMouse.x===0&&this.lastMouse.y===0&&(this.lastMouse={x:Math.round(window.innerWidth/2),y:Math.round(window.innerHeight/2)})}async togglePageTranslation(){if(this.pageTranslator.isActive())return this.pageTranslator.deactivate(),this.suppressAutoPage(`user-close`),{ok:!0};let e=await this.ensureEngineReady(`page`);if(!e.ok)return e;this.lensActive&&this.deactivateLens(),this.suppressAutoPage(`user-open`);let t={...this.settings,sourceLang:await this.effectiveSourceLang()};return await this.pageTranslator.toggle(t,this.configured),{ok:!0}}async toggleStickyLensAsync(){if(this.lensActive)return this.deactivateLens(),{ok:!0,lensActive:!1};if(this.pausedHere)return{ok:!1,error:`当前网站已暂停翻译`};let e=await this.ensureEngineReady(`lens`);return e.ok?(this.activateStickyLens(),{ok:!0,lensActive:!0}):e}activateStickyLens(){this.lensActive=!0,this.lensSticky=!0,this.hotkeyHeld=!1,this.ensureMouseSeed(),this.warmBrowserEngine(),this.refreshLensView()}activateTemporaryLens(e){this.lensActive=!0,this.lensSticky=!1,this.hotkeyDownAt=e,this.ensureMouseSeed(),this.warmBrowserEngine(),this.refreshLensView()}warmBrowserEngine(){this.settings.translationEngine===`browser`&&this.effectiveSourceLang().then(e=>this.browserTranslator.prepare(e,this.settings.targetLang))}refreshLensView(){this.tryFocusEditableLens()||this.updateLens()}tryFocusEditableLens(){if(!this.settings.inputTranslate)return!1;let e=Te(document.activeElement);return e?(this.updateEditableLens(e),!0):!1}async scanVisibleAndTranslate(){if(this.pausedHere||!this.settings.autoTranslate||!this.canTranslateText())return;let e=Math.round(window.innerHeight*this.settings.prefetchMarginRatio),t=Oe(this.settings.minTextLength,e);for(let e of t)this.registry.upsert({id:e.id,el:e.el,tag:e.tag,text:e.text});let n=this.registry.pendingBlocks().filter(e=>!this.inflight.has(e.id)&&!o(e.text,this.settings.targetLang));n.length&&await this.translateSpecific(n)}async maybeStartPageTranslation(){if(this.autoPageStartPending||this.autoPageSuppress||this.autoPageAbandoned||this.pausedHere||!this.settings.autoPageTranslation||this.pageTranslator.isActive())return;let e=this.settings;if(this.settings.sourceLang===`auto`){if(gt((document.body?.innerText||document.body?.textContent||``).slice(0,12e3))){this.scheduleAutoPageRetry(`auto:insufficient-sample`);return}let t=await this.effectiveSourceLang();if(J(t)===J(this.settings.targetLang)){this.abandonAutoPage(`auto:page-in-target-language`);return}e={...this.settings,sourceLang:t}}else{let e=_t(this.settings.sourceLang);if(!e.matches){e.shouldRetry?this.scheduleAutoPageRetry(`lang:${e.reason}`):this.abandonAutoPage(`lang:${e.reason}`);return}}if(this.settings.pageTranslationEngine===`external`&&!this.configured){this.abandonAutoPage(`external-unconfigured`);return}let t=this.settingsGeneration,n=e,r=this.configured;this.autoPageStartPending=!0;try{if(n.pageTranslationEngine===`browser`){let e=await this.browserTranslator.availability(n.sourceLang,n.targetLang);if(e!==`available`){e===`downloadable`||e===`downloading`?(this.scheduleAutoPageRetry(`pack:${e}`),this.noticeAutoPageBlocked(e===`downloading`?`Chrome 语言包下载中，就绪后将自动开启整页翻译`:`请先在设置中下载 Chrome 语言包，才能自动开启整页翻译`)):(this.abandonAutoPage(`pack:${e}`),this.noticeAutoPageBlocked(`Chrome 内置翻译当前不可用，自动整页已跳过（可改用外部 LLM 或手动开启）`));return}}if(t!==this.settingsGeneration||this.autoPageSuppress||this.pausedHere||!this.settings.autoPageTranslation||this.pageTranslator.isActive())return;this.clearAutoPageRetry(),await this.pageTranslator.activate(n,r),this.pageTranslator.isActive()?this.suppressAutoPage(`auto-started`):this.abandonAutoPage(`activate-failed`)}finally{this.autoPageStartPending=!1,t!==this.settingsGeneration&&this.settings.autoPageTranslation&&!this.autoPageSuppress&&!this.autoPageAbandoned&&!this.pausedHere&&!this.pageTranslator.isActive()&&this.maybeStartPageTranslation()}}static AUTO_PAGE_RETRY_MAX_ATTEMPTS=12;static AUTO_PAGE_RETRY_WINDOW_MS=12e3;static AUTO_PAGE_RETRY_BACKOFF_MAX_MS=2500;scheduleAutoPageRetry(e){if(!this.settings.autoPageTranslation||this.pausedHere||this.autoPageSuppress||this.autoPageAbandoned||this.pageTranslator.isActive())return;let t=Date.now();if(this.autoPageRetryDeadline||(this.autoPageRetryDeadline=t+r.AUTO_PAGE_RETRY_WINDOW_MS,this.autoPageRetryAttempts=0,this.autoPageRetryBackoffMs=1e3),t>this.autoPageRetryDeadline||this.autoPageRetryAttempts>=r.AUTO_PAGE_RETRY_MAX_ATTEMPTS){this.abandonAutoPage(`retry-budget-exhausted`);return}if(this.autoPageRetryTimer)return;let n=this.autoPageRetryBackoffMs;this.autoPageRetryAttempts++,this.autoPageRetryBackoffMs=Math.min(Math.round(this.autoPageRetryBackoffMs*1.35),r.AUTO_PAGE_RETRY_BACKOFF_MAX_MS),this.autoPageRetryTimer=window.setTimeout(()=>{this.autoPageRetryTimer=0,this.settings.autoPageTranslation&&!this.autoPageSuppress&&!this.autoPageAbandoned&&!this.pausedHere&&!this.pageTranslator.isActive()&&this.maybeStartPageTranslation()},n)}clearAutoPageRetry(){this.autoPageRetryTimer&&window.clearTimeout(this.autoPageRetryTimer),this.autoPageRetryTimer=0}resetAutoPageRetryBudget(){this.clearAutoPageRetry(),this.autoPageRetryDeadline=0,this.autoPageRetryAttempts=0,this.autoPageRetryBackoffMs=1e3}suppressAutoPage(e){this.autoPageSuppress=!0,this.clearAutoPageRetry()}abandonAutoPage(e){this.autoPageAbandoned=!0,this.clearAutoPageRetry(),this.autoPageRetryDeadline=0,this.autoPageRetryAttempts=0}noticeAutoPageBlocked(e){let t=Date.now();e===this.autoPageNoticeText&&t-this.autoPageNoticeAt<3e4||(this.autoPageNoticeAt=t,this.autoPageNoticeText=e,console.info(`[Lens Translator]`,e))}onKeyDown=e=>{if(e.key===`Escape`){if(this.lensActive){e.preventDefault(),this.deactivateLens();return}if(this.pageTranslator.isActive()){e.preventDefault(),this.pageTranslator.deactivate(),this.suppressAutoPage(`escape`);return}}if(!this.pausedHere){if(n(e,this.settings.pageTranslationHotkey)){if(e.repeat){e.preventDefault();return}e.preventDefault(),e.stopPropagation(),this.togglePageTranslation();return}if(n(e,this.settings.shotTranslateHotkey)){if(e.repeat){e.preventDefault();return}if(e.preventDefault(),e.stopPropagation(),this.shotTranslator.isSelecting()){this.shotTranslator.cancel();return}!this.startShotTranslate().ok&&!this.configured&&this.showEngineSetupPrompt({kind:`external-unconfigured`});return}if(n(e,this.settings.hotkey)){if(e.repeat){e.preventDefault();return}if(e.preventDefault(),e.stopPropagation(),this.lensActive&&this.lensSticky){this.deactivateLens();return}this.lensActive||(this.hotkeyHeld=!0,this.hotkeyDownAt=Date.now(),this.beginHotkeyLens(this.hotkeyDownAt))}}};async beginHotkeyLens(e){if(!(await this.ensureEngineReady(`lens`)).ok){this.hotkeyHeld=!1;return}if(!this.lensActive){if(!this.hotkeyHeld){let t=Date.now()-e;t>0&&t<Lt&&this.activateStickyLens();return}this.activateTemporaryLens(e)}}onKeyUp=e=>{let t=e.code===this.settings.hotkey.code,n=this.isHotkeyModifierRelease(e);if((t||n)&&(this.hotkeyHeld=!1),!(!this.lensActive||this.lensSticky)){if(t){let e=Date.now()-this.hotkeyDownAt;if(e>0&&e<Lt){this.lensSticky=!0;return}this.deactivateLens();return}n&&this.deactivateLens()}};onBlur=()=>{this.hotkeyHeld=!1,this.lensActive&&!this.lensSticky&&this.deactivateLens()};onMouseMove=e=>{let t=e.composedPath();t.includes(this.lens.getHost())||t.some(e=>e instanceof Element&&e.id===`lens-translator-bubble-root`)||(this.lastMouse={x:e.clientX,y:e.clientY},!(!this.lensActive||this.pointerFrame)&&(this.pointerFrame=requestAnimationFrame(()=>{this.pointerFrame=0,this.updateLens()})))};onStickyReposition=()=>{!this.lensActive||!this.lensSticky||this.stickyFrame||(this.stickyFrame=requestAnimationFrame(()=>{this.stickyFrame=0,this.lens.reposition()}))};updateLens(){if(!this.lensActive){this.lens.hide();return}this.ensureMouseSeed();let e=this.lens.getHost(),t=document.elementsFromPoint(this.lastMouse.x,this.lastMouse.y).filter(t=>t!==e&&!e.contains(t))[0]??null,n=this.imageEntryForHit(t);if(n){if(!this.configured){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`unconfigured`}),this.lens.highlight(null);return}let e=n.el.getBoundingClientRect();if(this.lens.highlight(n.el),n.status===`ready`&&n.translation){this.lensPayload={sourceText:``,translation:n.translation,sourceLang:this.syncSourceLang(),targetLang:this.settings.targetLang},this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`ready`,text:n.translation,sourceRect:e});return}if(n.status===`error`&&!this.imageInflight.has(n.id)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`error`,message:n.error??`图片翻译失败`,sourceRect:e});return}this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceRect:e}),this.translateImageEntry(n);return}if(!this.canTranslateText()){this.lensPayload=null,this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`unconfigured`}),this.lens.highlight(null);return}if(this.settings.inputTranslate){let e=Te(t);if(e){this.updateEditableLens(e);return}}let r=Math.min(2,this.settings.minTextLength),i=this.registry.getByElement(t);if(i){let e=Ee(this.lastMouse.x,this.lastMouse.y,r);e&&e.el!==i.el&&e.text.length<i.text.length&&(i=this.registry.upsert(e))}else{let e=Ee(this.lastMouse.x,this.lastMouse.y,r);e&&(i=this.registry.upsert(e))}if(!i){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`empty`}),this.lens.highlight(null);return}if(o(i.text,this.settings.targetLang)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`target-language`}),this.lens.highlight(i.el);return}this.lens.highlight(i.el);let s=i.el.getBoundingClientRect(),c=i.text,l=a(c);if(!(this.settings.translationEngine===`external`&&this.configured&&Yt(l)&&this.updateDictLens(i.id,l,s))){if(i.status===`ready`&&i.translation){this.lensPayload={sourceText:c,translation:i.translation,sourceLang:this.syncSourceLang(),targetLang:this.settings.targetLang},this.updateStarMarker(c,this.lensPayload.sourceLang),this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`ready`,text:i.translation,sourceText:c,sourceRect:s});return}if(i.status===`error`&&!this.inflight.has(i.id)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`error`,message:i.error??`翻译失败`,sourceText:c,sourceRect:s});return}this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceText:c,sourceRect:s}),this.inflight.has(i.id)||this.batcher.enqueue({id:i.id,tag:i.tag,text:i.text})}}updateEditableLens(e){let t=a(e.text),n=e.el.getBoundingClientRect();this.lens.highlight(e.el);let r=this.editableCache.get(t);if(r){this.lensPayload={sourceText:e.text,translation:r.translation,sourceLang:r.sourceLang,targetLang:r.targetLang,editable:e},this.updateStarMarker(e.text,r.sourceLang),this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`editable`,sourceText:e.text,translation:r.translation,status:`ready`,writable:e.writable,sourceRect:n});return}this.lensPayload={sourceText:e.text,translation:null,sourceLang:this.syncSourceLang(),targetLang:this.settings.targetLang,editable:e},this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`editable`,sourceText:e.text,translation:null,status:`pending`,writable:e.writable,sourceRect:n}),!this.editableInflight.has(t)&&(this.editableInflight.add(t),this.translateInputText(e.text).then(r=>{if(r)this.editableCache.set(t,r);else if(this.lensPayload?.editable&&a(this.lensPayload.editable.text)===t){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`editable`,sourceText:e.text,translation:null,status:`error`,error:`回译失败，请检查引擎或语言包`,writable:e.writable,sourceRect:n});return}this.lensActive&&this.updateLens()}).finally(()=>{this.editableInflight.delete(t)}))}updateDictLens(e,t,n){let r=this.settings.sourceLang===`auto`?this.resolvedSourceLang??bt(t)??`en`:this.settings.sourceLang,i=`${r}|${this.settings.targetLang}|${t.toLowerCase()}`,a=this.dictCache.get(i);if(a){let i=a.senses[0]?.gloss??``;return i&&this.registry.setTranslation(e,i),this.lensPayload={sourceText:t,translation:i||null,sourceLang:r,targetLang:this.settings.targetLang},this.updateStarMarker(t,r),this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`dict`,entry:a,sourceText:t,sourceRect:n}),!0}return this.dictErrors.has(i)?!1:(this.lensPayload={sourceText:t,translation:null,sourceLang:r,targetLang:this.settings.targetLang},this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceText:t,sourceRect:n}),this.dictInflight.has(i)?!0:(this.dictInflight.add(i),this.fetchDictionaryEntry(t,r).then(e=>{e?this.dictCache.set(i,e):this.dictErrors.add(i),this.lensActive&&this.updateLens()}).finally(()=>{this.dictInflight.delete(i)}),!0))}dictErrors=new Set;deactivateLens(){this.lensActive=!1,this.lensSticky=!1,this.hotkeyHeld=!1,this.hotkeyDownAt=0,this.lensPayload=null,this.stopSpeaking(),this.lens.hide()}async translateImageEntry(e){if(!(this.pausedHere||!this.configured||this.imageInflight.has(e.id))){this.imageInflight.add(e.id),this.imageRegistry.setPending(e.id);try{let t=await chrome.runtime.sendMessage({type:`translate-image`,imageUrl:e.url});zt(t)?t.ok?this.imageRegistry.setTranslation(e.id,t.translation):this.imageRegistry.setError(e.id,Zt(t.error)):this.imageRegistry.setError(e.id,`图片翻译服务未返回有效结果`)}catch(t){this.imageRegistry.setError(e.id,t instanceof Error?t.message:String(t))}finally{this.imageInflight.delete(e.id)}this.lensActive&&this.updateLens()}}async translateWithBrowser(e){if(!this.browserTranslator.isSupported())return;let t=this.translationGeneration,n=await this.effectiveSourceLang(),r=this.settings.targetLang;for(let i of e){if(t!==this.translationGeneration)return;let e=await this.browserTranslator.translate(i.text,n,r);if(t!==this.translationGeneration)return;e&&this.registry.setTranslation(i.id,e)}}async translateSpecific(e){if(this.pausedHere)return;let t=this.translationGeneration,n=this.settings.translationEngine,r=this.configured,i=[],s=new Set;for(let t of e){if(o(t.text,this.settings.targetLang))continue;let e=this.registry.get(t.id);if(!e||e.status===`ready`&&e.translation||this.inflight.has(t.id))continue;let n=a(t.text);if(!this.inflightTexts.has(n)){if(s.has(n)){this.registry.setPending(t.id);continue}s.add(n),i.push({id:t.id,tag:t.tag,text:n})}}if(!i.length)return;for(let e of i)this.inflight.set(e.id,t),this.inflightTexts.set(a(e.text),t),this.registry.setPending(e.id);let c=n===`browser`?`Chrome 内置翻译不可用或不支持当前语言对`:`外部 API 未配置`;try{if(n===`browser`)await this.translateWithBrowser(i);else if(r){let e=P(),n=await this.effectiveSourceLang(),r=this.settings.targetLang,a=null;if(await p(i,Rt,async i=>{if(t===this.translationGeneration){try{let o=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:e,blocks:[i],sourceLang:n,targetLang:r});if(t!==this.translationGeneration)return;if(!Q(o)){a===null&&(a=`翻译服务未返回有效结果`);return}for(let e of o.translations??[])this.registry.setTranslation(e.id,e.translation);!o.ok&&a===null&&(a=o.error)}catch(e){a===null&&(a=e instanceof Error?e.message:String(e))}this.lensActive&&this.updateLens()}}),t!==this.translationGeneration)return;a!==null&&(c=a)}if(t!==this.translationGeneration)return;for(let e of i)this.registry.get(e.id)?.translation||this.registry.setError(e.id,c)}catch(e){if(t!==this.translationGeneration)return;c=e instanceof Error?e.message:String(e);for(let e of i)this.registry.get(e.id)?.translation||this.registry.setError(e.id,c)}finally{for(let e of i){this.inflight.get(e.id)===t&&this.inflight.delete(e.id);let n=a(e.text);this.inflightTexts.get(n)===t&&this.inflightTexts.delete(n)}}this.lensActive&&this.updateLens()}canTranslateText(){return this.settings.translationEngine===`browser`?this.browserTranslator.isSupported():this.configured}speak(e,t){e&&chrome.runtime.sendMessage({type:`tts-speak`,text:e.slice(0,4e3),lang:t}).catch(()=>{})}stopSpeaking(){chrome.runtime.sendMessage({type:`tts-stop`}).catch(()=>void 0)}async saveToVocabulary(e,t,n){let r=n?.sourceLang??this.syncSourceLang(),i=n?.targetLang??this.settings.targetLang;await d({source:e,translation:t,sourceLang:r,targetLang:i,pageUrl:location.href})&&(this.starredKeys.add(l(e,r,i)),this.lens.setStarActive(!0))}updateStarMarker(e,t){let n=l(e,t,this.settings.targetLang);this.lens.setStarActive(this.starredKeys.has(n))}async effectiveSourceLang(){return this.settings.sourceLang===`auto`?this.resolvedSourceLang?this.resolvedSourceLang:(this.resolvingSourceLang||=(async()=>{let e=(document.body?.innerText||document.body?.textContent||``).slice(0,4e3);return this.resolvedSourceLang=await Ct(e,`en`),this.resolvedSourceLang})().finally(()=>{this.resolvingSourceLang=null}),this.resolvingSourceLang):this.settings.sourceLang}syncSourceLang(){return this.settings.sourceLang===`auto`?this.resolvedSourceLang??`en`:this.settings.sourceLang}async translateInputText(e){let t=await this.effectiveSourceLang(),n=!o(e,this.settings.targetLang),r=n?t:this.settings.targetLang,i=n?this.settings.targetLang:t;if(this.settings.translationEngine===`browser`){let t=await this.browserTranslator.translate(e,r,i);return t?{translation:t,sourceLang:r,targetLang:i}:null}if(!this.configured)return null;let a=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:P(),blocks:[{id:`input`,tag:`editable`,text:e}],sourceLang:r,targetLang:i});if(!Q(a)||!a.ok)return null;let s=a.translations.find(e=>e.id===`input`)?.translation;return s?{translation:s,sourceLang:r,targetLang:i}:null}replaceEditableContent(e,t){let n=e.el;n.focus();let r=!1;try{e.kind===`contenteditable`?r=document.execCommand(`selectAll`,!1)&&document.execCommand(`insertText`,!1,t):(n.select(),r=document.execCommand(`insertText`,!1,t))}catch{r=!1}if(!r)if(e.kind===`contenteditable`)n.textContent=t,n.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`,data:t}));else{let e=n;e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}this.editableCache.set(a(t),{translation:t,sourceLang:this.settings.targetLang,targetLang:this.syncSourceLang()}),this.updateLens()}async fetchDictionaryEntry(e,t){let n=await chrome.runtime.sendMessage({type:`translate-dict`,text:e,sourceLanguage:t,targetLanguage:this.settings.targetLang});return!qt(n)||!n.ok?null:n.entry}syncAutoScanObserver(){if(this.settings.autoTranslate&&!this.pausedHere){this.autoScanMo||(this.autoScanMo=new MutationObserver(Qt(()=>{this.settings.autoTranslate&&this.scanVisibleAndTranslate()},500)),this.autoScanMo.observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0}));return}this.autoScanMo?.disconnect(),this.autoScanMo=null}async ensureEngineReady(e,t){if(this.pausedHere)return{ok:!1,error:`当前网站已暂停翻译`};let n=e===`lens`?this.settings.translationEngine:this.settings.pageTranslationEngine,r=t?.quiet===!0;if(n===`external`)return this.configured?{ok:!0}:(r||this.showEngineSetupPrompt({kind:`external-unconfigured`}),{ok:!1,error:e===`lens`?`透镜翻译需要先配置外部 API`:`整页翻译需要先配置外部 API`});let i=await this.browserTranslator.availability(await this.effectiveSourceLang(),this.settings.targetLang);return i===`available`?{ok:!0}:i===`unsupported`?(r||this.showEngineSetupPrompt({kind:`browser-unsupported`}),{ok:!1,error:`当前浏览器不支持 Chrome 内置翻译（需桌面版 Chrome 138+）`}):(r||this.showEngineSetupPrompt({kind:`language-pack`,availability:i}),{ok:!1,error:i===`downloadable`||i===`downloading`?`需要先下载 Chrome 语言包`:`Chrome 内置翻译暂时不可用（语言包未就绪或本页策略限制），请稍后重试或改用外部 LLM`})}showEngineSetupPrompt(e){this.setupPrompt.isOpen()||this.setupPrompt.show(e,{sourceLang:this.settings.sourceLang,targetLang:this.settings.targetLang},{onDownload:e.kind===`language-pack`?async()=>{if(this.setupPrompt.setStatus(`正在下载语言包…`),await this.browserTranslator.prepare(this.settings.sourceLang,this.settings.targetLang,e=>{this.setupPrompt.setStatus(`语言包下载 ${Math.round(e*100)}%`)})){this.setupPrompt.setStatus(`语言包已就绪，请再次开启翻译`),window.setTimeout(()=>this.setupPrompt.dismiss(),900);return}let e=this.browserTranslator.lastError?.trim();this.setupPrompt.setStatus(e?`语言包下载失败：${e}`:`语言包下载失败，请检查网络或改用外部 LLM`,!0)}:void 0,onOpenLlmSetup:()=>{chrome.runtime.sendMessage({type:`open-options`,hash:`#external-api`}).catch(()=>{})},onOpenOnboarding:()=>{chrome.runtime.sendMessage({type:`open-options`,hash:`#onboarding`}).catch(()=>{})}})}async translateSelectionText(e){if(this.pausedHere)return null;if(this.settings.translationEngine===`browser`)return(await this.ensureEngineReady(`lens`,{quiet:!0})).ok?this.browserTranslator.translate(e,await this.effectiveSourceLang(),this.settings.targetLang):null;if(!(await this.ensureEngineReady(`lens`,{quiet:!0})).ok)return null;let t=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:P(),blocks:[{id:`sel`,tag:`selection`,text:e}],sourceLang:await this.effectiveSourceLang(),targetLang:this.settings.targetLang});return!Q(t)||!t.ok?null:t.translations.find(e=>e.id===`sel`)?.translation??null}bubbleState(){return{ok:!0,lensActive:this.lensActive,pageTranslationActive:this.pageTranslator.isActive()}}async handleBubbleControl(e){if(e.command===`get-state`)return this.bubbleState();if(e.command===`toggle-lens`){let e=await this.toggleStickyLensAsync();return e.ok?this.bubbleState():e}if(e.command===`retranslate-page`){let e=await this.retranslatePage();return e.ok?this.bubbleState():e}if(e.command===`shot-translate`){let e=this.startShotTranslate();return e.ok?this.bubbleState():e}let t=await this.togglePageTranslation();return t.ok?this.bubbleState():t}startShotTranslate(){return this.pausedHere?{ok:!1,error:`当前网站已暂停翻译`}:this.configured?(this.lensActive&&this.deactivateLens(),this.shotTranslator.start(),{ok:!0}):{ok:!1,error:`截图翻译需要外部多模态模型：请先完成配置`}}bubbleVisibleNow(){return this.settings.showFloatingBubble!==!1&&!this.pausedHere}async translateShot(e,t){let n=await chrome.runtime.sendMessage({type:`translate-shot`,rect:e,devicePixelRatio:t});if(n&&typeof n==`object`&&`type`in n&&n.type===`translate-shot-result`&&`ok`in n){if(n.ok===!0&&`translation`in n&&`image`in n)return{ok:!0,translation:String(n.translation),image:String(n.image)};if(n.ok===!1&&`error`in n)return{ok:!1,error:String(n.error)}}return{ok:!1,error:`翻译服务未返回有效结果`}}async retranslatePage(){let e=await this.ensureEngineReady(`page`);if(!e.ok)return e;this.lensActive&&this.deactivateLens(),this.suppressAutoPage(`user-open`);let t={...this.settings,sourceLang:await this.effectiveSourceLang()};return await this.pageTranslator.refresh(t,this.configured),{ok:!0}}imageEntryForHit(e){if(!(e instanceof HTMLImageElement)||!e.complete||e.naturalWidth<2||e.naturalHeight<2)return;let t=e.currentSrc||e.src;if(t)return this.imageRegistry.upsert(f(`img`,t,b(e)),e,t)}isHotkeyModifierRelease(e){let t=this.settings.hotkey;return!!(t.altKey&&(e.code===`AltLeft`||e.code===`AltRight`)||t.shiftKey&&(e.code===`ShiftLeft`||e.code===`ShiftRight`)||t.ctrlKey&&(e.code===`ControlLeft`||e.code===`ControlRight`)||t.metaKey&&(e.code===`MetaLeft`||e.code===`MetaRight`))}};function qt(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-dict-result`||typeof e.ok!=`boolean`?!1:e.ok?`entry`in e&&typeof e.entry==`object`:`error`in e&&typeof e.error==`string`}var Jt=/^[\p{L}\p{M}'-]+(?: [\p{L}\p{M}'-]+)?$/u;function Yt(e){return e.length<=60&&Jt.test(e)}function Xt(e){return`command`in e?e.command===`get-state`||e.command===`toggle-page-translation`||e.command===`toggle-lens`||e.command===`retranslate-page`||e.command===`shot-translate`:!1}function $(e){return{ok:!1,error:e instanceof Error?e.message:String(e)}}function Zt(e){let t=e.toLowerCase();return e.includes(`API not configured`)||e.includes(`未配置`)?`图片翻译需要外部多模态模型：请先配置 Base URL、API Key 与支持 image 的模型`:t.includes(`image`)&&(t.includes(`not support`)||t.includes(`unsupported`)||t.includes(`invalid`)||t.includes(`不支持`))?e:e.includes(`400`)||t.includes(`invalid_request`)||t.includes(`unknown field`)?`当前模型可能不支持图片输入：${e}`:e}function Qt(e,t){let n=0;return((...r)=>{window.clearTimeout(n),n=window.setTimeout(()=>e(...r),t)})}var $t=`lens-translator-bubble-shell`,en=class{host;frame;pinned=!1;collapseTimer=0;mountObserver;constructor(){this.host=document.createElement(`div`),this.host.id=`lens-translator-bubble-root`,this.host.setAttribute(`data-lens-ignore`,``);let e=this.host.attachShadow({mode:`closed`}),t=document.createElement(`style`);t.textContent=nn,this.frame=document.createElement(`iframe`),this.frame.src=chrome.runtime.getURL(`src/bubble/index.html`),this.frame.title=`Lens Translator 快捷控制`,this.frame.setAttribute(`allow`,`clipboard-write`),e.append(t,this.frame),this.host.addEventListener(`pointerenter`,()=>this.expand()),this.host.addEventListener(`pointerleave`,()=>this.scheduleCollapse()),window.addEventListener(`message`,this.onMessage),this.mountObserver=new MutationObserver(()=>{this.host.isConnected||this.mount()}),this.mountObserver.observe(document.documentElement,{childList:!0})}mount(){this.host.isConnected||document.documentElement.append(this.host)}setVisible(e){this.host.style.display=e?``:`none`,e||(this.pinned=!1,delete this.host.dataset.expanded)}expand(){window.clearTimeout(this.collapseTimer),this.host.dataset.expanded=`true`}scheduleCollapse(){this.pinned||(window.clearTimeout(this.collapseTimer),this.collapseTimer=window.setTimeout(()=>{delete this.host.dataset.expanded},420))}onMessage=e=>{if(!(e.source!==this.frame.contentWindow||!tn(e.data))){if(e.data.action===`pin`){this.pinned=!0,this.expand();return}this.pinned=!1,e.data.action===`collapse`?delete this.host.dataset.expanded:this.scheduleCollapse()}}};function tn(e){if(!e||typeof e!=`object`)return!1;let t=e;return t.type===$t&&(t.action===`pin`||t.action===`unpin`||t.action===`collapse`)}var nn=`
  :host { all: initial; }
  iframe {
    display: block;
    width: 100%;
    height: 100%;
    border: 0;
    background: transparent;
  }
  :host {
    position: fixed;
    z-index: 2147483646;
    top: clamp(88px, 42vh, calc(100vh - 88px));
    right: -13px;
    width: 62px;
    height: 62px;
    overflow: hidden;
    pointer-events: auto;
    border-radius: 18px 0 0 18px;
    filter: drop-shadow(0 10px 24px rgb(15 23 42 / 16%));
    transition:
      width 280ms cubic-bezier(.2,.8,.2,1),
      height 280ms cubic-bezier(.2,.8,.2,1),
      right 280ms cubic-bezier(.2,.8,.2,1),
      top 280ms cubic-bezier(.2,.8,.2,1),
      border-radius 220ms ease;
  }
  :host([data-expanded="true"]) {
    top: clamp(12px, calc(50vh - 260px), 28px);
    right: 12px;
    width: min(360px, calc(100vw - 24px));
    height: min(520px, calc(100vh - 24px));
    border-radius: 12px;
  }
  @media (max-width: 520px) {
    :host([data-expanded="true"]) {
      top: 8px;
      right: 8px;
      width: calc(100vw - 16px);
      height: min(520px, calc(100vh - 16px));
    }
  }
  @media (prefers-reduced-motion: reduce) {
    :host { transition-duration: 1ms; }
  }
`,rn=`__lensTranslatorMounted`,an=window;async function on(){if(an[rn])return;an[rn]=!0;let e=new Kt(340),t=new en;t.mount(),e.setBubbleVisibilityHandler(e=>t.setVisible(e)),e.bindListeners(),e.ensureMouseSeed(),await e.refreshSettings()}on();
//# sourceMappingURL=main.ts-C1Zih6MJ.js.map
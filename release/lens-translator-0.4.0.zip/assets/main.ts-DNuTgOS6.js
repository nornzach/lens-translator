import{i as e,t}from"./settings-defaults-D6xjKQHY.js";import{i as n}from"./hotkey-tZ8Jri1V.js";import{n as r,t as i}from"./languages-C1-vhm4e.js";import{a,i as o,n as s,r as c,t as l}from"./text-CgJ50h6s.js";import{t as u}from"./browser-translator-B3qLF_W1.js";function d(e,t,n){let r=`${e.toLowerCase()}|${o(t)}|${n}`,i=2166136261;for(let e=0;e<r.length;e++)i^=r.charCodeAt(e),i=Math.imul(i,16777619);return`b_${(i>>>0).toString(36)}`}var f=`data-lens-translator-source`,p=[`p`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`li`,`blockquote`,`figcaption`,`caption`,`td`,`th`,`dt`,`dd`,`summary`,`label`,`legend`,`address`,`article`],m=[`[role="heading"]`,`[role="listitem"]`,`[role="paragraph"]`,`[role="article"]`,`[role="text"]`,`[role="tab"]`,`[role="menuitem"]`,`[role="menuitemradio"]`,`[role="option"]`,`[role="button"]`,`[role="link"]`],ee=`.markdown-body,.markdown-content,.markdown,.md-content,.md-typeset,.prose,.Post-body,.post-content,.entry-content,.article-content,.article-body,.post-body,.rich-text,.RichText,.notion-page-content,[data-testid="post_message"],.message-body,.comment-body,.js-comment-body,.wiki-body,.doc-content,.docs-content,.content__default,.theme-default-content,.vp-doc,.mdx-content,[class*="Markdown"],[class*="markdown"],[class*="ProseMirror"],[class*="DraftEditor"],[class*="ql-editor"],[class*="tiptap"],[class*="slate-"],[data-slate-editor]`.split(`,`),h=/(?:^|[\s_-])(?:paragraph|text-block|textblock|richtext|rich-text|post-body|postbody|entry-content|article-body|md-p|md-block|markdown-p|block-paragraph|block-text|notion-text|notion-page-block|pw-post-body|reader-word|transcript|caption-text|message-text|comment-text|answer-text|question-title|issue-body)(?:$|[\s_-])/i,te=/paragraph|text|heading|list.?item|quote|callout|toggle|bulleted|numbered|to.?do/i,g=new Set(`a.abbr.b.bdi.bdo.br.cite.code.data.dfn.em.i.kbd.mark.q.rp.rt.ruby.s.samp.small.span.strong.sub.sup.time.u.var.wbr.svg.img.picture.source.font.strike.big.tt.acronym.del.ins.math.mi.mo.mn.mrow.msup.msub`.split(`.`)),ne=`script.style.noscript.template.svg.canvas.video.audio.iframe.object.embed.textarea.input.select.nav.pre.[contenteditable]:not([contenteditable="false"]).[role="textbox"].[class*="DraftEditorPlaceholder"].[class*="EditorPlaceholder"].[class*="editor-placeholder"].[aria-hidden="true"].[role="navigation"].[role="banner"].[role="search"].[role="toolbar"].[role="tooltip"].tool-tip.[data-lens-ignore].[data-lens-page-translation].#lens-translator-root`.split(`.`).join(`, `),_=new Set(`script.style.noscript.template.svg.canvas.video.audio.iframe.object.embed.textarea.input.select.option.nav.pre.code.br.hr.img.path.meta.link.head.html.body`.split(`.`));function v(e){let t=[],n=e,r=0;for(;n&&r<8;){let e=n.parentElement,i=0;if(e){let t=[...e.children].filter(e=>e.tagName===n.tagName);i=Math.max(0,t.indexOf(n))}let a=n.tagName.toLowerCase();t.push(`${a}[${i}]`),n=e,r++}return`/`+t.reverse().join(`/`)}function y(e,t){let n=e.getBoundingClientRect();if(!b(e,n))return!1;let r=window.innerHeight,i=window.innerWidth;return!(n.bottom<-t||n.top>r+t||n.right<0||n.left>i)}function b(e,t=e.getBoundingClientRect()){if(t.width<2||t.height<2)return!1;let n=window.getComputedStyle(e);return!(n.display===`none`||n.visibility===`hidden`||n.opacity===`0`)}var re=new Set([`script`,`style`,`noscript`,`template`]);function x(e){if(typeof e.querySelector!=`function`||typeof document>`u`||typeof document.createTreeWalker!=`function`||!e.querySelector(`script, style, noscript, template`))return e.textContent??``;let t=document.createTreeWalker(e,4,{acceptNode(t){let n=t.parentElement;for(;n&&n!==e;){if(re.has(n.tagName.toLowerCase()))return 2;n=n.parentElement}return 1}}),n=``,r=t.nextNode();for(;r;)n+=r.nodeValue??``,r=t.nextNode();return n}function S(e){return o(e.getAttribute(`data-lens-translator-source`)??x(e))}function C(e){for(let t of e.children){let e=t.tagName.toLowerCase();if(e.includes(`-`)||!g.has(e)||e!==`br`&&e!==`img`&&e!==`source`&&e!==`wbr`&&e!==`path`&&!C(t))return!1}return!0}function ie(e){return typeof e.className==`string`?e.className:e.getAttribute(`class`)??``}function ae(e){let t=ie(e);if(h.test(t))return!0;let n=e.getAttribute(`data-testid`)||e.getAttribute(`data-test`)||``;if(h.test(n))return!0;let r=e.getAttribute(`data-block-type`)||e.getAttribute(`data-type`)||e.getAttribute(`data-slate-type`)||e.getAttribute(`data-text-type`)||``;if(r&&te.test(r))return!0;let i=e.getAttribute(`role`)||``;return i===`heading`||i===`listitem`||i===`paragraph`||i===`text`}function oe(e){return e.tagName.includes(`-`)}function w(e){let t=0;for(let n of p)if(t+=e.querySelectorAll(n).length,t>3)return t;for(let n of m)if(t+=e.querySelectorAll(n).length,t>3)return t;return t}function se(e){return e.querySelectorAll(`a, button, [role="link"], [role="button"], [role="tab"], [role="menuitem"], [role="menuitemradio"], [role="option"]`).length>1}function T(e){let t=(e.getAttribute(`role`)||``).toLowerCase();if(t===`tab`||t===`menuitem`||t===`menuitemradio`||t===`option`||t===`button`||t===`link`)return!0;let n=e.tagName.toLowerCase();if(n===`button`||n===`summary`)return!0;if(n===`a`){let t=S(e);if(t.length>0&&t.length<=48&&(C(e)||e.children.length===0))return!0}if(e.closest(`[role="tablist"]`)&&(n===`div`||n===`span`||n===`li`)&&(C(e)||e.children.length===0)){let t=S(e);if(t.length>0&&t.length<=48)return!0}return!1}function E(e,t){let n=e.tagName.toLowerCase(),r=S(e);if(T(e))return c(r,Math.min(2,t))&&r.length<=80;if(_.has(n)||!c(r,t))return!1;if(C(e))return!se(e);if(ae(e)){let n=w(e);if(n<=2&&r.length<=2e3||n===0&&r.length>=t&&r.length<=1500)return!0}if(oe(e)){let n=w(e);if(n===0&&C(e)||n<=1&&r.length<=1200&&r.length>=t)return!0}return!1}function ce(e,t){return!T(e)&&w(e)>1&&S(e).length>t*2}function D(e){if(e.closest(`#lens-translator-root`)||!e.hasAttribute(`data-lens-translator-source`)&&e.querySelector(`[data-lens-page-translation]`)||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`)return!0;if(T(e))return!!e.closest(`script, style, noscript, template, textarea, input, select, svg, canvas`);if(e.closest(ne))return!0;let t=e.tagName.toLowerCase();return!!_.has(t)}function le(e=document){let t=[],n=new Set,r=e=>{for(let r of e)n.has(r)||(n.add(r),t.push(r))};r(e.querySelectorAll(p.join(`,`))),r(e.querySelectorAll(m.join(`,`))),r(e.querySelectorAll(`button, [role="tablist"] button, [role="tablist"] a, [role="tablist"] [role="tab"]`)),r(e.querySelectorAll(`[role="tablist"] > *, [role="tablist"] [role="presentation"] > *`)),r(e.querySelectorAll(`a, [role="link"]`));for(let t of e.querySelectorAll(ee.join(`,`)))r(t.querySelectorAll(p.join(`,`))),r(t.querySelectorAll(`:scope > div, :scope > span, :scope > section`)),r(t.querySelectorAll(`div > p, div > li, div > h1, div > h2, div > h3, section > p`));r(e.querySelectorAll([`[data-block-type]`,`[data-slate-type]`,`[data-text-type]`,`[class*="paragraph"]`,`[class*="Paragraph"]`,`[class*="text-block"]`,`[class*="TextBlock"]`,`[class*="notion-text"]`,`[class*="markdown"] p`,`[class*="Markdown"] p`,`[class*="prose"] p`,`[class*="prose"] li`].join(`,`))),r(e.querySelectorAll(`div, span, section, article, main`));for(let r of e.querySelectorAll(`*`))r.tagName.includes(`-`)&&!n.has(r)&&(n.add(r),t.push(r));return t}function ue(e,t,n){if(D(e)||(n===null?!b(e):!y(e,n)))return;let r=e.tagName.toLowerCase(),i=p.includes(r),a=e.getAttribute(`role`)||``,o=a===`heading`||a===`listitem`||a===`paragraph`||a===`text`||a===`tab`||a===`menuitem`||a===`button`||a===`link`,s=T(e),l=s?Math.min(2,t):t;if(s){if(!E(e,t))return}else if(i||o){if(!c(S(e),l)||ce(e,t))return}else if(!E(e,t))return;let u=S(e);if(c(u,l))return{id:d(r,u,v(e)),el:e,tag:r,text:u}}var de=new Set([`script`,`style`,`noscript`,`template`,`canvas`,`video`,`audio`,`iframe`,`object`,`embed`,`textarea`,`input`,`select`,`option`,`br`,`hr`,`img`,`path`,`meta`,`link`,`head`,`html`,`body`,`svg`]),fe=`script, style, noscript, template, canvas, video, audio, iframe, object, embed, textarea, input, select, [data-lens-ignore], #lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt`;function O(e){if(e.closest(fe)||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`)return!0;let t=e.tagName.toLowerCase();return!!de.has(t)}function pe(e,t){return t.length<280?!1:e.querySelectorAll(`p, li, h1, h2, h3, h4, h5, h6, tr, blockquote, pre, section, article`).length>=4}function me(e,t){return T(e)?1:Math.max(1,Math.min(t,2))}function he(e,t=1){let n=e;for(;n!==null;){let e=n,r=e.tagName.toLowerCase();if(r===`html`||r===`body`)break;let i=!0;if(!O(e)){try{i=b(e)}catch{i=!0}if(i){let n=S(e);if(c(n,me(e,t))&&n.length<=4e3&&!pe(e,n))return{id:d(r,n,v(e)),el:e,tag:r,text:n}}}n=e.parentElement}}function k(e,t,n=1){let r=null;try{let n=document;if(typeof n.caretRangeFromPoint==`function`){let i=n.caretRangeFromPoint(e,t)?.startContainer;i&&(r=i.nodeType===Node.TEXT_NODE?i.parentElement:i instanceof Element?i:null)}else if(typeof n.caretPositionFromPoint==`function`){let i=n.caretPositionFromPoint(e,t)?.offsetNode;i&&(r=i.nodeType===Node.TEXT_NODE?i.parentElement:i instanceof Element?i:null)}}catch{}if(!r)try{r=document.elementsFromPoint(e,t).find(e=>e.id!==`lens-translator-root`&&!e.closest?.(`#lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root`)&&!O(e))??null}catch{r=null}return he(r,n)||ge(r,n)}function ge(e,t){let n=e;for(;n&&n.tagName.toLowerCase()!==`html`;){let e=ue(n,t,0);if(e)return e;n=n.parentElement}}function _e(e,t){return j(document,e,t)}function ve(e,t=document){let n=A(t),r=n.flatMap(t=>j(t,e,null)),i=new Set(r.map(e=>e.el)),a=n.flatMap(t=>xe(t,e,i));return[...r,...a]}function A(e=document){let t=[e];`shadowRoot`in e&&e.shadowRoot&&t.push(e.shadowRoot);for(let e=0;e<t.length;e++)for(let n of t[e].querySelectorAll(`*`))n.shadowRoot&&t.push(n.shadowRoot);return t}function ye(e){let t=e.parentElement;if(!t)return null;let n=t;for(;g.has(n.tagName.toLowerCase());){let e=n.parentElement;if(!e||e.tagName.toLowerCase()===`body`)break;n=e}let r=n.tagName.toLowerCase();return r===`html`||r===`body`?null:n}function be(e,t){let n=e;for(;n;){if(t.has(n))return!0;n=n.parentElement}return!1}function xe(e,t,n){let r=new Map,i=document.createTreeWalker(e,4),a=i.nextNode();for(;a;){let e=a,t=o(e.data),s=e.parentElement;if(t&&s&&!be(s,n)){let n=ye(e);if(n&&!D(n)){let e=r.get(n)??[];e.push(t),r.set(n,e)}}a=i.nextNode()}let s=[];for(let[e,i]of r){if(!b(e))continue;let r=o(i.join(` `));if(!c(r,T(e)?Math.min(2,t):t))continue;let a=e.tagName.toLowerCase(),l={id:d(a,r,v(e)),el:e,tag:a,text:r};s.push(l),n.add(e)}return s}function j(e,t,n){let r=le(e),i=[],a=new Set,o=new Set;for(let e of r){if(o.has(e))continue;let r=ue(e,t,n);!r||a.has(r.id)||(a.add(r.id),o.add(r.el),i.push(r))}return Se(i)}function Se(e){if(e.length<=1)return e;let t=new Map(e.map(e=>[e.el,e])),n=new Set;for(let r of e){let e=r.el.parentElement;for(;e;){let i=t.get(e);if(i&&r.text.length>=Math.min(i.text.length*.5,i.text.length-1)&&(i.text.length<=r.text.length+40||i.el.querySelectorAll(`p,li,h1,h2,h3,h4,h5,h6`).length>=1)){n.add(i);break}e=e.parentElement}}return e.filter(e=>!n.has(e))}var Ce=class{byId=new Map;byEl=new WeakMap;byNormText=new Map;maxEntries;maxTranslations;constructor(e=1500,t=2500){this.maxEntries=Math.max(1,e),this.maxTranslations=Math.max(1,t)}upsert(e){let t=this.byId.get(e.id);t||this.makeRoom();let n=o(e.text),r=this.byNormText.get(n),i={id:e.id,el:e.el,tag:e.tag,text:e.text,status:e.status??t?.status??`pending`,translation:t?.translation,error:t?.error};return t&&t.text===i.text&&t.translation?(i.translation=t.translation,i.status=`ready`):r&&(i.translation=r,i.status=`ready`,i.error=void 0),this.byId.set(i.id,i),this.byEl.set(i.el,i.id),i}setTranslation(e,t){let n=this.byId.get(e);if(!n)return;let r=o(n.text);for(this.byNormText.delete(r),this.byNormText.set(r,t);this.byNormText.size>this.maxTranslations;){let e=this.byNormText.keys().next().value;if(e===void 0)break;this.byNormText.delete(e)}for(let e of this.byId.values())o(e.text)===r&&(e.translation=t,e.status=`ready`,e.error=void 0)}setError(e,t){let n=this.byId.get(e);n&&(n.status=`error`,n.error=t)}setPending(e){let t=this.byId.get(e);t&&t.status!==`ready`&&(t.status=`pending`)}get(e){return this.byId.get(e)}getByElement(e){if(!e)return;let t=e;for(;t;){let e=this.byEl.get(t);if(e)return this.byId.get(e);t=t.parentElement}}pendingBlocks(){return[...this.byId.values()].filter(e=>e.status===`pending`).map(e=>({id:e.id,tag:e.tag,text:e.text}))}resetTranslationsToPending(){this.byNormText.clear();for(let e of this.byId.values())e.status=`pending`,e.translation=void 0,e.error=void 0}makeRoom(){if(!(this.byId.size<this.maxEntries)){for(let[e,t]of this.byId)t.el.isConnected||this.byId.delete(e);for(;this.byId.size>=this.maxEntries;){let e=this.byId.keys().next().value;if(e===void 0)break;this.byId.delete(e)}}}},we=class{host;root;panel;textLayer;sourceLabel;sourceBody;zhLabel;body;divider;hint;ring;highlightEl=null;widthPx;lastSourceKey=``;sourceLangLabel=`源语言`;targetLangLabel=`译文`;constructor(e=340){this.widthPx=e,this.host=document.createElement(`div`),this.host.id=`lens-translator-root`,Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,pointerEvents:`none`,zIndex:`2147483647`}),this.root=this.host.attachShadow({mode:`open`});let t=document.createElement(`style`);t.textContent=Te;let n=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);n.setAttribute(`aria-hidden`,`true`),n.setAttribute(`width`,`0`),n.setAttribute(`height`,`0`),n.style.position=`absolute`,n.innerHTML=`
      <defs>
        <filter id="glass-distortion" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.008 0.008" numOctaves="2" seed="3" result="noise" />
          <feGaussianBlur in="noise" stdDeviation="0.5" result="softNoise" />
          <feDisplacementMap in="SourceGraphic" in2="softNoise" scale="12" xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </defs>
    `,this.ring=document.createElement(`div`),this.ring.className=`source-outline`,this.ring.style.display=`none`,this.panel=document.createElement(`div`),this.panel.className=`liquidGlass-wrapper panel`,this.panel.style.display=`none`;let r=document.createElement(`div`);r.className=`liquidGlass-effect`;let i=document.createElement(`div`);i.className=`liquidGlass-tint`;let a=document.createElement(`div`);a.className=`liquidGlass-shine`,this.textLayer=document.createElement(`div`),this.textLayer.className=`liquidGlass-text`,this.sourceLabel=document.createElement(`div`),this.sourceLabel.className=`label label-source`,this.sourceLabel.textContent=this.sourceLangLabel,this.sourceBody=document.createElement(`div`),this.sourceBody.className=`body body-source`,this.divider=document.createElement(`div`),this.divider.className=`divider`,this.zhLabel=document.createElement(`div`),this.zhLabel.className=`label label-target`,this.zhLabel.textContent=this.targetLangLabel,this.body=document.createElement(`div`),this.body.className=`body body-zh`,this.hint=document.createElement(`div`),this.hint.className=`hint`,this.textLayer.append(this.sourceLabel,this.sourceBody,this.divider,this.zhLabel,this.body,this.hint),this.panel.append(r,i,a,this.textLayer),this.root.append(t,n,this.ring,this.panel),this.applyWidth()}applyWidth(){this.panel.style.width=`${this.widthPx}px`,this.panel.style.maxWidth=`${this.widthPx}px`}mount(){this.host.isConnected||document.documentElement.appendChild(this.host)}setWidth(e){this.widthPx=Math.max(280,e),this.applyWidth()}setLanguageLabels(e,t){this.sourceLangLabel=e||`源语言`,this.targetLangLabel=t||`译文`,this.sourceLabel.textContent=this.sourceLangLabel,this.zhLabel.textContent=this.targetLangLabel}setFontSize(e){let t=Math.max(10,Math.min(28,e));this.host.style.setProperty(`--lens-zh-size`,`${t+2.5}px`),this.host.style.setProperty(`--lens-en-size`,`${t+.5}px`)}setFontFamily(e){let t={system:`-apple-system, BlinkMacSystemFont, 'SF Pro Text', system-ui, sans-serif`,sans:`Inter, ui-sans-serif, system-ui, sans-serif`,serif:`Georgia, 'Times New Roman', serif`,mono:`'SFMono-Regular', Consolas, 'Liberation Mono', monospace`}[e];this.host.style.setProperty(`--lens-font-family`,t)}setAppearance(e){let t=typeof matchMedia==`function`&&matchMedia(`(prefers-color-scheme: dark)`).matches?`rgba(242, 244, 247, 0.96)`:`rgba(20, 24, 32, 0.94)`;this.host.style.setProperty(`--lens-target-color`,e.pageTranslationUseCustomColor?e.pageTranslationTextColor:t),this.host.style.setProperty(`--lens-target-background`,e.pageTranslationUseBackground?e.pageTranslationBackgroundColor:`transparent`),this.host.style.setProperty(`--lens-target-padding`,e.pageTranslationUseBackground?`6px 8px`:`0`),this.host.style.setProperty(`--lens-target-radius`,e.pageTranslationUseBackground?`4px`:`0`),this.host.style.setProperty(`--lens-target-weight`,e.pageTranslationBold?`700`:`520`),this.host.style.setProperty(`--lens-target-style`,e.pageTranslationItalic?`italic`:`normal`),this.host.style.setProperty(`--lens-target-decoration`,e.pageTranslationUnderline?`underline`:`none`)}showAt(e,t,n){this.mount(),this.panel.style.display=`flex`,this.panel.classList.add(`is-visible`),this.body.classList.remove(`muted`,`pending-anim`),this.sourceBody.classList.remove(`muted`);let r=`sourceText`in n&&n.sourceText?n.sourceText:``,i=!!r;switch(this.sourceLabel.hidden=!i,this.sourceBody.hidden=!i,this.divider.hidden=!i,this.zhLabel.hidden=n.kind===`empty`||n.kind===`target-language`||n.kind===`unconfigured`,i?this.sourceBody.textContent=r:this.sourceBody.textContent=``,n.kind){case`ready`:this.zhLabel.textContent=this.targetLangLabel,this.body.textContent=n.text;break;case`pending`:this.zhLabel.textContent=this.targetLangLabel,this.body.classList.add(`muted`,`pending-anim`),this.body.textContent=`翻译中…`;break;case`empty`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`此处无可译文本（请移到文字上）`;break;case`target-language`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`此段已是目标语言`;break;case`error`:this.zhLabel.textContent=this.targetLangLabel,this.body.classList.add(`muted`),this.body.textContent=n.message;break;case`unconfigured`:this.sourceLabel.hidden=!0,this.sourceBody.hidden=!0,this.divider.hidden=!0,this.zhLabel.hidden=!0,this.body.classList.add(`muted`),this.body.textContent=`翻译引擎未就绪，请下载语言包或配置外部 LLM`;break}this.hint.textContent=`可选择文本复制 · Esc 关闭`;let a=`sourceRect`in n&&n.sourceRect?n.sourceRect:null;if(a){let n=`${Math.round(a.left)}|${Math.round(a.top)}|${Math.round(a.right)}|${Math.round(a.bottom)}`;n!==this.lastSourceKey&&(this.lastSourceKey=n,this.placePanel(e,t,a))}else this.lastSourceKey=``,this.placePanel(e,t,null)}placePanel(e,t,n){let r=window.innerWidth,i=window.innerHeight,a=this.panel.getBoundingClientRect(),o=Math.max(a.width,this.widthPx),s=Math.max(a.height,80),c=e+16,l=t+16;if(n&&n.width>0){let a=[];a.push({left:M(n.left,8,r-o-8),top:n.bottom+12,score:4}),a.push({left:M(n.left,8,r-o-8),top:n.top-s-12,score:3}),a.push({left:n.right+12,top:M(n.top,8,i-s-8),score:2}),a.push({left:n.left-o-12,top:M(n.top,8,i-s-8),score:1});let u=null;for(let e of a){if(!(e.left>=8&&e.top>=8&&e.left+o<=r-8&&e.top+s<=i-8))continue;let t={left:e.left,top:e.top,right:e.left+o,bottom:e.top+s},a=!(t.right<n.left-4||t.left>n.right+4||t.bottom<n.top-4||t.top>n.bottom+4),c=e.score+(a?-10:0);(!u||c>u.score)&&(u={...e,score:c})}u?(c=u.left,l=u.top):(c=M(e+16,8,r-o-8),l=M(t+16,8,i-s-8),n&&(l=M(n.bottom+12,8,i-s-8)))}else c=M(c,8,r-o-8),l=M(l,8,i-s-8);this.panel.style.left=`${c}px`,this.panel.style.top=`${l}px`}hide(){this.panel.style.display=`none`,this.panel.classList.remove(`is-visible`),this.lastSourceKey=``,this.clearHighlight()}getHost(){return this.host}highlight(e){if(this.highlightEl===e){e&&this.positionRing(e);return}if(this.highlightEl=e,!e){this.ring.style.display=`none`;return}this.positionRing(e)}reposition(){this.highlightEl&&this.positionRing(this.highlightEl)}positionRing(e){if(!e.isConnected){this.ring.style.display=`none`;return}let t=e.getBoundingClientRect(),n=t.bottom<=0||t.right<=0||t.top>=window.innerHeight||t.left>=window.innerWidth;if(t.width<1||t.height<1||n){this.ring.style.display=`none`;return}this.ring.style.display=`block`,this.ring.style.left=`${t.left-3}px`,this.ring.style.top=`${t.top-3}px`,this.ring.style.width=`${t.width+6}px`,this.ring.style.height=`${t.height+6}px`}clearHighlight(){this.highlightEl=null,this.ring.style.display=`none`}};function M(e,t,n){return Math.max(t,Math.min(n,e))}var Te=`
  :host, * { box-sizing: border-box; }

  .liquidGlass-wrapper {
    position: fixed;
    display: flex;
    overflow: hidden;
    padding: 0.85rem 1rem;
    border-radius: 14px;
    box-shadow:
      0 10px 32px rgba(15, 23, 42, 0.14),
      0 2px 8px rgba(15, 23, 42, 0.06),
      0 0 0 1px rgba(15, 23, 42, 0.06);
    transition: box-shadow 0.2s ease, transform 0.2s ease;
    font: 16px/1.55 var(--lens-font-family, Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, system-ui, sans-serif);
    -webkit-font-smoothing: antialiased;
    color: rgba(20, 24, 32, 0.94);
  }

  .liquidGlass-wrapper.is-visible {
    animation: glassIn 0.28s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }

  @keyframes glassIn {
    from { opacity: 0; transform: scale(0.96) translateY(4px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
  }

  .liquidGlass-effect {
    position: absolute;
    z-index: 0;
    inset: 0;
    border-radius: inherit;
    backdrop-filter: blur(16px) saturate(140%);
    -webkit-backdrop-filter: blur(16px) saturate(140%);
    isolation: isolate;
  }

  .liquidGlass-tint {
    position: absolute;
    z-index: 1;
    inset: 0;
    border-radius: inherit;
    background: rgba(255, 255, 255, 0.94);
  }

  .liquidGlass-shine {
    position: absolute;
    z-index: 2;
    inset: 0;
    border-radius: inherit;
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.7);
    pointer-events: none;
  }

  .liquidGlass-text {
    position: relative;
    z-index: 3;
    width: 100%;
    min-width: 0;
  }

  .panel {
    flex-direction: column;
    max-height: min(440px, 58vh);
    background: transparent;
    pointer-events: auto;
    user-select: text;
  }

  .panel .body,
  .panel .hint {
    cursor: text;
  }

  .panel .liquidGlass-text {
    overflow: auto;
    max-height: min(420px, 54vh);
  }

  .label {
    font-size: 10.5px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: rgba(91, 100, 114, 0.95);
    margin-bottom: 4px;
  }

  .label-target {
    margin-top: 2px;
  }

  .divider {
    height: 1px;
    margin: 10px 0;
    background: rgba(15, 23, 42, 0.08);
  }

  .body {
    white-space: pre-wrap;
    word-break: break-word;
    font-size: var(--lens-zh-size, 16.5px);
    line-height: 1.55;
    color: rgba(20, 24, 32, 0.94);
    font-weight: 520;
  }

  .body-source {
    font-size: var(--lens-en-size, 14.5px);
    line-height: 1.5;
    color: rgba(91, 100, 114, 0.95);
    font-weight: 450;
  }

  .body-zh,
  .body-target {
    font-size: var(--lens-zh-size, 16.5px);
    color: var(--lens-target-color, rgba(20, 24, 32, 0.94));
    background: var(--lens-target-background, transparent);
    padding: var(--lens-target-padding, 0);
    border-radius: var(--lens-target-radius, 0);
    font-weight: var(--lens-target-weight, 520);
    font-style: var(--lens-target-style, normal);
    text-decoration: var(--lens-target-decoration, none);
  }

  .body.muted {
    color: rgba(91, 100, 114, 0.95);
    font-weight: 400;
  }

  .hint {
    margin-top: 10px;
    font-size: 11.5px;
    color: rgba(139, 147, 160, 0.98);
    line-height: 1.4;
  }

  .source-outline {
    position: fixed;
    pointer-events: none;
    border-radius: 6px;
    border: 1.5px solid rgba(23, 105, 224, 0.55);
    box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.45);
    background: transparent;
  }

  @keyframes lens-pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
  }

  .pending-anim {
    animation: lens-pulse 1.1s ease-in-out infinite;
  }

  @media (prefers-color-scheme: dark) {
    .liquidGlass-wrapper {
      color: rgba(242, 244, 247, 0.96);
      box-shadow:
        0 12px 36px rgba(0, 0, 0, 0.45),
        0 0 0 1px rgba(255, 255, 255, 0.08);
    }
    .liquidGlass-tint {
      background: rgba(24, 27, 33, 0.94);
    }
    .liquidGlass-shine {
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.06);
    }
    .label { color: rgba(168, 176, 189, 0.95); }
    .divider { background: rgba(255, 255, 255, 0.08); }
    .body { color: rgba(242, 244, 247, 0.96); }
    .body-source { color: rgba(168, 176, 189, 0.95); }
    .body-zh,
    .body-target {
      color: var(--lens-target-color, rgba(242, 244, 247, 0.96));
    }
    .body.muted { color: rgba(168, 176, 189, 0.9); }
    .hint { color: rgba(123, 132, 148, 0.98); }
    .source-outline {
      border-color: rgba(77, 142, 240, 0.7);
      box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.35);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .liquidGlass-wrapper.is-visible { animation: none; }
    .pending-anim { animation: none; }
  }
`,Ee=class{byId=new Map;byUrl=new Map;maxEntries;maxTranslations;constructor(e=300,t=500){this.maxEntries=Math.max(1,e),this.maxTranslations=Math.max(1,t)}upsert(e,t,n){let r=this.byId.get(e);r||this.makeRoom();let i=this.byUrl.get(n),a={id:e,el:t,url:n,status:r?.status??(i?`ready`:`pending`),translation:r?.translation??i,error:r?.error};return a.translation&&(a.error=void 0),this.byId.set(e,a),a}get(e){return this.byId.get(e)}setPending(e){let t=this.byId.get(e);t&&(t.status=`pending`,t.error=void 0)}setTranslation(e,t){let n=this.byId.get(e);if(n){for(this.byUrl.delete(n.url),this.byUrl.set(n.url,t);this.byUrl.size>this.maxTranslations;){let e=this.byUrl.keys().next().value;if(e===void 0)break;this.byUrl.delete(e)}for(let e of this.byId.values())e.url===n.url&&(e.translation=t,e.status=`ready`,e.error=void 0)}}setError(e,t){let n=this.byId.get(e);!n||n.translation||(n.status=`error`,n.error=t)}makeRoom(){if(!(this.byId.size<this.maxEntries)){for(let[e,t]of this.byId)t.el.isConnected||this.byId.delete(e);for(;this.byId.size>=this.maxEntries;){let e=this.byId.keys().next().value;if(e===void 0)break;this.byId.delete(e)}}}};function N(e=location){return`${e.origin}${e.pathname}`}var De=class{flush;windowMs;pending=new Map;timer=null;constructor(e,t=80){this.flush=e,this.windowMs=t}enqueue(e){this.pending.set(e.id,e),this.timer===null&&(this.timer=setTimeout(()=>{this.timer=null;let e=[...this.pending.values()];this.pending.clear(),e.length&&this.flush(e)},this.windowMs))}},P=`lens-page-alignment-match`,F=`data-lens-page-alignment-source`,Oe=`[data-lens-page-translated]`,ke=`lens-translator-page-alignment-overlay`;function Ae(e){let t=[];for(let n of e.matchAll(/\p{Script=Han}|[\p{L}\p{M}\p{N}_'-]+/gu)){let e=n.index;t.push({text:n[0],start:e,end:e+n[0].length})}return t}function I(e,t){if(typeof Intl.Segmenter!=`function`)return Ae(e);let n=new Intl.Segmenter(t,{granularity:`word`}),r=[];for(let t of n.segment(e))t.isWordLike&&r.push({text:t.segment,start:t.index,end:t.index+t.segment.length});return r}function je(e,t){let n=I(e,t),r=[],i=0;for(let t=0;t<n.length;t++){let a=n[t];a.start>i&&r.push({text:e.slice(i,a.start),start:i,end:a.start,wordIndex:null}),r.push({...a,wordIndex:t}),i=a.end}return i<e.length&&r.push({text:e.slice(i),start:i,end:e.length,wordIndex:null}),r}function Me(e){return e.normalize(`NFKD`).replace(/\p{M}/gu,``).toLocaleLowerCase().replace(/[^\p{L}\p{N}]/gu,``)}function Ne(e,t){let n=Array.from({length:t.length+1},(e,t)=>t);for(let r=1;r<=e.length;r++){let i=n[0];n[0]=r;for(let a=1;a<=t.length;a++){let o=n[a];n[a]=Math.min(n[a]+1,n[a-1]+1,i+(e[r-1]===t[a-1]?0:1)),i=o}}return n[t.length]}function L(e,t){if(!e||!t)return 0;if(e===t)return 1;let n=Math.min(e.length,t.length),r=Math.max(e.length,t.length);return n>=3&&(e.includes(t)||t.includes(e))?Math.min(.9,.2+n/r):Math.max(0,1-Ne(e,t)/r)}function Pe(e,t,n){if(!e.length)return null;let r=(t+.5)/Math.max(1,n),i=Math.min(e.length-1,Math.floor(r*e.length));return{start:e[i].start,end:e[i].end}}function R(e,t,n,r,i){let a=I(e,i),o=Pe(a,n,r),s=I(t,i).map(e=>Me(e.text)).filter(Boolean);if(!a.length||!s.length)return o;let c=a.map(e=>Me(e.text)),l=(n+.5)/Math.max(1,r),u=Math.max(1,s.length-1),d=Math.min(a.length,s.length+2),f=null;for(let e=u;e<=d;e++)for(let t=0;t+e<=a.length;t++){let n=c.slice(t,t+e),r=s.reduce((e,t)=>e+Math.max(...n.map(e=>L(t,e))),0)/s.length,i=n.reduce((e,t)=>e+Math.max(...s.map(e=>L(e,t))),0)/n.length,o=r*.7+i*.3,u=(t+e/2)/a.length,d=Math.max(0,1-Math.abs(u-l)),p=o*.82+d*.18;(!f||p>f.score)&&(f={lexical:o,score:p,start:t,end:t+e})}return!f||f.lexical<.34?o:{start:a[f.start].start,end:a[f.end-1].end}}function Fe(e){let t=[],n=[],r=``,i=null,a=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),o=a.nextNode(),s=(e,i,a)=>{r+=e;for(let r=0;r<e.length;r++)t.push(i),n.push(a)};for(;o;){let e=o.data;for(let t=0;t<e.length;){let n=e.codePointAt(t),a=String.fromCodePoint(n),c=a.length;/\s/u.test(a)?r&&!i&&(i={node:o,offset:t}):(i&&=(s(` `,i,{node:i.node,offset:i.offset+1}),null),s(a,{node:o,offset:t},{node:o,offset:t+c})),t+=c}o=a.nextNode()}return{text:r,starts:t,ends:n}}function Ie(e,t,n){let r=Fe(e);if(r.text!==o(t)||n.start<0||n.end>r.text.length)return null;let i=r.starts[n.start],a=r.ends[n.end-1];if(!i||!a)return null;let s=document.createRange();return s.setStart(i.node,i.offset),s.setEnd(a.node,a.offset),s}function z(e){let t=Number.parseFloat(e);return Number.isFinite(t)?t:0}var Le=class{entries=new WeakMap;translator=new u;overlay=null;overlayHost=null;overlayWords=new Map;hovered=null;highlightedHost=null;alignmentTimer=0;active=!1;activate(){this.active||(this.active=!0,document.addEventListener(`pointermove`,this.onPointerMove,!0),window.addEventListener(`scroll`,this.onViewportChange,!0),window.addEventListener(`resize`,this.onViewportChange))}deactivate(){this.active=!1,document.removeEventListener(`pointermove`,this.onPointerMove,!0),window.removeEventListener(`scroll`,this.onViewportChange,!0),window.removeEventListener(`resize`,this.onViewportChange),this.clearInteraction(),this.entries=new WeakMap}register(e,t,n,r,i,a){let o=je(n,i);this.entries.set(e,{host:e,sourceText:t,translation:n,sourceLanguage:r,targetLanguage:i,isUi:a,segments:o,wordCount:o.filter(e=>e.wordIndex!==null).length,alignments:new Map})}unregister(e){this.entries.delete(e),(this.overlayHost===e||this.highlightedHost===e)&&this.clearInteraction()}onViewportChange=()=>this.clearInteraction();onPointerMove=e=>{let t=e.composedPath().find(e=>e instanceof Element)?.closest(Oe)??null,n=t?this.entries.get(t):void 0;if(!t||!n||n.isUi||!t.isConnected){this.clearInteraction();return}let r=this.sourceContentBottom(t),i=window.getComputedStyle(t,`::after`),a=r+z(i.marginTop);if(e.clientY<a){this.clearInteraction();return}this.ensureOverlay(n,a,i);let o=this.overlay?.getBoundingClientRect();if(!o||e.clientX<o.left||e.clientX>o.right||e.clientY<o.top||e.clientY>o.bottom){this.clearInteraction();return}let s=this.segmentAtPoint(e.clientX,e.clientY,n);if(s?.wordIndex===null||s===void 0){window.clearTimeout(this.alignmentTimer),this.clearHighlight(),this.hovered=null;return}if(this.hovered?.host===t&&this.hovered.wordIndex===s.wordIndex)return;this.hovered={host:t,wordIndex:s.wordIndex};let c=R(n.sourceText,``,s.wordIndex,n.wordCount,n.sourceLanguage);c&&this.highlight(n,c),window.clearTimeout(this.alignmentTimer);let l=n.alignments.get(s.wordIndex);if(l){this.applyAlignmentWhenCurrent(l,t,s.wordIndex,n);return}this.alignmentTimer=window.setTimeout(()=>{if(this.hovered?.host!==t||this.hovered.wordIndex!==s.wordIndex)return;let e=this.alignSegment(n,s);n.alignments.set(s.wordIndex,e),this.applyAlignmentWhenCurrent(e,t,s.wordIndex,n)},160)};applyAlignmentWhenCurrent(e,t,n,r){e.then(e=>{!e||!this.active||this.hovered?.host!==t||this.hovered.wordIndex!==n||this.highlight(r,e)})}alignSegment(e,t){let n=R(e.sourceText,``,t.wordIndex??0,e.wordCount,e.sourceLanguage);return this.translator.isSupported()?this.translator.translate(t.text,e.targetLanguage,e.sourceLanguage).then(n=>R(e.sourceText,n??``,t.wordIndex??0,e.wordCount,e.sourceLanguage)):Promise.resolve(n)}ensureOverlay(e,t,n){if(this.overlay||(this.overlay=document.createElement(`div`),this.overlay.id=ke,this.overlay.setAttribute(`data-lens-ignore`,``),document.documentElement.append(this.overlay)),this.overlayHost!==e.host){this.overlay.replaceChildren(),this.overlayWords.clear();for(let t of e.segments){if(t.wordIndex===null){this.overlay.append(document.createTextNode(t.text));continue}let e=document.createElement(`span`);e.textContent=t.text,this.overlayWords.set(t.wordIndex,e),this.overlay.append(e)}this.overlayHost=e.host}let r=e.host.getBoundingClientRect(),i=window.getComputedStyle(e.host),a=r.left+z(i.borderLeftWidth)+z(i.paddingLeft),o=Math.max(1,r.width-z(i.borderLeftWidth)-z(i.borderRightWidth)-z(i.paddingLeft)-z(i.paddingRight)),s=this.overlay.style;s.all=`initial`,s.position=`fixed`,s.zIndex=`2147483646`,s.pointerEvents=`none`,s.boxSizing=`border-box`,s.left=`${a}px`,s.top=`${t}px`,s.width=`${o}px`,s.margin=`0`,s.padding=n.padding,s.border=`0`,s.background=`transparent`,s.color=`transparent`,s.fontFamily=n.fontFamily,s.fontSize=n.fontSize,s.fontStyle=n.fontStyle,s.fontWeight=n.fontWeight,s.lineHeight=n.lineHeight,s.letterSpacing=n.letterSpacing,s.wordSpacing=n.wordSpacing,s.textAlign=n.textAlign,s.whiteSpace=n.whiteSpace,s.overflowWrap=n.overflowWrap,s.direction=n.direction}sourceContentBottom(e){let t=document.createRange();t.selectNodeContents(e);let n=[...t.getClientRects()];return t.detach(),n.reduce((e,t)=>Math.max(e,t.bottom),e.getBoundingClientRect().top)}segmentAtPoint(e,t,n){for(let r of n.segments){if(r.wordIndex===null)continue;let n=this.overlayWords.get(r.wordIndex);if(n){for(let i of n.getClientRects())if(e>=i.left-1&&e<=i.right+1&&t>=i.top&&t<=i.bottom)return r}}}highlight(e,t){let n=Ie(e.host,e.sourceText,t);if(!n)return;this.clearHighlight();let r=globalThis.CSS?.highlights,i=globalThis.Highlight;r&&i?r.set(P,new i(n)):e.host.setAttribute(F,``),this.highlightedHost=e.host}clearHighlight(){(globalThis.CSS?.highlights)?.delete(P),this.highlightedHost?.removeAttribute(F),this.highlightedHost=null}clearInteraction(){window.clearTimeout(this.alignmentTimer),this.clearHighlight(),this.hovered=null,this.overlay?.remove(),this.overlay=null,this.overlayHost=null,this.overlayWords.clear()}},B=`data-lens-page-translated`,V=`data-lens-page-translation-text`,H=`data-lens-page-ui-translation`,U=`data-lens-page-ui-stacked-translation`,W=`data-lens-page-ui-control-translation`,G=`lens-translator-page-style`,K=`lens-translator-page-status`,Re=3,ze=5e3,Be=4,Ve=8e3,He=600;function Ue(e){let t=e.pageTranslationUseCustomColor?e.pageTranslationTextColor:`inherit`,n=e.pageTranslationUseBackground?e.pageTranslationBackgroundColor:`transparent`,r=e.pageTranslationUseBackground?`0.3em 0.5em`:`0`,i=e.pageTranslationUseBackground?`4px`:`0`,a=e.pageTranslationUseCustomColor||e.pageTranslationUseBackground?`1`:`0.78`;return`
[${B}]::after {
  content: attr(${V}) !important;
  display: block !important;
  box-sizing: border-box !important;
  margin: 0.24em 0 0.1em !important;
  padding: ${r} !important;
  border: 0 !important;
  border-radius: ${i} !important;
  background: ${n} !important;
  color: ${t} !important;
  font-family: ${{system:`inherit`,sans:`Inter, ui-sans-serif, system-ui, sans-serif`,serif:`Georgia, "Times New Roman", serif`,mono:`"SFMono-Regular", Consolas, "Liberation Mono", monospace`}[e.pageTranslationFontFamily]} !important;
  font-size: ${e.pageTranslationFontSizePx}px !important;
  font-style: ${e.pageTranslationItalic?`italic`:`normal`} !important;
  font-weight: ${e.pageTranslationBold?`700`:`400`} !important;
  line-height: 1.45 !important;
  letter-spacing: 0 !important;
  overflow-wrap: anywhere !important;
  text-align: start !important;
  text-decoration: ${e.pageTranslationUnderline?`underline`:`none`} !important;
  text-transform: none !important;
  unicode-bidi: plaintext !important;
  white-space: pre-wrap !important;
  opacity: ${a} !important;
}

[${B}][${H}]::after {
  content: " · " attr(${V}) !important;
  display: inline-block !important;
  vertical-align: baseline !important;
  margin: 0 0 0 0.32em !important;
  padding: 0 !important;
  border: 0 !important;
  background: transparent !important;
  color: inherit !important;
  font-size: 0.68em !important;
  font-style: normal !important;
  font-weight: 400 !important;
  line-height: inherit !important;
  text-decoration: none !important;
  white-space: normal !important;
  opacity: 0.62 !important;
}

[${B}][${H}][${U}]::after {
  content: attr(${V}) !important;
  display: block !important;
  margin: 0.12em 0 0 !important;
  font-size: 0.58em !important;
  line-height: 1.15 !important;
  white-space: normal !important;
}

[${B}][${H}][${W}]::after {
  content: " · " attr(${V}) !important;
  display: inline-block !important;
  vertical-align: baseline !important;
  margin-left: 0.3em !important;
  font-size: 0.7em !important;
  line-height: inherit !important;
  white-space: nowrap !important;
}

::highlight(${P}) {
  background: rgb(250 204 21 / 52%);
  color: inherit;
  text-decoration: underline;
  text-decoration-color: rgb(202 138 4 / 80%);
  text-decoration-thickness: 2px;
}

[${F}] {
  background-color: rgb(250 204 21 / 22%) !important;
}

#${K} {
  position: fixed !important;
  z-index: 2147483647 !important;
  top: 16px !important;
  right: 16px !important;
  max-width: min(360px, calc(100vw - 32px)) !important;
  padding: 9px 12px !important;
  border: 1px solid rgb(15 23 42 / 14%) !important;
  border-radius: 7px !important;
  background: rgb(255 255 255 / 96%) !important;
  box-shadow: 0 8px 24px rgb(15 23 42 / 16%) !important;
  color: #172033 !important;
  font: 500 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif !important;
  letter-spacing: 0 !important;
}

#${K}[data-error="true"] {
  border-color: rgb(185 28 28 / 24%) !important;
  color: #991b1b !important;
}

@media (prefers-color-scheme: dark) {
  #${K} {
    border-color: rgb(255 255 255 / 16%) !important;
    background: rgb(24 24 27 / 96%) !important;
    color: #f4f4f5 !important;
  }
  #${K}[data-error="true"] { color: #fca5a5 !important; }
}
`}function We(e){return!!(e&&typeof e==`object`&&`id`in e&&typeof e.id==`string`&&`translation`in e&&typeof e.translation==`string`)}function Ge(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-batch-result`||typeof e.ok!=`boolean`||`translations`in e&&e.translations!==void 0&&(!Array.isArray(e.translations)||!e.translations.every(We))?!1:e.ok?`translations`in e&&Array.isArray(e.translations):`error`in e&&typeof e.error==`string`}function Ke(e){let t=[...e].sort((e,t)=>e.el===t.el?0:e.el.compareDocumentPosition(t.el)&4?-1:1),n=[],r=[];for(let e of t)y(e.el,0)?n.push(e):r.push(e);let i=[...n,...r],a=new Map;for(let e of i){let t=o(e.text),n=a.get(t);if(n){n.blocks.push(e);continue}a.set(t,{representative:{id:e.id,tag:e.tag,text:t},blocks:[e]})}return[...a.values()]}var qe=`nav, [role="navigation"], [role="banner"], [role="menu"], [role="tablist"], [role="search"], [role="toolbar"]`,Je=`button, [role="button"], [role="tab"], [role="menuitem"], [role="menuitemradio"], [role="option"]`,Ye=`[role="grid"], [role="treegrid"], [class*="ContributionCalendar"], .js-calendar-graph, .contrib-legend, [class*="ContributionCalendar"] [data-level], .js-calendar-graph [data-level]`,Xe=/^(?:mon|tue|tues|wed|weds|thu|thur|thurs|fri|sat|sun|monday|tuesday|wednesday|thursday|friday|saturday|sunday|jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|january|february|march|april|june|july|august|september|october|november|december)$/i;function Ze(e){return Xe.test(o(e))}function q(e){return!!(T(e.el)||e.el.closest(qe)||e.el.closest(Je))}function Qe(e){if(e.el.closest(`button, [role="button"]`))return!0;let t=`${e.el.getAttribute(`class`)??``} ${e.el.getAttribute(`data-testid`)??``}`;return/(?:^|[\s_-])(?:button|btn|submit)(?:$|[\s_-])/iu.test(t)}function $e(e){if(!q(e))return e.el;let t=o(e.text),n=e.el;for(let r of e.el.querySelectorAll(`*`)){let e=r.tagName.toLowerCase();e===`svg`||e===`path`||e===`img`||o(x(r))===t&&(n=r)}return n}function et(e,t){let{el:n,text:r}=e;if(n.closest(`time`)||n.closest(Ye)||Ze(r))return!1;let i=q(e);if(i&&/@[\p{L}\p{N}_-]+/u.test(r)||!l(r,i?Math.min(2,t):t))return!1;if(i)return!0;if(T(n))return!1;let a=n.closest(`a, [role="link"]`);return!(a&&r.length<=48&&o(x(a))===o(r))}var tt=class{browserTranslator;active=!1;generation=0;statusTimer=0;mutationTimer=0;initialRetryTimer=0;activationDeadline=0;processingGeneration=0;rescanRequested=!1;observer=null;observedRoots=new WeakSet;currentSettings=null;dirtyRoots=new Set;translatedHosts=new Set;sourceHosts=new Map;attemptedTextByHost=new WeakMap;sourceBlockByHost=new WeakMap;volatileHosts=new WeakSet;hostChurn=new WeakMap;translationCache=new Map;processedCount=0;translatedCount=0;totalCount=0;alignment=new Le;constructor(e){this.browserTranslator=e}isActive(){return this.active}async toggle(e,t){if(this.active){this.deactivate();return}await this.activate(e,t)}deactivate(){this.active=!1,this.generation++,this.observer?.disconnect(),this.observer=null,this.alignment.deactivate(),this.observedRoots=new WeakSet,window.clearTimeout(this.statusTimer),window.clearTimeout(this.mutationTimer),window.clearTimeout(this.initialRetryTimer);for(let e of this.translatedHosts)e.removeAttribute(B),e.removeAttribute(V),e.removeAttribute(H),e.removeAttribute(U),e.removeAttribute(W);for(let[e,t]of this.sourceHosts)t===null?e.removeAttribute(f):e.setAttribute(f,t);this.translatedHosts.clear(),this.sourceHosts.clear(),this.attemptedTextByHost=new WeakMap,this.sourceBlockByHost=new WeakMap,this.volatileHosts=new WeakSet,this.hostChurn=new WeakMap,this.translationCache.clear(),this.dirtyRoots.clear(),this.currentSettings=null,this.processingGeneration=0,this.rescanRequested=!1,document.getElementById(K)?.remove(),document.getElementById(G)?.remove()}restyle(e){this.active&&(this.currentSettings=e,this.ensureStyles(e))}async activate(e,t){window.clearTimeout(this.statusTimer),this.active=!0;let n=++this.generation;if(this.currentSettings=e,this.ensureStyles(e),e.pageTranslationEngine===`external`&&!t){this.failActivation(`整页翻译需要先配置外部 API`);return}if(e.pageTranslationEngine===`browser`&&!this.browserTranslator.isSupported()){this.failActivation(`当前浏览器不支持 Chrome 内置翻译`);return}this.alignment.activate(),this.startObserving(),this.activationDeadline=Date.now()+Ve,await this.scanAndTranslate(e,n,!0)}async scanAndTranslate(e,t,n=!1){if(this.isCurrent(t)){if(this.processingGeneration===t){this.rescanRequested=!0;return}if(this.processingGeneration===0){this.processingGeneration=t,window.clearTimeout(this.statusTimer);try{let r=n?[document]:[...this.dirtyRoots];this.dirtyRoots.clear(),this.observePageRoots(r),this.cleanupDisconnectedHosts(),n&&this.showStatus(`正在分析页面文本…`);let i=new Map;for(let t of r)if(!(t!==document&&t instanceof Node&&!t.isConnected))for(let n of ve(e.minTextLength,t))i.set(n.el,n);let a=Ke([...i.values()].filter(t=>this.volatileHosts.has(t.el)||!et(t,e.minTextLength)||s(t.text,e.targetLang)||this.translatedHosts.has(t.el)?!1:this.attemptedTextByHost.get(t.el)!==t.text));if(this.totalCount=a.reduce((e,t)=>e+t.blocks.length,0),this.processedCount=0,this.translatedCount=0,!a.length){n&&this.translatedHosts.size===0?Date.now()<this.activationDeadline?(this.showStatus(`正在等待页面内容加载…`),this.scheduleInitialRetry(t)):this.failActivation(`当前页面没有可翻译文本`):document.getElementById(K)?.remove();return}n||this.showStatus(`检测到新内容，正在翻译…`);for(let e of a)for(let t of e.blocks)this.attemptedTextByHost.set(t.el,t.text);this.updateProgress();let o=[];for(let t of a){let n=this.translationCache.get(t.representative.text);n?(this.renderGroup(t,n,e),this.processedCount+=t.blocks.length):o.push(t)}if(this.updateProgress(),o.length&&(e.pageTranslationEngine===`browser`?await this.translateWithBrowser(o,e,t):await this.translateWithExternal(o,e,t)),!this.isCurrent(t))return;if(n&&this.translatedCount===0&&this.translatedHosts.size===0){this.failActivation(`整页翻译失败，当前语言对可能不可用`);return}let c=this.totalCount-this.translatedCount;this.showStatus(c>0?`翻译完成：${this.translatedCount} 段成功，${c} 段失败`:`翻译完成：${this.translatedCount} 段`,c>0),this.scheduleStatusRemoval()}catch(e){if(!this.isCurrent(t))return;let r=e instanceof Error?e.message:String(e);n&&this.translatedHosts.size===0?this.failActivation(r):(this.showStatus(`整页翻译部分失败：${r}`,!0),this.scheduleStatusRemoval(5e3))}finally{if(this.processingGeneration!==t)return;this.processingGeneration=0,this.rescanRequested&&this.isCurrent(t)&&(this.rescanRequested=!1,this.scheduleScan(0))}}}}async translateWithBrowser(e,t,n){let r=await this.browserTranslator.prepare(t.sourceLang,t.targetLang);if(this.isCurrent(n)){if(!r)throw Error(`Chrome 内置翻译不支持当前语言对`);for(let r of e){if(!this.isCurrent(n))return;let e=await this.browserTranslator.translate(r.representative.text,t.sourceLang,t.targetLang);if(!this.isCurrent(n))return;e&&this.renderGroup(r,e,t),this.processedCount+=r.blocks.length,this.updateProgress()}}}async translateWithExternal(e,t,n){let r=new Map(e.map(e=>[e.representative.id,e])),i=a(e.map(e=>e.representative),t.batchCharLimit,30),o=N(),s=null;if(await this.runWithConcurrency(i,Be,async e=>{if(this.isCurrent(n)){try{let i=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:o,blocks:e});if(!this.isCurrent(n))return;if(!Ge(i))throw Error(`翻译服务未返回有效结果`);for(let e of i.translations??[]){let n=r.get(e.id);n&&this.renderGroup(n,e.translation,t)}i.ok||s===null&&(s=i.error)}catch(e){s===null&&(s=e instanceof Error?e.message:String(e))}if(this.isCurrent(n)){for(let t of e){let e=r.get(t.id);e&&(this.processedCount+=e.blocks.length)}this.updateProgress()}}}),this.isCurrent(n)&&s!==null&&e.some(e=>!this.translationCache.has(e.representative.text)))throw Error(s)}async runWithConcurrency(e,t,n){let r=e.slice(),i=async()=>{let e=r.shift();e!==void 0&&(await n(e),await i())},a=[];for(let n=0;n<Math.min(t,e.length);n++)a.push(i());await Promise.all(a)}renderGroup(e,t,n){this.translationCache.set(e.representative.text,t);for(let r of e.blocks){if(!r.el.isConnected)continue;let e=q(r),i=e?$e(r):r.el;if(!this.translatedHosts.has(i)){if(this.sourceHosts.has(i)||(this.sourceHosts.set(i,i.getAttribute(f)),i.setAttribute(f,r.text)),i.setAttribute(B,``),i.setAttribute(V,t),e)if(i.setAttribute(H,``),Qe(r))i.setAttribute(W,``);else{let e=window.getComputedStyle(i).display;!e.includes(`flex`)&&!e.includes(`grid`)&&i.setAttribute(U,``)}this.translatedHosts.add(i),this.sourceBlockByHost.set(i,r.el),this.alignment.register(i,r.text,t,n.sourceLang,n.targetLang,q(r)),this.translatedCount++}}}startObserving(){this.observer?.disconnect(),this.observedRoots=new WeakSet,this.observer=new MutationObserver(e=>this.onMutations(e)),this.observePageRoots([document])}observePageRoots(e){if(this.observer)for(let t of e)for(let e of A(t)){let t=e===document?document.documentElement:e;this.observedRoots.has(t)||(this.observer.observe(t,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:[`class`,`style`,`hidden`,`aria-hidden`,`open`]}),this.observedRoots.add(t))}}onMutations(e){let t=!1;for(let n of e){let e=n.target.nodeType===1?n.target:n.target.parentElement;if(!e||e.closest(`[data-lens-ignore]`))continue;if(n.type===`childList`){let e=[...n.addedNodes,...n.removedNodes];if(e.length>0&&e.every(e=>this.isOwnNode(e)))continue}let r=e.closest(`[${B}]`);if(!(r&&n.type===`attributes`)){if(r){let e=r.getAttribute(`data-lens-translator-source`)??``;if(o(x(r))===e)continue;if(this.markChurnAndMaybeVolatile(r)){this.invalidateHost(r);continue}this.invalidateHost(r),this.dirtyRoots.add(r.parentElement??r),t=!0;continue}this.dirtyRoots.add(e.parentElement??e),t=!0}}t&&this.scheduleScan()}markChurnAndMaybeVolatile(e){let t=Date.now(),n=this.hostChurn.get(e);if(!n||t-n.since>ze)return this.hostChurn.set(e,{count:1,since:t}),!1;if(n.count++,n.count<Re)return!1;this.volatileHosts.add(e);let r=this.sourceBlockByHost.get(e);return r&&this.volatileHosts.add(r),!0}isOwnNode(e){return e.nodeType===1&&(e.hasAttribute(`data-lens-ignore`)||e.id===G||e.id===K)}invalidateHost(e){this.alignment.unregister(e),e.removeAttribute(B),e.removeAttribute(V),e.removeAttribute(H),e.removeAttribute(U),e.removeAttribute(W),this.translatedHosts.delete(e);let t=this.sourceHosts.get(e);t===null?e.removeAttribute(f):t!==void 0&&e.setAttribute(f,t),this.sourceHosts.delete(e),this.attemptedTextByHost.delete(this.sourceBlockByHost.get(e)??e),this.sourceBlockByHost.delete(e)}cleanupDisconnectedHosts(){for(let e of this.translatedHosts)e.isConnected||this.invalidateHost(e)}scheduleScan(e=250){window.clearTimeout(this.mutationTimer),this.mutationTimer=window.setTimeout(()=>{!this.active||!this.currentSettings||this.scanAndTranslate(this.currentSettings,this.generation)},e)}scheduleInitialRetry(e){window.clearTimeout(this.initialRetryTimer),this.initialRetryTimer=window.setTimeout(()=>{!this.isCurrent(e)||!this.currentSettings||this.scanAndTranslate(this.currentSettings,e,!0)},He)}isCurrent(e){return this.active&&e===this.generation}ensureStyles(e){let t=document.getElementById(G);t||(t=document.createElement(`style`),t.id=G,t.setAttribute(`data-lens-ignore`,``),(document.head??document.documentElement).append(t)),t.textContent=Ue(e)}showStatus(e,t=!1){let n=document.getElementById(K);n||(n=document.createElement(`div`),n.id=K,n.setAttribute(`data-lens-ignore`,``),n.setAttribute(`role`,`status`),n.setAttribute(`aria-live`,`polite`),document.documentElement.append(n)),n.dataset.error=t?`true`:`false`,n.textContent=e}updateProgress(){this.showStatus(`整页翻译 ${Math.min(this.processedCount,this.totalCount)}/${this.totalCount}`)}failActivation(e){this.active=!1,window.clearTimeout(this.initialRetryTimer),this.observer?.disconnect(),this.observer=null,this.alignment.deactivate(),this.showStatus(e,!0),this.scheduleStatusRemoval(5e3)}scheduleStatusRemoval(e=3e3){window.clearTimeout(this.statusTimer),this.statusTimer=window.setTimeout(()=>{document.getElementById(K)?.remove()},e)}},nt=new Set(`a.an.and.are.as.at.be.by.for.from.has.have.in.is.it.not.of.on.or.that.the.this.to.was.we.will.with.you`.split(`.`));function J(e){return e.trim().toLocaleLowerCase().split(/[-_]/u)[0]}function rt(e){let t=e.match(/\p{L}/gu)??[];if(t.length<40||(e.match(/[a-z]/giu)?.length??0)/t.length<.78)return!1;let n=e.toLocaleLowerCase().match(/[a-z]+(?:'[a-z]+)?/gu)??[];return n.length<12?!1:n.reduce((e,t)=>e+ +!!nt.has(t),0)>=Math.max(2,Math.ceil(n.length*.035))}function it(e,t,n){let r=J(e),i=J(t);return i?i===r:r===`en`&&rt(n)}function at(e,t=document){return it(e,t.documentElement.lang||t.querySelector(`meta[http-equiv="content-language" i]`)?.content||``,(t.body?.innerText||t.body?.textContent||``).slice(0,12e3))}var ot=class{host;root;panel;sourceLabel;sourceBody;targetLabel;targetBody;bound=!1;enabled=!1;paused=!1;sourceLang=`en`;targetLang=`zh`;requestId=0;lastText=``;translate;constructor(e){this.translate=e,this.host=document.createElement(`div`),this.host.id=`lens-translator-selection-root`,this.host.setAttribute(`data-lens-ignore`,``),Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,pointerEvents:`none`,zIndex:`2147483645`}),this.root=this.host.attachShadow({mode:`closed`});let t=document.createElement(`style`);t.textContent=st,this.panel=document.createElement(`div`),this.panel.className=`panel`,this.panel.style.display=`none`,this.panel.addEventListener(`mousedown`,e=>e.stopPropagation()),this.sourceLabel=document.createElement(`div`),this.sourceLabel.className=`label`,this.sourceBody=document.createElement(`div`),this.sourceBody.className=`source`,this.targetLabel=document.createElement(`div`),this.targetLabel.className=`label target-label`,this.targetBody=document.createElement(`div`),this.targetBody.className=`target`,this.panel.append(this.sourceLabel,this.sourceBody,this.targetLabel,this.targetBody),this.root.append(t,this.panel)}bind(){this.bound||(this.bound=!0,document.addEventListener(`selectionchange`,this.onSelectionChange),document.addEventListener(`mousedown`,this.onMouseDown,!0),window.addEventListener(`scroll`,this.hide,!0),window.addEventListener(`resize`,this.hide))}setEnabled(e){this.enabled=e,e||this.hide()}setPaused(e){this.paused=e,e&&this.hide()}setLanguages(e,t){this.sourceLang=e,this.targetLang=t,this.sourceLabel.textContent=r(e),this.targetLabel.textContent=r(t)}onMouseDown=e=>{let t=e.composedPath();t.includes(this.host)||t.includes(this.panel)||this.panel.style.display!==`none`&&!this.getSelectedText()&&this.hide()};onSelectionChange=()=>{if(!this.enabled||this.paused){this.hide();return}window.setTimeout(()=>void this.refreshFromSelection(),0)};getSelectedText(){let e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return``;let t=o(e.toString());if(t.length<1||t.length>2e3)return``;let n=e.anchorNode;if(n&&X(n instanceof Element?n:n.parentElement))return``;let r=e.focusNode;return r&&X(r instanceof Element?r:r.parentElement)||Y(document.activeElement)?``:t}async refreshFromSelection(){let e=this.getSelectedText();if(!e){this.hide();return}if(e===this.lastText&&this.panel.style.display!==`none`)return;this.lastText=e;let t=window.getSelection();if(!t||t.rangeCount===0){this.hide();return}let n=t.getRangeAt(0).getBoundingClientRect();if(n.width<1&&n.height<1){this.hide();return}if(this.mount(),this.sourceLabel.textContent=r(this.sourceLang),this.targetLabel.textContent=r(this.targetLang),this.sourceBody.textContent=e,this.panel.style.display=`block`,s(e,this.targetLang)){this.targetBody.classList.add(`muted`),this.targetBody.textContent=`已是目标语言`,this.place(n);return}this.targetBody.classList.add(`muted`,`pending`),this.targetBody.textContent=`翻译中…`,this.place(n);let i=++this.requestId;try{let t=await this.translate(e);if(i!==this.requestId||this.getSelectedText()!==e)return;if(!t){this.targetBody.textContent=`翻译失败`;return}this.targetBody.classList.remove(`muted`,`pending`),this.targetBody.textContent=t,this.place(n)}catch(e){if(i!==this.requestId)return;this.targetBody.classList.add(`muted`),this.targetBody.classList.remove(`pending`),this.targetBody.textContent=e instanceof Error?e.message:`翻译失败`}}place(e){let t=window.innerWidth,n=window.innerHeight,r=this.panel.getBoundingClientRect(),i=Math.max(r.width,220),a=Math.max(r.height,72),o=Math.min(Math.max(8,e.left),t-i-8),s=e.bottom+10;s+a>n-8&&(s=Math.max(8,e.top-a-10)),this.panel.style.left=`${o}px`,this.panel.style.top=`${s}px`}mount(){this.host.isConnected||document.documentElement.append(this.host)}hide=()=>{this.requestId++,this.lastText=``,this.panel.style.display=`none`,this.targetBody.classList.remove(`muted`,`pending`)}};function Y(e){if(!e||!(e instanceof HTMLElement))return!1;if(e.isContentEditable)return!0;let t=e.tagName;return t===`INPUT`||t===`TEXTAREA`||t===`SELECT`||!!e.closest(`input, textarea, select, [contenteditable=""], [contenteditable="true"]`)}function X(e){return e?Y(e)?!0:!!e.closest(`#lens-translator-root, #lens-translator-bubble-root, #lens-translator-selection-root, #lens-translator-setup-prompt, [data-lens-ignore]`):!1}var st=`
  :host, * { box-sizing: border-box; }
  .panel {
    position: fixed;
    min-width: 180px;
    max-width: min(360px, calc(100vw - 16px));
    max-height: min(280px, 42vh);
    overflow: auto;
    padding: 10px 12px;
    border-radius: 12px;
    background: rgb(255 255 255 / 96%);
    box-shadow:
      0 12px 32px rgb(15 23 42 / 18%),
      0 0 0 1px rgb(15 23 42 / 8%);
    color: #0f172a;
    font: 13px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif;
    pointer-events: auto;
    user-select: text;
  }
  .label {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.05em;
    color: #94a3b8;
    margin-bottom: 2px;
  }
  .target-label { margin-top: 8px; }
  .source {
    color: #64748b;
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 12.5px;
  }
  .target {
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 14px;
    font-weight: 520;
    color: #0f172a;
  }
  .target.muted { color: #64748b; font-weight: 400; }
  .target.pending { animation: pulse 1.1s ease-in-out infinite; }
  @keyframes pulse {
    0%, 100% { opacity: 0.55; }
    50% { opacity: 1; }
  }
  @media (prefers-color-scheme: dark) {
    .panel {
      background: rgb(24 24 27 / 96%);
      color: #f4f4f5;
      box-shadow: 0 12px 32px rgb(0 0 0 / 45%), 0 0 0 1px rgb(255 255 255 / 8%);
    }
    .source { color: #a1a1aa; }
    .target { color: #fafafa; }
    .target.muted { color: #a1a1aa; }
  }
  @media (prefers-reduced-motion: reduce) {
    .target.pending { animation: none; }
  }
`,ct=class{host=null;root=null;show(e,t,n){this.dismiss(),this.host=document.createElement(`div`),this.host.id=`lens-translator-setup-prompt`,this.host.setAttribute(`data-lens-ignore`,``),Object.assign(this.host.style,{all:`initial`,position:`fixed`,inset:`0`,zIndex:`2147483647`,pointerEvents:`auto`}),this.root=this.host.attachShadow({mode:`closed`});let r=i(t.sourceLang,t.targetLang),a=lt(e,r),o=document.createElement(`style`);o.textContent=ut;let s=document.createElement(`div`);s.className=`backdrop`,s.addEventListener(`click`,e=>{e.target===s&&(n.onDismiss?.(),this.dismiss())});let c=document.createElement(`div`);c.className=`card`,c.setAttribute(`role`,`dialog`),c.setAttribute(`aria-modal`,`true`),c.setAttribute(`aria-labelledby`,`lens-setup-title`);let l=document.createElement(`h2`);l.id=`lens-setup-title`,l.textContent=a.title;let u=document.createElement(`p`);u.className=`body`,u.textContent=a.body;let d=document.createElement(`div`);d.className=`pair`,d.textContent=r;let f=document.createElement(`div`);if(f.className=`actions`,a.primary===`download`&&n.onDownload){let e=document.createElement(`button`);e.type=`button`,e.className=`btn primary`,e.textContent=`下载语言包`,e.addEventListener(`click`,()=>{Promise.resolve(n.onDownload?.())}),f.append(e)}if(n.onOpenLlmSetup){let e=document.createElement(`button`);e.type=`button`,e.className=a.primary===`llm`?`btn primary`:`btn`,e.textContent=`配置外部 LLM`,e.addEventListener(`click`,()=>{Promise.resolve(n.onOpenLlmSetup?.()),this.dismiss()}),f.append(e)}if(n.onOpenOnboarding){let e=document.createElement(`button`);e.type=`button`,e.className=`btn`,e.textContent=`打开设置向导`,e.addEventListener(`click`,()=>{Promise.resolve(n.onOpenOnboarding?.()),this.dismiss()}),f.append(e)}let p=document.createElement(`button`);p.type=`button`,p.className=`btn ghost`,p.textContent=`稍后`,p.addEventListener(`click`,()=>{n.onDismiss?.(),this.dismiss()}),f.append(p),c.append(l,u,d,f),s.append(c),this.root.append(o,s),document.documentElement.append(this.host),window.addEventListener(`keydown`,this.onKeyDown,!0)}setStatus(e,t=!1){if(!this.root)return;let n=this.root.querySelector(`.status`);n||(n=document.createElement(`p`),n.className=`status`,this.root.querySelector(`.card`)?.append(n)),n.textContent=e,n.dataset.error=t?`true`:`false`}dismiss(){window.removeEventListener(`keydown`,this.onKeyDown,!0),this.host?.remove(),this.host=null,this.root=null}isOpen(){return!!this.host?.isConnected}onKeyDown=e=>{e.key===`Escape`&&this.isOpen()&&(e.preventDefault(),e.stopPropagation(),this.dismiss())}};function lt(e,t){return e.kind===`browser-unsupported`?{title:`当前浏览器不支持内置翻译`,body:`需要桌面版 Chrome 138+ 的 Translator API，或改用外部 LLM 完成翻译。`,primary:`llm`}:e.kind===`external-unconfigured`?{title:`尚未配置外部翻译服务`,body:`当前选择了外部 LLM。请填写 Base URL、API Key 与模型，或改回 Chrome 内置翻译。`,primary:`llm`}:e.availability===`downloadable`||e.availability===`downloading`?{title:`需要下载语言包`,body:`语言对 ${t} 的 Chrome 语言包尚未就绪。下载后即可离线翻译；也可以改用外部 LLM。`,primary:`download`}:e.availability===`unavailable`?{title:`当前语言对不可用`,body:`Chrome 内置翻译不支持 ${t}。请更换语言，或切换到外部 LLM。`,primary:`llm`}:{title:`翻译尚未就绪`,body:`请检查语言包状态，或在设置中切换到外部 LLM。`,primary:`none`}}var ut=`
  :host { all: initial; }
  * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
  .backdrop {
    position: fixed;
    inset: 0;
    display: grid;
    place-items: center;
    padding: 20px;
    background: rgb(15 23 42 / 42%);
    backdrop-filter: blur(4px);
  }
  .card {
    width: min(420px, 100%);
    padding: 22px 22px 18px;
    border-radius: 16px;
    background: #fff;
    box-shadow: 0 24px 60px rgb(15 23 42 / 28%);
    color: #0f172a;
  }
  h2 {
    margin: 0 0 10px;
    font-size: 17px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }
  .body {
    margin: 0 0 12px;
    font-size: 13.5px;
    line-height: 1.55;
    color: #475569;
  }
  .pair {
    display: inline-flex;
    margin-bottom: 16px;
    padding: 5px 10px;
    border-radius: 999px;
    background: #eff6ff;
    color: #1d4ed8;
    font-size: 12px;
    font-weight: 600;
  }
  .actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  .btn {
    appearance: none;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    background: #f8fafc;
    color: #0f172a;
    font-size: 13px;
    font-weight: 600;
    padding: 9px 12px;
    cursor: pointer;
  }
  .btn:hover { background: #f1f5f9; }
  .btn.primary {
    border-color: #2563eb;
    background: #2563eb;
    color: #fff;
  }
  .btn.primary:hover { background: #1d4ed8; }
  .btn.ghost {
    border-color: transparent;
    background: transparent;
    color: #64748b;
  }
  .status {
    margin: 12px 0 0;
    font-size: 12.5px;
    color: #0369a1;
  }
  .status[data-error="true"] { color: #b91c1c; }
  @media (prefers-color-scheme: dark) {
    .card { background: #18181b; color: #f4f4f5; }
    .body { color: #a1a1aa; }
    .pair { background: #172554; color: #93c5fd; }
    .btn { border-color: #3f3f46; background: #27272a; color: #f4f4f5; }
    .btn:hover { background: #3f3f46; }
    .btn.ghost { color: #a1a1aa; }
  }
`,Z=320;function dt(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-image-result`||typeof e.ok!=`boolean`?!1:e.ok?`translation`in e&&typeof e.translation==`string`:`error`in e&&typeof e.error==`string`}function ft(e){return!e||typeof e!=`object`?!1:`id`in e&&typeof e.id==`string`&&`translation`in e&&typeof e.translation==`string`}function Q(e){return!e||typeof e!=`object`||!(`type`in e)||!(`ok`in e)||e.type!==`translate-batch-result`||typeof e.ok!=`boolean`?!1:e.ok?`translations`in e&&Array.isArray(e.translations)&&e.translations.every(ft):!(`error`in e)||typeof e.error!=`string`?!1:!(`translations`in e)||e.translations===void 0||Array.isArray(e.translations)&&e.translations.every(ft)}function pt(e){return!e||typeof e!=`object`||!(`type`in e)||e.type!==`settings`||!(`configured`in e)||typeof e.configured!=`boolean`||!(`settings`in e)||!e.settings||typeof e.settings!=`object`||!(`paused`in e)||typeof e.paused!=`boolean`?!1:`apiKey`in e.settings&&e.settings.apiKey===``}function mt(e){return!e||typeof e!=`object`||!(`type`in e)||e.type!==`background-error`?null:`error`in e&&typeof e.error==`string`?e.error:null}function ht(e,t){return[e.translationEngine!==`external`||t,e.sourceLang,e.targetLang,e.translationEngine,e.minTextLength,e.batchCharLimit].join(`\0`)}function gt(e,t){return[e.pageTranslationEngine!==`external`||t,e.sourceLang,e.targetLang,e.pageTranslationEngine,e.minTextLength,e.batchCharLimit].join(`\0`)}function _t(e){return[e.pageTranslationFontFamily,e.pageTranslationFontSizePx,e.pageTranslationUseCustomColor,e.pageTranslationTextColor,e.pageTranslationUseBackground,e.pageTranslationBackgroundColor,e.pageTranslationBold,e.pageTranslationItalic,e.pageTranslationUnderline].join(`\0`)}var vt=class{registry=new Ce;imageRegistry=new Ee;browserTranslator=new u;pageTranslator=new tt(this.browserTranslator);lens;batcher;setupPrompt=new ct;selectionTranslator;settings=t;configured=!1;pausedHere=!1;lensSettingsSig=``;pageSettingsSig=``;pageStyleSig=``;autoPageStartPending=!1;settingsGeneration=0;translationGeneration=0;lensActive=!1;lensSticky=!1;hotkeyDownAt=0;hotkeyHeld=!1;lastMouse={x:0,y:0};lastSelectionSetupPromptAt=0;inflight=new Map;inflightTexts=new Map;imageInflight=new Set;pointerFrame=0;stickyFrame=0;listenersBound=!1;autoScanMo=null;onBubbleVisibility=null;constructor(e=340){this.lens=new we(e),this.batcher=new De(e=>this.translateSpecific(e)),this.selectionTranslator=new ot(e=>this.translateSelectionText(e))}setBubbleVisibilityHandler(e){this.onBubbleVisibility=e,e(this.settings.showFloatingBubble!==!1&&!this.pausedHere)}bindListeners(){if(this.listenersBound)return;this.listenersBound=!0,this.selectionTranslator.bind(),window.addEventListener(`keydown`,this.onKeyDown,!0),window.addEventListener(`keyup`,this.onKeyUp,!0),window.addEventListener(`blur`,this.onBlur),window.addEventListener(`mousemove`,this.onMouseMove,!0);let e=xt(()=>{this.settings.autoTranslate&&this.scanVisibleAndTranslate()},300);window.addEventListener(`scroll`,e,!0),window.addEventListener(`resize`,e),window.addEventListener(`scroll`,this.onStickyReposition,!0),window.addEventListener(`resize`,this.onStickyReposition),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e.settings&&this.refreshSettings()}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(t.id!==chrome.runtime.id||!e||typeof e!=`object`)return!1;let r=e.type;return r===`toggle-page-translation`?(this.togglePageTranslation().then(n,e=>{n($(e))}),!0):r===`toggle-lens`?(this.toggleStickyLensAsync().then(n,e=>{n($(e))}),!0):r===`bubble-control`&&yt(e)?(this.handleBubbleControl(e).then(n,e=>{n($(e))}),!0):!1})}async refreshSettings(){try{let t=await chrome.runtime.sendMessage({type:`get-settings`}),n=mt(t);if(n)throw Error(n);if(!pt(t))throw Error(`Invalid settings response`);let i=this.settings;this.configured=t.configured,this.settings=e(t.settings),this.settingsGeneration++,this.pausedHere=t.paused,this.pausedHere&&(this.lensActive&&this.deactivateLens(),this.pageTranslator.isActive()&&this.pageTranslator.deactivate(),this.selectionTranslator.hide()),this.lens.setWidth(this.settings.lensWidthPx),this.lens.setFontSize(this.settings.pageTranslationFontSizePx),this.lens.setFontFamily(this.settings.pageTranslationFontFamily),this.lens.setAppearance(this.settings),this.lens.setLanguageLabels(r(this.settings.sourceLang),r(this.settings.targetLang)),this.selectionTranslator.setPaused(this.pausedHere),this.selectionTranslator.setEnabled(this.settings.selectionTranslate),this.selectionTranslator.setLanguages(this.settings.sourceLang,this.settings.targetLang),this.onBubbleVisibility?.(this.settings.showFloatingBubble&&!this.pausedHere),this.syncAutoScanObserver();let a=ht(this.settings,this.configured),o=a!==this.lensSettingsSig,s=this.lensSettingsSig;this.lensSettingsSig=a;let c=gt(this.settings,this.configured),l=c!==this.pageSettingsSig,u=this.pageSettingsSig;this.pageSettingsSig=c;let d=_t(this.settings),f=d!==this.pageStyleSig;this.pageStyleSig=d,u!==``&&l&&this.pageTranslator.isActive()?this.pageTranslator.deactivate():f&&this.pageTranslator.isActive()&&this.pageTranslator.restyle(this.settings),s!==``&&o&&(this.translationGeneration++,this.inflight.clear(),this.inflightTexts.clear(),this.registry.resetTranslationsToPending()),this.canTranslateText()&&this.settings.autoTranslate&&(o||!i.autoTranslate)&&this.scanVisibleAndTranslate(),this.settings.autoPageTranslation&&await this.maybeStartPageTranslation()}catch(e){console.warn(`[Lens Translator] settings refresh failed`,e instanceof Error?e.message:String(e))}}ensureMouseSeed(){this.lastMouse.x===0&&this.lastMouse.y===0&&(this.lastMouse={x:Math.round(window.innerWidth/2),y:Math.round(window.innerHeight/2)})}async togglePageTranslation(){if(this.pageTranslator.isActive())return this.pageTranslator.deactivate(),{ok:!0};let e=await this.ensureEngineReady(`page`);return e.ok?(this.lensActive&&this.deactivateLens(),await this.pageTranslator.toggle(this.settings,this.configured),{ok:!0}):e}async toggleStickyLensAsync(){if(this.lensActive)return this.deactivateLens(),{ok:!0,lensActive:!1};if(this.pausedHere)return{ok:!1,error:`当前网站已暂停翻译`};let e=await this.ensureEngineReady(`lens`);return e.ok?(this.activateStickyLens(),{ok:!0,lensActive:!0}):e}activateStickyLens(){this.lensActive=!0,this.lensSticky=!0,this.hotkeyHeld=!1,this.ensureMouseSeed(),this.settings.translationEngine===`browser`&&this.browserTranslator.prepare(this.settings.sourceLang,this.settings.targetLang),this.updateLens()}activateTemporaryLens(e){this.lensActive=!0,this.lensSticky=!1,this.hotkeyDownAt=e,this.ensureMouseSeed(),this.settings.translationEngine===`browser`&&this.browserTranslator.prepare(this.settings.sourceLang,this.settings.targetLang),this.updateLens()}async scanVisibleAndTranslate(){if(this.pausedHere||!this.settings.autoTranslate||!this.canTranslateText())return;let e=Math.round(window.innerHeight*this.settings.prefetchMarginRatio),t=_e(this.settings.minTextLength,e);for(let e of t)this.registry.upsert({id:e.id,el:e.el,tag:e.tag,text:e.text});let n=this.registry.pendingBlocks().filter(e=>!this.inflight.has(e.id)&&!s(e.text,this.settings.targetLang));n.length&&await this.translateSpecific(n)}async maybeStartPageTranslation(){if(this.autoPageStartPending||this.pausedHere||!this.settings.autoPageTranslation||this.pageTranslator.isActive()||!at(this.settings.sourceLang)||this.settings.pageTranslationEngine===`external`&&!this.configured)return;let e=this.settingsGeneration,t=this.settings,n=this.configured;this.autoPageStartPending=!0;try{if(t.pageTranslationEngine===`browser`&&await this.browserTranslator.availability(t.sourceLang,t.targetLang)!==`available`||e!==this.settingsGeneration||this.pausedHere||!this.settings.autoPageTranslation||this.pageTranslator.isActive())return;await this.pageTranslator.activate(t,n)}finally{this.autoPageStartPending=!1,e!==this.settingsGeneration&&this.settings.autoPageTranslation&&!this.pausedHere&&!this.pageTranslator.isActive()&&this.maybeStartPageTranslation()}}onKeyDown=e=>{if(e.key===`Escape`){if(this.lensActive){e.preventDefault(),this.deactivateLens();return}if(this.pageTranslator.isActive()){e.preventDefault(),this.pageTranslator.deactivate();return}}if(!this.pausedHere){if(n(e,this.settings.pageTranslationHotkey)){if(e.repeat){e.preventDefault();return}e.preventDefault(),e.stopPropagation(),this.togglePageTranslation();return}if(n(e,this.settings.hotkey)){if(e.repeat){e.preventDefault();return}if(e.preventDefault(),e.stopPropagation(),this.lensActive&&this.lensSticky){this.deactivateLens();return}this.lensActive||(this.hotkeyHeld=!0,this.hotkeyDownAt=Date.now(),this.beginHotkeyLens(this.hotkeyDownAt))}}};async beginHotkeyLens(e){if(!(await this.ensureEngineReady(`lens`)).ok){this.hotkeyHeld=!1;return}if(!this.lensActive){if(!this.hotkeyHeld){let t=Date.now()-e;t>0&&t<Z&&this.activateStickyLens();return}this.activateTemporaryLens(e)}}onKeyUp=e=>{let t=e.code===this.settings.hotkey.code,n=this.isHotkeyModifierRelease(e);if((t||n)&&(this.hotkeyHeld=!1),!(!this.lensActive||this.lensSticky)){if(t){let e=Date.now()-this.hotkeyDownAt;if(e>0&&e<Z){this.lensSticky=!0;return}this.deactivateLens();return}n&&this.deactivateLens()}};onBlur=()=>{this.hotkeyHeld=!1,this.lensActive&&!this.lensSticky&&this.deactivateLens()};onMouseMove=e=>{let t=e.composedPath();t.includes(this.lens.getHost())||t.some(e=>e instanceof Element&&e.id===`lens-translator-bubble-root`)||(this.lastMouse={x:e.clientX,y:e.clientY},!(!this.lensActive||this.pointerFrame)&&(this.pointerFrame=requestAnimationFrame(()=>{this.pointerFrame=0,this.updateLens()})))};onStickyReposition=()=>{!this.lensActive||!this.lensSticky||this.stickyFrame||(this.stickyFrame=requestAnimationFrame(()=>{this.stickyFrame=0,this.lens.reposition()}))};updateLens(){if(!this.lensActive){this.lens.hide();return}this.ensureMouseSeed();let e=this.lens.getHost(),t=document.elementsFromPoint(this.lastMouse.x,this.lastMouse.y).filter(t=>t!==e&&!e.contains(t))[0]??null,n=this.imageEntryForHit(t);if(n){if(!this.configured){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`unconfigured`}),this.lens.highlight(null);return}let e=n.el.getBoundingClientRect();if(this.lens.highlight(n.el),n.status===`ready`&&n.translation){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`ready`,text:n.translation,sourceRect:e});return}if(n.status===`error`&&!this.imageInflight.has(n.id)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`error`,message:n.error??`图片翻译失败`,sourceRect:e});return}this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceRect:e}),this.translateImageEntry(n);return}if(!this.canTranslateText()){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`unconfigured`}),this.lens.highlight(null);return}let r=Math.min(2,this.settings.minTextLength),i=this.registry.getByElement(t);if(i){let e=k(this.lastMouse.x,this.lastMouse.y,r);e&&e.el!==i.el&&e.text.length<i.text.length&&(i=this.registry.upsert(e))}else{let e=k(this.lastMouse.x,this.lastMouse.y,r);e&&(i=this.registry.upsert(e))}if(!i){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`empty`}),this.lens.highlight(null);return}if(s(i.text,this.settings.targetLang)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`target-language`}),this.lens.highlight(i.el);return}this.lens.highlight(i.el);let a=i.el.getBoundingClientRect(),o=i.text;if(i.status===`ready`&&i.translation){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`ready`,text:i.translation,sourceText:o,sourceRect:a});return}if(i.status===`error`&&!this.inflight.has(i.id)){this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`error`,message:i.error??`翻译失败`,sourceText:o,sourceRect:a});return}this.lens.showAt(this.lastMouse.x,this.lastMouse.y,{kind:`pending`,sourceText:o,sourceRect:a}),this.inflight.has(i.id)||this.batcher.enqueue({id:i.id,tag:i.tag,text:i.text})}deactivateLens(){this.lensActive=!1,this.lensSticky=!1,this.hotkeyHeld=!1,this.hotkeyDownAt=0,this.lens.hide()}async translateImageEntry(e){if(!(this.pausedHere||!this.configured||this.imageInflight.has(e.id))){this.imageInflight.add(e.id),this.imageRegistry.setPending(e.id);try{let t=await chrome.runtime.sendMessage({type:`translate-image`,imageUrl:e.url});dt(t)?t.ok?this.imageRegistry.setTranslation(e.id,t.translation):this.imageRegistry.setError(e.id,bt(t.error)):this.imageRegistry.setError(e.id,`图片翻译服务未返回有效结果`)}catch(t){this.imageRegistry.setError(e.id,t instanceof Error?t.message:String(t))}finally{this.imageInflight.delete(e.id)}this.lensActive&&this.updateLens()}}async translateWithBrowser(e){if(!this.browserTranslator.isSupported())return;let t=this.translationGeneration,n=this.settings.sourceLang,r=this.settings.targetLang;for(let i of e){if(t!==this.translationGeneration)return;let e=await this.browserTranslator.translate(i.text,n,r);if(t!==this.translationGeneration)return;e&&this.registry.setTranslation(i.id,e)}}async translateSpecific(e){if(this.pausedHere)return;let t=this.translationGeneration,n=this.settings.translationEngine,r=this.configured,i=[],a=new Set;for(let t of e){if(s(t.text,this.settings.targetLang))continue;let e=this.registry.get(t.id);if(!e||e.status===`ready`&&e.translation||this.inflight.has(t.id))continue;let n=o(t.text);if(!this.inflightTexts.has(n)){if(a.has(n)){this.registry.setPending(t.id);continue}a.add(n),i.push({id:t.id,tag:t.tag,text:n})}}if(!i.length)return;for(let e of i)this.inflight.set(e.id,t),this.inflightTexts.set(o(e.text),t),this.registry.setPending(e.id);let c=n===`browser`?`Chrome 内置翻译不可用或不支持当前语言对`:`外部 API 未配置`;try{if(n===`browser`)await this.translateWithBrowser(i);else if(r){let e=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:N(),blocks:i});if(t!==this.translationGeneration)return;if(!Q(e))c=`翻译服务未返回有效结果`;else{for(let t of e.translations??[])this.registry.setTranslation(t.id,t.translation);e.ok||(c=e.error)}}if(t!==this.translationGeneration)return;for(let e of i)this.registry.get(e.id)?.translation||this.registry.setError(e.id,c)}catch(e){if(t!==this.translationGeneration)return;c=e instanceof Error?e.message:String(e);for(let e of i)this.registry.get(e.id)?.translation||this.registry.setError(e.id,c)}finally{for(let e of i){this.inflight.get(e.id)===t&&this.inflight.delete(e.id);let n=o(e.text);this.inflightTexts.get(n)===t&&this.inflightTexts.delete(n)}}this.lensActive&&this.updateLens()}canTranslateText(){return this.settings.translationEngine===`browser`?this.browserTranslator.isSupported():this.configured}syncAutoScanObserver(){if(this.settings.autoTranslate&&!this.pausedHere){this.autoScanMo||(this.autoScanMo=new MutationObserver(xt(()=>{this.settings.autoTranslate&&this.scanVisibleAndTranslate()},500)),this.autoScanMo.observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0}));return}this.autoScanMo?.disconnect(),this.autoScanMo=null}async ensureEngineReady(e,t){if(this.pausedHere)return{ok:!1,error:`当前网站已暂停翻译`};let n=e===`lens`?this.settings.translationEngine:this.settings.pageTranslationEngine,r=t?.quiet===!0;if(n===`external`)return this.configured?{ok:!0}:(r||this.showEngineSetupPrompt({kind:`external-unconfigured`}),{ok:!1,error:e===`lens`?`透镜翻译需要先配置外部 API`:`整页翻译需要先配置外部 API`});if(!this.browserTranslator.isSupported())return r||this.showEngineSetupPrompt({kind:`browser-unsupported`}),{ok:!1,error:`当前浏览器不支持 Chrome 内置翻译`};let i=await this.browserTranslator.availability(this.settings.sourceLang,this.settings.targetLang);return i===`available`?{ok:!0}:(r||this.showEngineSetupPrompt({kind:`language-pack`,availability:i}),{ok:!1,error:i===`unavailable`?`当前语言对在 Chrome 内置翻译中不可用`:`需要先下载 Chrome 语言包`})}showEngineSetupPrompt(e){this.setupPrompt.isOpen()||this.setupPrompt.show(e,{sourceLang:this.settings.sourceLang,targetLang:this.settings.targetLang},{onDownload:e.kind===`language-pack`?async()=>{if(this.setupPrompt.setStatus(`正在下载语言包…`),await this.browserTranslator.prepare(this.settings.sourceLang,this.settings.targetLang,e=>{this.setupPrompt.setStatus(`语言包下载 ${Math.round(e*100)}%`)})){this.setupPrompt.setStatus(`语言包已就绪，请再次开启翻译`),window.setTimeout(()=>this.setupPrompt.dismiss(),900);return}this.setupPrompt.setStatus(`语言包下载失败，请改用外部 LLM 或更换语言`,!0)}:void 0,onOpenLlmSetup:()=>{chrome.runtime.sendMessage({type:`open-options`,hash:`#external-api`})},onOpenOnboarding:()=>{chrome.runtime.sendMessage({type:`open-options`,hash:`#onboarding`})}})}async translateSelectionText(e){if(this.pausedHere)return null;if(this.settings.translationEngine===`browser`){let t=await this.ensureEngineReady(`lens`,{quiet:!0});if(!t.ok)throw this.maybePromptSetupFromSelection(),Error(t.error);return this.browserTranslator.translate(e,this.settings.sourceLang,this.settings.targetLang)}let t=await this.ensureEngineReady(`lens`,{quiet:!0});if(!t.ok)throw this.maybePromptSetupFromSelection(),Error(t.error);let n=await chrome.runtime.sendMessage({type:`translate-batch`,pageKey:N(),blocks:[{id:`sel`,tag:`selection`,text:e}]});if(!Q(n)||!n.ok)throw Q(n)&&!n.ok?Error(n.error):Error(`翻译服务未返回有效结果`);return n.translations.find(e=>e.id===`sel`)?.translation??null}maybePromptSetupFromSelection(){let e=Date.now();e-this.lastSelectionSetupPromptAt<6e4||(this.lastSelectionSetupPromptAt=e,this.ensureEngineReady(`lens`))}bubbleState(){return{ok:!0,lensActive:this.lensActive,pageTranslationActive:this.pageTranslator.isActive()}}async handleBubbleControl(e){if(e.command===`get-state`)return this.bubbleState();if(e.command===`toggle-lens`){let e=await this.toggleStickyLensAsync();return e.ok?this.bubbleState():e}let t=await this.togglePageTranslation();return t.ok?this.bubbleState():t}imageEntryForHit(e){if(!(e instanceof HTMLImageElement)||!e.complete||e.naturalWidth<2||e.naturalHeight<2)return;let t=e.currentSrc||e.src;if(t)return this.imageRegistry.upsert(d(`img`,t,v(e)),e,t)}isHotkeyModifierRelease(e){let t=this.settings.hotkey;return!!(t.altKey&&(e.code===`AltLeft`||e.code===`AltRight`)||t.shiftKey&&(e.code===`ShiftLeft`||e.code===`ShiftRight`)||t.ctrlKey&&(e.code===`ControlLeft`||e.code===`ControlRight`)||t.metaKey&&(e.code===`MetaLeft`||e.code===`MetaRight`))}};function yt(e){return`command`in e?e.command===`get-state`||e.command===`toggle-page-translation`||e.command===`toggle-lens`:!1}function $(e){return{ok:!1,error:e instanceof Error?e.message:String(e)}}function bt(e){let t=e.toLowerCase();return e.includes(`API not configured`)||e.includes(`未配置`)?`图片翻译需要外部多模态模型：请先配置 Base URL、API Key 与支持 image 的模型`:t.includes(`image`)&&(t.includes(`not support`)||t.includes(`unsupported`)||t.includes(`invalid`)||t.includes(`不支持`))?e:e.includes(`400`)||t.includes(`invalid_request`)||t.includes(`unknown field`)?`当前模型可能不支持图片输入：${e}`:e}function xt(e,t){let n=0;return((...r)=>{window.clearTimeout(n),n=window.setTimeout(()=>e(...r),t)})}var St=`lens-translator-bubble-shell`,Ct=class{host;frame;pinned=!1;collapseTimer=0;mountObserver;constructor(){this.host=document.createElement(`div`),this.host.id=`lens-translator-bubble-root`,this.host.setAttribute(`data-lens-ignore`,``);let e=this.host.attachShadow({mode:`closed`}),t=document.createElement(`style`);t.textContent=Tt,this.frame=document.createElement(`iframe`),this.frame.src=chrome.runtime.getURL(`src/bubble/index.html`),this.frame.title=`Lens Translator 快捷控制`,this.frame.setAttribute(`allow`,`clipboard-write`),e.append(t,this.frame),this.host.addEventListener(`pointerenter`,()=>this.expand()),this.host.addEventListener(`pointerleave`,()=>this.scheduleCollapse()),window.addEventListener(`message`,this.onMessage),this.mountObserver=new MutationObserver(()=>{this.host.isConnected||this.mount()}),this.mountObserver.observe(document.documentElement,{childList:!0})}mount(){this.host.isConnected||document.documentElement.append(this.host)}setVisible(e){this.host.style.display=e?``:`none`,e||(this.pinned=!1,delete this.host.dataset.expanded)}expand(){window.clearTimeout(this.collapseTimer),this.host.dataset.expanded=`true`}scheduleCollapse(){this.pinned||(window.clearTimeout(this.collapseTimer),this.collapseTimer=window.setTimeout(()=>{delete this.host.dataset.expanded},420))}onMessage=e=>{if(!(e.source!==this.frame.contentWindow||!wt(e.data))){if(e.data.action===`pin`){this.pinned=!0,this.expand();return}this.pinned=!1,e.data.action===`collapse`?delete this.host.dataset.expanded:this.scheduleCollapse()}}};function wt(e){if(!e||typeof e!=`object`)return!1;let t=e;return t.type===St&&(t.action===`pin`||t.action===`unpin`||t.action===`collapse`)}var Tt=`
  :host { all: initial; }
  iframe {
    display: block;
    width: 100%;
    height: 100%;
    border: 0;
    background: transparent;
  }
  :host {
    position: fixed;
    z-index: 2147483646;
    top: clamp(88px, 42vh, calc(100vh - 88px));
    right: -13px;
    width: 62px;
    height: 62px;
    overflow: hidden;
    pointer-events: auto;
    border-radius: 18px 0 0 18px;
    filter: drop-shadow(0 10px 24px rgb(15 23 42 / 16%));
    transition:
      width 280ms cubic-bezier(.2,.8,.2,1),
      height 280ms cubic-bezier(.2,.8,.2,1),
      right 280ms cubic-bezier(.2,.8,.2,1),
      top 280ms cubic-bezier(.2,.8,.2,1),
      border-radius 220ms ease;
  }
  :host([data-expanded="true"]) {
    top: clamp(12px, calc(50vh - 260px), 28px);
    right: 12px;
    width: min(360px, calc(100vw - 24px));
    height: min(520px, calc(100vh - 24px));
    border-radius: 12px;
  }
  @media (max-width: 520px) {
    :host([data-expanded="true"]) {
      top: 8px;
      right: 8px;
      width: calc(100vw - 16px);
      height: min(520px, calc(100vh - 16px));
    }
  }
  @media (prefers-reduced-motion: reduce) {
    :host { transition-duration: 1ms; }
  }
`,Et=`__lensTranslatorMounted`,Dt=window;async function Ot(){if(Dt[Et])return;Dt[Et]=!0;let e=new vt(340),t=new Ct;t.mount(),e.setBubbleVisibilityHandler(e=>t.setVisible(e)),e.bindListeners(),e.ensureMouseSeed(),await e.refreshSettings()}Ot();
//# sourceMappingURL=main.ts-DNuTgOS6.js.map